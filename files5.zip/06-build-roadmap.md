# Focus Forge — Build Roadmap

**Status:** Draft v1.0
**Owners:** ADHD Toolkit Task Force
**Architecture:** Vercel + cPanel MySQL + Monorepo + Prisma
**Builder:** Claude Code (primary) with human review at milestone gates

---

## How To Use This Document

This roadmap is structured for an AI coding agent to execute step by step. Each milestone is **atomic, verifiable, and rollback-able**.

### Reading Order
1. Read this entire file before starting Milestone 1.
2. Read the milestone you're working on in full before any code is written.
3. Refer to spec docs (`01–05`, `07`, `08`) when implementation details are unclear.
4. **Stop at every milestone gate** for human verification.

### What Each Milestone Contains
- **Goal** — One sentence: what's working at the end
- **Prerequisites** — What must be done first
- **Spec references** — Which other docs to consult
- **Files** — What to create/modify
- **Tasks** — Atomic, ordered steps
- **Tests** — Automated tests required (TDD encouraged but not mandatory)
- **Acceptance criteria** — Pass/fail gate
- **Manual smoke test** — What the human verifies
- **Pause point** — ✅ Safe to stop here

### Conventions
- All paths relative to monorepo root
- All commands assume `pnpm` package manager
- All code TypeScript with `strict: true`
- All tests use Vitest (unit/integration) + Playwright (E2E)
- All commits follow Conventional Commits format

---

## Phase Overview

```
PHASE 1: FOUNDATION (3 milestones)
  M1: Monorepo + Vercel + DB connection
  M2: Authentication system + Admin foundation
  M3: Design system primitives

PHASE 2: VERTICAL SLICES (10 milestones)
  M4: Task capture + dashboard
  M5: Walk Me Through It
  M6: Analog Timer
  M7: Voice Dump + AI parsing
  M8: Reverse Scheduler / Doorknob
  M9: Launchpad
  M10: Praise Repository
  M11: Body Doubling
  M12: Body Check-Ins
  M13: Decision Paralysis Breaker

PHASE 3: LAUNCH PREP (4 milestones)
  M14: Onboarding flow + first-session experience
  M15: PWA + offline + production hardening
  M16: Bug & Feature Request Tool (community feedback infrastructure)
  M17: Routines & Task Templates (recurring schedules)

POST-LAUNCH (deferred):
  M18: Monetization (Stripe integration, Pro tier)
```

**Note on M16 ordering:** The Bug & Feature Request Tool intentionally ships in Phase 3 — early users need a way to report issues from day one. Building it before M18 (paid) means feedback collection is available throughout the free-tier launch period.

**Note on M17 ordering:** Routines depend on the task system (M4) but don't directly depend on M14 or M15. They're sequenced after M15 for milestone discipline (don't introduce major user-facing features during launch hardening).

**Note on M18:** Build the entire app on the free tier first. Add paid-tier infrastructure once you have real users to validate pricing assumptions. The `feature_grants` table from M1 already supports this.

---

# PHASE 1: FOUNDATION

## Milestone 1: Monorepo + Vercel + DB Connection

**Goal:** A deployed monorepo on Vercel that connects to your cPanel MySQL and shows a "Hello, Focus Forge" page.

**Prerequisites:**
- GitHub account
- Vercel account (free tier)
- cPanel access with Remote MySQL feature enabled
- OpenAI API key (will use later)
- Local Node 20+ and pnpm 9+ installed

**Spec references:** `04-mysql-schema.md` §3, §6

### Tasks

#### 1.1 Monorepo Scaffolding
```
- Initialize repo with pnpm workspaces:
  - Create root package.json with "workspaces": ["apps/*", "packages/*"]
  - Create pnpm-workspace.yaml
  - Create turbo.json (Turborepo for build orchestration)
  - Create tsconfig.base.json (extended by all packages)
  - Create .editorconfig, .gitignore, .nvmrc (Node 20)
  
- Create folder structure:
  apps/web/              (Next.js app)
  packages/database/     (Prisma + DB client)
  packages/ui/           (Design system — empty for now)
  packages/domain/       (Pure business logic — empty for now)
  packages/ai/           (OpenAI integration — empty for now)
  packages/config/       (Shared TS, ESLint configs)
```

#### 1.2 Next.js App
```
- cd apps/web
- pnpm create next-app@latest . --typescript --tailwind --app --no-src-dir
  - When prompted: use App Router, TypeScript yes, Tailwind yes, no src dir
- Install: prisma, @prisma/client, zod, lucide-react
- Configure tailwind.config.ts to extend from packages/ui (when ui exists)
- Add @ alias for app paths
```

#### 1.3 Prisma Setup
```
- cd packages/database
- pnpm init
- pnpm add prisma @prisma/client
- pnpm dlx prisma init --datasource-provider mysql
- Configure schema.prisma with cuid() primary keys (per doc 04 §2.2):
    model User {
      id String @id @default(cuid())
      // ...
    }
- Create the basic users table in schema.prisma (just enough for M2)
- Add prisma scripts: "generate", "migrate dev", "migrate deploy", "studio"
- Export Prisma client singleton from src/client.ts (avoid multiple instances)
- DO NOT use UUIDv7 or BINARY(16) — see doc 04 §2.2 for rationale
```

#### 1.4 Remote MySQL Setup (cPanel side)
```
INSTRUCTIONS FOR HUMAN (Claude Code: pause and request human action):

1. Log into cPanel
2. Find "Remote MySQL" in the Databases section
3. Add Vercel's IP ranges to allowed hosts:
   - Vercel doesn't publish static IPs for free tier
   - Use "%" (any host) as a temporary measure for development
   - Document that this is a security tradeoff to revisit before paid launch
4. Create a new MySQL database: focus_forge
5. Create a new MySQL user with full access to focus_forge
6. Note the connection string format:
   mysql://USER:PASSWORD@your-cpanel-domain.com:3306/focus_forge
7. Provide this DATABASE_URL to Claude Code via .env.local
```

#### 1.5 Vercel Setup
```
- Push monorepo to GitHub (private repo)
- Import in Vercel:
  - Root Directory: apps/web
  - Framework Preset: Next.js
  - Build Command: pnpm build (Vercel auto-detects monorepo)
  - Install Command: pnpm install
  - Output Directory: .next
- Add environment variables in Vercel dashboard:
  - DATABASE_URL (from cPanel)
  - NEXTAUTH_SECRET (generate: openssl rand -base64 32)
  - NEXTAUTH_URL (https://your-vercel-url.vercel.app)
- Trigger first deploy
```

#### 1.6 Hello, Focus Forge
```
- Replace apps/web/app/page.tsx with a simple "Hello, Focus Forge" page
- Add a server component that queries the database (e.g., counts users — should return 0)
- Verify the DB connection works from Vercel
```

### Tests Required

```
packages/database/src/__tests__/client.test.ts:
  - Test that Prisma client connects (skip in CI without DB)

apps/web/__tests__/home.test.tsx:
  - Test that home page renders without error
  - Test that "Hello, Focus Forge" appears

CI setup:
  - GitHub Actions workflow runs lint + test on every push
  - .github/workflows/ci.yml: pnpm install, pnpm lint, pnpm test
```

### Acceptance Criteria

- [ ] `pnpm install` from repo root succeeds
- [ ] `pnpm dev` runs the web app locally on http://localhost:3000
- [ ] Home page shows "Hello, Focus Forge"
- [ ] `pnpm prisma migrate dev` creates the users table on cPanel MySQL
- [ ] phpMyAdmin shows the users table exists
- [ ] Vercel deploy succeeds and shows the same page at the public URL
- [ ] Vercel page successfully queries cPanel MySQL (e.g., count of users = 0)
- [ ] CI workflow runs and passes
- [ ] All TypeScript strict checks pass

### Manual Smoke Test (Human)

1. Open Vercel deploy URL → see "Hello, Focus Forge"
2. Open phpMyAdmin → see users table with 0 rows
3. Make a trivial change locally → push to GitHub → confirm Vercel auto-deploys

### ✅ PAUSE POINT — End of M1

Stop here. Verify everything works. The biggest deployment risks are now eliminated. Future milestones build on a known-working foundation.

---

## Milestone 2: Authentication System + Admin Foundation

**Goal:** Users can sign up and log in via email+password, Google, Facebook, and magic link. Sessions persist 30 days. **The foundational admin model is also in place** — admin permissions defined, audit logging working, and the project owner can manage their own grants. Granular admin features (content moderation, billing, etc.) ship in their respective milestones.

**Prerequisites:** M1 complete

**Spec references:** `01-authentication-and-user-model.md` (entire doc, including §4 account states and §5.1.1 comp tier), `04-mysql-schema.md` §4.1–4.4, §4.7 (admin feature_keys), §4.28 (admin_actions table)

### Why Admin Is In M2

Admin tools must exist from the moment real user accounts exist. A hostile early user could do real damage (abusive submissions, ToS violations) before later milestones ship if there's no way to manage them. M2 gets the *foundational* admin model — capability checks, audit logging, basic account management. Specialized admin features (content moderation queue, billing console, etc.) ship in their respective feature milestones.

### Tasks

#### 2.1 Install NextAuth.js (v4 stable)
```
- pnpm add next-auth@^4 @next-auth/prisma-adapter
- pnpm add @node-rs/argon2 (for password hashing)
- pnpm add resend (for transactional email — magic link, verification)

NOTE: Using NextAuth v4 stable, not v5 beta. v4 has battle-tested patterns
that Claude Code reliably implements. v5 migration is documented future work.
```

#### 2.2 Expand Prisma Schema
```
- Add all auth-related tables from 04-mysql-schema.md §4.1-4.4:
  - users (with all fields)
  - auth_methods
  - sessions
  - magic_link_tokens
  - password_reset_tokens
  - email_verification_tokens
  - feature_grants (set up structure now, populate later)
  - audit_log
- Run prisma migrate dev
- Verify in phpMyAdmin
```

#### 2.3 Configure Auth.js
```
- apps/web/lib/auth.ts: NextAuth config with Google, Facebook, Email (magic link), Credentials (password) providers
- Email provider configured for magic links via Resend
- Credentials provider for email+password
- Custom pages: /signin, /signup, /verify-email, /reset-password
- Custom callbacks for tier checks, feature_grants
- Session strategy: database (using sessions table)
```

#### 2.4 Auth UI Pages
```
- apps/web/app/(auth)/signin/page.tsx
- apps/web/app/(auth)/signup/page.tsx
- apps/web/app/(auth)/verify-email/page.tsx
- apps/web/app/(auth)/reset-password/page.tsx
- apps/web/app/(auth)/layout.tsx (centered, single-column)

These use raw HTML/Tailwind — design system components come in M3.
```

#### 2.5 Server Actions for Auth Flows
```
- apps/web/server-actions/auth/signup-with-password.ts
- apps/web/server-actions/auth/signin-with-password.ts
- apps/web/server-actions/auth/request-magic-link.ts
- apps/web/server-actions/auth/request-password-reset.ts
- apps/web/server-actions/auth/verify-email.ts
- apps/web/server-actions/auth/sign-out.ts

Each action:
  - Validates input with Zod
  - Logs to audit_log
  - Implements rate limiting (5 attempts per email per 15 min)
  - Returns typed result (not throwing)
```

#### 2.6 OAuth Provider Registration (Human action)
```
INSTRUCTIONS FOR HUMAN:

Google:
1. Go to console.cloud.google.com
2. Create project: "Focus Forge"
3. Configure OAuth consent screen
4. Create OAuth credentials → Web application
5. Authorized redirect URIs: 
   - http://localhost:3000/api/auth/callback/google
   - https://your-vercel-url.vercel.app/api/auth/callback/google
6. Copy Client ID and Secret to .env.local and Vercel env vars

Facebook:
1. Go to developers.facebook.com
2. Create new app, type: Consumer
3. Add Facebook Login product
4. Settings → Basic: get App ID and App Secret
5. Add OAuth redirect URI same as Google
6. Copy to env vars

Apple:
DEFERRED for v1. Requires Apple Developer Program ($99/yr).
Will be added in a post-launch milestone. No action needed now.

Resend (Email Provider):
1. Sign up at resend.com (free tier: 3,000 emails/month, 100/day)
2. Verify a domain you own (or use their onboarding domain for dev)
3. Generate an API key
4. Copy RESEND_API_KEY to .env.local and Vercel env vars
5. Configure FROM email address in lib/email/config.ts
```

#### 2.7 Account Settings Page (Minimal)
```
- apps/web/app/(app)/account/page.tsx
- Shows current email, linked auth methods, "Sign out" button
- Shows account state (with appropriate UI for paused/suspended/pending_delete)
- Shows tier (with "Comp" indicator if applicable)
- Full account management (delete, export) deferred to M14
```

#### 2.8 Admin Foundation — Permission System
```
Per doc 04 §4.7 (admin feature_keys) and doc 01 §4.7 (audit trail):

- packages/domain/src/admin/permissions.ts
  - Define ADMIN_PERMISSIONS constant (all 12 admin feature_keys)
  - hasAdminPermission(userId, permission) helper using existing feature_grants table
  - requireAdminPermission(permission) middleware for API routes
  - Composite permission helpers (e.g., isAdmin = hasAny([...adminKeys]))
  
- packages/domain/src/admin/audit.ts
  - logAdminAction({ adminUserId, targetUserId, action, justification, metadata, stateBefore }) helper
  - Wraps insert into admin_actions table
  - Captures IP and user_agent automatically from request context

- ALL admin operations call logAdminAction() — no exceptions
- justification REQUIRED for: pause, suspend, soft_delete, emergency_delete,
  content removal, grant_admin, revoke_admin, grant_comp
```

#### 2.9 Admin Foundation — Account State Machine
```
Per doc 01 §4 expanded state machine:

- packages/domain/src/users/account-state.ts
  - getAccountStateForRequest(userId) — returns current effective state
    Considers: account_state column, paused_until, comp_expires_at
  - canUserPerformAction(userId, action) — guards based on state
    e.g., paused users cannot create content but can read

- Middleware: apps/web/middleware.ts
  - On every authenticated request, check account_state
  - 'paused' users: allow page reads, block mutations, show paused banner
  - 'suspended' users: redirect to /account/suspended page
  - 'pending_delete' users: show banner with cancel-deletion CTA
  - 'unverified' users: existing behavior (email verification banner)

- Pages:
  - /account/paused (shown to paused users on signin)
  - /account/suspended (shown to suspended users on signin attempt)
  - /account/scheduled-for-deletion (shown to pending_delete users with cancel CTA)
```

#### 2.10 Admin Foundation — Bootstrap Script
```
The project owner needs to grant themselves admin permissions before any admin UI exists.

- scripts/grant-super-admin.ts
  - Takes --email flag
  - Inserts feature_grants rows for ALL admin permissions
  - Records the action in admin_actions (admin_user_id = the granted user, target = self)
  - Idempotent (skips if already granted)
  - Run via: pnpm tsx scripts/grant-super-admin.ts --email you@example.com

CRITICAL: This script can ONLY be run from server/CLI. It is NOT exposed via any
HTTP endpoint. The first super-admin must be created out-of-band.

After bootstrap, the super-admin can grant other admins via the UI (M2.12).
```

#### 2.11 Admin Foundation — Minimal Admin UI
```
Just enough admin UI to be useful in early days. Full admin console expands in later milestones.

- apps/web/app/admin/layout.tsx
  - Wrapper layout for all /admin/* routes
  - Hard-checks at minimum admin_user_view permission
  - Forbidden users redirected to /404 (don't reveal admin exists)
  - Banner showing "ADMIN MODE" so admins remember they're in privileged context
  
- apps/web/app/admin/page.tsx (admin dashboard)
  - Quick links to: users, audit log, my permissions
  - Empty initially; expands as more admin features ship
  
- apps/web/app/admin/users/page.tsx (basic user list)
  - Search by email
  - Filter by account_state, tier
  - Per-user row: id, email, tier, state, signup date, last login
  - Click user → /admin/users/[id]
  
- apps/web/app/admin/users/[id]/page.tsx (user detail)
  - Read-only at minimum (admin_user_view)
  - Action buttons appear based on permissions:
    - admin_user_pause → Pause button
    - admin_user_suspend → Suspend button
    - admin_user_soft_delete → Soft Delete button
    - admin_user_management → Edit, Force Sign Out, Force Password Reset, Grant Comp
    - admin_user_emergency_delete → Emergency Delete (red-bordered confirmation)
  - All actions require justification text in modal
  - Audit log of actions taken on this user shown below
```

#### 2.12 Admin Foundation — User Management Actions
```
Server actions for the admin user management surface:

- apps/web/server-actions/admin/pause-user.ts
  - Required: target_user_id, duration_days, reason
  - Sets account_state='paused', paused_until=NOW()+duration
  - Logs to admin_actions with state_before snapshot
  
- apps/web/server-actions/admin/unpause-user.ts
- apps/web/server-actions/admin/suspend-user.ts
- apps/web/server-actions/admin/unsuspend-user.ts
- apps/web/server-actions/admin/soft-delete-user.ts
  - Required: target_user_id, justification
  - Optional: grace_period_days (default 30, super-admin can override to 0)
- apps/web/server-actions/admin/cancel-deletion.ts
- apps/web/server-actions/admin/emergency-delete-user.ts
  - Requires admin_user_emergency_delete permission
  - Requires extensive justification (min 100 chars)
  - Hard deletes immediately
  - Sends email to user if possible

- apps/web/server-actions/admin/grant-comp-tier.ts
  - Sets tier='comp', records previous tier for revert
  - Optional comp_expires_at
- apps/web/server-actions/admin/revoke-comp-tier.ts
- apps/web/server-actions/admin/grant-feature.ts (granular alternative to comp)
- apps/web/server-actions/admin/revoke-feature.ts
- apps/web/server-actions/admin/force-signout.ts
- apps/web/server-actions/admin/force-password-reset.ts

- apps/web/server-actions/admin/grant-admin-permission.ts
  - Requires admin_grant_admin (super-admin only)
- apps/web/server-actions/admin/revoke-admin-permission.ts
```

#### 2.13 Admin Foundation — Audit Log Viewer
```
- apps/web/app/admin/audit-log/page.tsx
  - Shows admin_actions table contents
  - Filter by: admin user, target user, action, date range
  - Each entry shows: when, who (admin), what (action), to whom (target), why (justification)
  - Required permission: admin_user_view OR admin_user_management
- Read-only — entries cannot be deleted or modified
```

### Tests Required

```
Unit tests (Vitest):
  - Password hashing/verification round-trip
  - Magic link token generation/validation
  - Email validation (edge cases: plus addressing, unicode)
  - Rate limiter logic
  - Admin permission checks (positive + negative cases)
  - Account state transitions (paused → active auto-restore, etc.)
  - logAdminAction always populates required fields

Integration tests:
  - Sign up with email+password creates user + auth_method rows
  - Sign in with correct password creates session
  - Sign in with wrong password does NOT create session, increments rate limit
  - Magic link flow end-to-end (mock email send)
  - Password reset flow end-to-end
  - OAuth callback creates user on first login, links on subsequent
  - Bootstrap script grants all admin permissions atomically
  - Admin pauses user → user cannot create content, can still sign in
  - Admin suspends user → user cannot sign in
  - Admin soft-deletes user → 30-day grace, user can self-recover
  - Non-admin attempts admin endpoint → 404 (NOT 403, hide admin existence)
  - Admin actions all create admin_actions rows with justification

E2E tests (Playwright):
  - User signs up with email+password → lands on dashboard
  - User signs out → can't access /account
  - User clicks "Forgot password" → receives email (mock) → resets → can log in
  - Project owner runs bootstrap script → can access /admin
  - Random user navigates to /admin → 404 page
  - Admin pauses user (with justification) → audit_actions row appears
  - Admin grants comp tier → user UI shows "Comp" indicator
  - Suspended user attempts sign in → sees suspension page with appeal info
```

### Acceptance Criteria

- [ ] User can sign up with email+password
- [ ] User can sign in with email+password
- [ ] User can sign in with Google OAuth
- [ ] User can sign in with Facebook OAuth
- [ ] Apple Sign-In: NOT in scope for v1 (skipped per spec)
- [ ] User can request and use magic link
- [ ] Sessions survive page refresh and 30-day inactivity simulation
- [ ] Password reset flow works end-to-end
- [ ] Email verification works (banner shown until verified, doesn't block app)
- [ ] Rate limiting kicks in after 5 failed attempts
- [ ] No red colors anywhere in auth UI (audit with grep)
- [ ] All forms keyboard-accessible
- [ ] axe-core passes 0 violations on all auth pages
- [ ] **Bootstrap script grants all 12 admin permissions to project owner**
- [ ] **Admin permission checks gate all /admin/* routes**
- [ ] **Forbidden access to /admin returns 404, not 403 (hides admin existence)**
- [ ] **Admin can pause/unpause users with justification**
- [ ] **Admin can suspend/unsuspend users with justification**
- [ ] **Admin can soft-delete users with 30-day grace (default) or override (super-admin)**
- [ ] **Super-admin can emergency-delete with min 100-char justification**
- [ ] **Admin can grant/revoke Comp tier with optional expiration**
- [ ] **Admin can grant/revoke specific feature_grants (granular alternative)**
- [ ] **All admin actions logged to admin_actions table with justification**
- [ ] **Audit log viewer shows all admin actions with filters**
- [ ] **Comp tier auto-expires via hourly cron (revert to comp_previous_tier)**
- [ ] **Paused accounts auto-restore via hourly cron when paused_until passes**
- [ ] **Paused users see banner, can read but not mutate**
- [ ] **Suspended users blocked from signing in, see appeal info**
- [ ] **Admin actions on locked users are tracked even if user is later deleted (admin_actions FK is SET NULL)**
- [ ] All tests pass

### Manual Smoke Test (Human)

1. Sign up with a real email — receive welcome
2. Log out, log back in with password
3. Log out, log in with Google
4. Log out, request magic link, click email link, verify auto-login
5. Forget password, reset, log in with new password
6. Check phpMyAdmin: users, auth_methods, sessions all populated correctly
7. Try to log in with wrong password 6 times → rate limit message appears

**Admin smoke tests:**
8. Run `pnpm tsx scripts/grant-super-admin.ts --email you@example.com`
9. Sign in as you — visit /admin, see admin dashboard
10. Sign in as a different user — visit /admin, see 404
11. As admin, find another user, pause them with reason "Testing"
12. As that user, sign in — see paused banner, try to create task → blocked
13. As admin, unpause the user
14. As admin, grant the user Comp tier with 7-day expiration
15. Verify in phpMyAdmin: users.tier='comp', comp_expires_at set
16. Wait 7+ days (or update timestamp manually) → cron reverts tier
17. Visit /admin/audit-log → see all actions taken with justifications

### ✅ PAUSE POINT — End of M2

Auth + admin is the most security-sensitive milestone. Verify thoroughly before continuing.

**Note:** This is a substantially larger M2 than originally specified. Plan accordingly. The Task Force chose to expand M2 rather than create a separate admin milestone because admin tools must exist from the moment user accounts exist.

---

## Milestone 3: Design System Primitives

**Goal:** Core UI components built and themed. Dark mode default. No red anywhere. Components live in `packages/ui` and are consumed by `apps/web`.

**Prerequisites:** M2 complete

**Spec references:** `02-design-system.md` (entire doc)

### Tasks

#### 3.1 Tailwind Config + Tokens
```
- packages/ui/tailwind.preset.ts: 
  - All color tokens from 02-design-system.md §2
  - All typography tokens from §3
  - All spacing/radius/shadow tokens from §4-7
  - Red removal via Proxy (§13.2)
- packages/ui/styles/globals.css:
  - CSS variables for both dark and light themes
  - Reduced-motion media query
- apps/web tailwind.config.ts extends the preset
```

#### 3.2 Component Library — Primitives
```
packages/ui/src/components/:

- Button.tsx (variants: primary, secondary, ghost, soft-destructive)
- IconButton.tsx (always with aria-label)
- Input.tsx (text, email, password, with show/hide toggle)
- Textarea.tsx (auto-growing)
- Select.tsx (native on mobile, custom on desktop)
- Checkbox.tsx
- Radio.tsx
- Toggle.tsx
- Slider.tsx
- Label.tsx

All components:
  - Use CSS variables (no hardcoded colors)
  - 44×44px minimum touch targets
  - Visible focus rings (--accent, 2px, 2px offset)
  - TypeScript prop types exported
  - JSDoc comments with examples
```

#### 3.3 Component Library — Containers
```
- Card.tsx
- Modal.tsx (focus trap, Esc-to-close, backdrop click)
- Drawer.tsx (slides from right)
- Toast.tsx (4s auto-dismiss, soft, non-blocking)
- ToastProvider.tsx (root provider for app)
```

#### 3.4 Component Library — Feedback
```
- EmptyState.tsx (illustration + message + single CTA)
- LoadingSpinner.tsx
- SkeletonLoader.tsx
- ErrorBoundary.tsx (graceful fail, Forgiveness Protocol — no red)
```

#### 3.5 Theme Provider
```
- packages/ui/src/theme/ThemeProvider.tsx
- Reads user preference from cookie / DB
- Falls back to prefers-color-scheme
- Applies data-theme attribute to <html>
```

#### 3.6 Storybook (Highly Recommended)
```
- pnpm dlx storybook@latest init in packages/ui
- Story file for every component
- This is your visual QA tool
```

#### 3.7 Apply To Auth Pages (Refactor)
```
- Refactor M2 auth pages to use new components
- This ensures the design system actually works under load
- Verify dark mode looks correct on all auth screens
```

### Tests Required

```
Unit tests:
  - Each component renders without crashing
  - Each component respects disabled state
  - Each component respects required ARIA attributes
  - ThemeProvider correctly switches themes

Visual regression (optional but recommended):
  - Storybook + Chromatic, or 
  - Playwright screenshot tests for each component

Accessibility tests:
  - axe-core integration in component tests
  - 0 violations required
```

### Acceptance Criteria

- [ ] All components in packages/ui exist with TypeScript types
- [ ] Storybook runs and shows every component in dark + light mode
- [ ] Auth pages refactored to use design system
- [ ] Build error if any code uses Tailwind red-* class
- [ ] axe-core: 0 violations on Storybook pages
- [ ] All components keyboard-navigable
- [ ] prefers-reduced-motion honored (verify with DevTools)
- [ ] All components have JSDoc with usage examples

### Manual Smoke Test (Human)

1. Open Storybook → tab through every component
2. Toggle dark/light theme → all components look correct
3. Enable "Reduce motion" in OS settings → animations disabled
4. Open auth pages → look identical to Storybook in dark mode
5. Try to write `text-red-500` somewhere → build fails with helpful error

### ✅ PAUSE POINT — End of M3 — End of Phase 1

Phase 1 complete. Foundation is solid. Vertical slices begin.

---

# PHASE 2: VERTICAL SLICES

## Milestone 4: Task Capture + Dashboard

**Goal:** Logged-in user can type a task, see it appear on the dashboard, mark it Complete or Defer. Forgiveness Protocol enforced everywhere. First Capture Badge fires on first task.

**Prerequisites:** M3 complete

**Spec references:** `04-mysql-schema.md` §4.5–4.6, §4.8, §4.15; `02-design-system.md` §9.4 (TaskCard, PriorityBadge); `03-onboarding-flow.md` §3

### Tasks

#### 4.1 Schema Additions
```
- Add to Prisma schema:
  - tasks
  - task_steps
  - badges (table for definitions)
  - user_badges
  - events (append-only log)
- pnpm prisma migrate dev
- Seed badges table (first_capture, first_step, first_focus, first_complete, etc.)
- See 04-mysql-schema.md §8 for seed data
```

#### 4.2 Task Domain Logic
```
packages/domain/src/tasks/:

- create-task.ts (input → tasks row + event log)
- complete-task.ts (status active → completed, badge check)
- defer-task.ts (status → deferred, increment deferred_count silently)
- list-active-tasks.ts (dashboard query, see schema doc §7.1)

Each function:
  - Pure logic, no UI
  - Returns typed Result<T, E>
  - Records to events table
  - Triggers badge engine check
```

#### 4.3 Badge Engine
```
packages/domain/src/badges/:

- check-and-award.ts (subscribe to events, award badges)
- get-user-badges.ts
- The engine reads from events table, not feature tables
- First Capture badge: fires on first task.created event for user
- Idempotent — running twice doesn't double-award
```

#### 4.4 Server Actions
```
apps/web/server-actions/tasks/:

- create-task.ts
- complete-task.ts
- defer-task.ts (with optional "defer until" datetime)
- update-task-priority.ts

All call domain functions, handle authentication, return typed results.
```

#### 4.5 Dashboard Page
```
- apps/web/app/(app)/page.tsx (the post-login landing)
- Shows:
  - User's display name (using getUserAddressName fallback per doc 01 §2.5)
  - List of active tasks (single column)
  - "Capture another thought" input at top
  - Empty state if no tasks (per spec §11.1)
- Cross-device sync via 5-second polling (M4 sets this up; reused later)
```

#### 4.6 TaskCard Component
```
- packages/ui/src/components/TaskCard.tsx
- Shows: title, priority pill, scheduled time if any, step progress
- Actions: "Done. Next step." / "Push to later"
- NO red, NO "delete," NO "overdue"
```

#### 4.7 Cross-Device Sync (Short Polling)
```
Per doc 04 §5 — chosen over SSE for Vercel free-tier compatibility:

- apps/web/app/api/sync/route.ts (returns events newer than ?since= timestamp)
- apps/web/lib/sync/use-sync-stream.ts (client hook with 5s polling interval)
- Pauses when document.hidden === true
- Resumes immediately when tab regains focus
- Updates Zustand store on new events
- Optimistic UI: local state updates immediately, sync is for cross-device only
```

### Tests Required

```
Unit tests:
  - create-task: validates input, creates row, logs event
  - complete-task: respects ENUM values, awards First Complete badge first time
  - defer-task: increments counter silently, never visible to user
  - Badge engine: idempotent, fires correct badges

Integration tests:
  - POST to create-task action: full round-trip
  - Dashboard page loads tasks for current user only
  - /api/sync endpoint returns events filtered by since param

E2E tests (Playwright):
  - User logs in → captures first task → sees First Capture Badge toast
  - User completes task → sees First Complete badge
  - User defers task → it disappears from dashboard, reappears at deferred time
  - Two browser tabs: change in one, appears in other within 3 seconds
```

### Acceptance Criteria

- [ ] User can capture a task via text input
- [ ] Task appears immediately on dashboard
- [ ] First Capture Badge fires on first task creation, only once
- [ ] User can mark task complete → "Done. Next step." → animation plays
- [ ] User can defer task → removed from view, no shame language
- [ ] Status enum cannot be set to "failed" (TS error)
- [ ] Priority enum cannot be set to "urgent" or "red" (TS error)
- [ ] Dashboard query returns in <100ms with 1000 tasks (load test)
- [ ] Polling sync keeps two tabs aligned within 7s (5s poll + 2s grace)
- [ ] No red colors anywhere
- [ ] Empty state per design system spec
- [ ] All tests pass
- [ ] axe-core 0 violations

### Manual Smoke Test (Human)

1. Log in → land on empty dashboard with empty state
2. Type "Buy oranges" → press Enter → see TaskCard appear
3. See First Capture Badge toast
4. Mark complete → animation, task moves out
5. Add task, defer for 1 hour → it disappears, reappears after 1 hour
6. Open second tab → both stay in sync

### ✅ PAUSE POINT — End of M4

The core loop works. Every subsequent milestone extends from here.

---

## Milestone 5: Walk Me Through It

**Goal:** When user has multi-step task, they can enter a focused single-step mode that hides all other UI.

**Prerequisites:** M4 complete

**Spec references:** `Detailed_ADHD_Forge_Document.pdf` §3.1; `Comprehensive_Multidisciplinary_Framework_*.pdf` §9 Tool 2

### Important Framing Note

M5 ships with **manual step creation**. AI-generated steps arrive in M7. During the M5–M7 window:

- The UI does NOT promise AI-generated steps yet
- Button copy: "Add steps manually" (not "Generate steps")
- The "Walk Me Through It" feature works on whatever steps exist (manual or AI, whatever's available)
- Help text on the empty state: "You can add steps yourself for now. Voice-driven step generation coming soon."

This avoids overpromising during the gap. M7 enhances rather than replaces.

### Tasks

#### 5.1 Manual Step Creation
```
- Edit task UI: "Add steps manually" button
- User can manually add ordered steps to a task
- packages/domain/src/tasks/add-step.ts
- packages/domain/src/tasks/complete-step.ts
- packages/domain/src/tasks/reorder-steps.ts
- Drag-to-reorder UX (large touch targets, mobile-friendly)
```

#### 5.2 Walk-Through UI
```
- apps/web/app/(app)/walk/[taskId]/page.tsx
- Full-screen, single-column, hides nav
- Shows ONE step at a time
- Big "Done. Next step." button
- "Pause" button returns to dashboard, preserves position
- ESC key acts as Pause
```

#### 5.3 First Step Badge
```
- Add to events: task_step.completed
- Badge engine: first_step badge fires on first step completion
```

### Tests Required

```
Unit:
  - add-step: validates order, returns step
  - complete-step: marks complete, awards badge
  - Step ordering remains stable on completion

E2E:
  - User adds 3 steps to task → enters walk-through → completes each → returns to dashboard
  - User pauses mid-walk → resumes → starts at correct step
  - User completes all steps → task auto-completes → First Complete badge
```

### Acceptance Criteria

- [ ] User can add steps to a task manually
- [ ] Walk-through mode shows one step at a time
- [ ] No other UI visible in walk-through
- [ ] First Step badge fires correctly
- [ ] ESC pauses
- [ ] Mobile-friendly (works in PWA, drag-to-reorder works)
- [ ] No copy promises AI generation yet (that arrives in M7)
- [ ] All tests pass

### Manual Smoke Test (Human)
1. Add 3 steps to a task manually
2. Click "Walk Me Through It"
3. Complete each step in turn
4. Confirm dashboard shows task complete

### ✅ PAUSE POINT — End of M5

---

## Milestone 6: Analog Timer

**Goal:** User can start a timer with a diminishing wedge visual, optional Sound Family alerts, and Picture-in-Picture pop-out.

**Prerequisites:** M5 complete

**Spec references:** `Detailed_ADHD_Forge_Document.pdf` §3.2; `Comprehensive_Multidisciplinary_Framework_*.pdf` §4

### Tasks

#### 6.1 Timer Domain Logic
```
packages/domain/src/timer/:
- focus-session.ts (start/pause/resume/end)
- sound-families.ts (definitions)
```

#### 6.2 Schema
```
Add to Prisma:
- focus_sessions (per schema doc §4.12)
```

#### 6.3 AnalogTimer Component
```
packages/ui/src/components/AnalogTimer.tsx:
- SVG-based wedge that diminishes
- Color zones (yellow → green → mauve as time elapses)
- Smooth animation, respects prefers-reduced-motion
- Configurable duration (15/25/45 min presets + custom)
```

#### 6.4 Sound Family System
```
- Pre-recorded audio files in apps/web/public/sounds/families/
- soft_chimes/ (variations 1-5)
- singing_bowls/ (variations 1-5)
- pink_noise_pulse/ (variations 1-3)
- Random selection on each interval to prevent habituation
- No two consecutive selections from the same family use the same variation
```

#### 6.5 Tactile/Vibration Cues (Mobile)
```
Per Comprehensive_Multidisciplinary_Framework §4 — vibration prompts mentioned 
alongside audio in original spec but not previously tracked:

- packages/domain/src/timer/vibration-patterns.ts (define patterns)
- Use navigator.vibrate() for pattern-based haptic feedback on supported devices
- User preference: "haptic_feedback" boolean (default ON for mobile, ignored on desktop)
- Patterns:
  - interval_chime: [200] (single short pulse)
  - timer_complete: [200, 100, 200, 100, 400] (celebration pattern)
  - body_check_in_prompt: [100] (gentle nudge)
- Falls back silently on browsers without Vibration API
- Honors prefers-reduced-motion (vibration considered motion for some users)
- Sound and vibration are independently toggleable in settings
```

#### 6.6 Picture-in-Picture
```
- "Pop out" button uses documentPictureInPicture API
- Falls back to a normal floating window if API unavailable
- Pop-out shows minimal timer UI only
```

#### 6.7 First Focus Badge
```
- Event: focus_session.started → first_focus badge
- Event: focus_session.completed → focus_complete badge (repeatable)
```

### Tests Required

```
Unit:
  - Timer start/pause/resume/end state transitions
  - Sound family selection randomness (no consecutive repeats)
  - Wedge percentage calculation accuracy
  - Vibration pattern selection respects user preference

Integration:
  - focus_sessions row created on start, updated on end
  - Badge fires correctly

E2E:
  - User starts 30-second timer → wedge animates → completes → badge
  - User pops out timer → floating window appears
  - User pauses, resumes, completes
  - Vibration triggered on mobile (manual test only — Playwright can't verify haptics)
```

### Acceptance Criteria

- [ ] Three preset durations + custom
- [ ] Visual wedge accurate to ±1 second
- [ ] Sound Family cycles variations correctly (no two consecutive same)
- [ ] Vibration patterns fire on mobile devices that support Vibration API
- [ ] Sound and vibration toggle independently in settings
- [ ] prefers-reduced-motion disables vibration (per design system clarification)
- [ ] Picture-in-Picture works in Chrome/Edge
- [ ] Fallback floating window in Safari/Firefox
- [ ] Mobile: timer works in foreground
- [ ] First Focus and Focus Complete badges fire
- [ ] All tests pass

### Manual Smoke Test (Human)
1. Start 25-min timer → see wedge animate
2. Pop out → floating window, return to other tabs
3. Wait for completion → hear sound, see badge
4. On mobile: feel vibration on completion
5. Toggle "Disable haptics" in settings → no more vibrations

### ✅ PAUSE POINT — End of M6

---

## Milestone 7: Voice Dump + AI Parsing

**Goal:** User can hold a button to record audio, which is transcribed via Whisper and parsed into structured tasks via GPT-4o-mini.

**Prerequisites:** M6 complete

**Spec references:** `ADHD_Forge_Tech_Specs.pdf` §2; `Detailed_ADHD_Forge_Document.pdf` §3.1; `01-authentication-and-user-model.md` §11.2

### Tasks

#### 7.1 OpenAI Integration
```
packages/ai/src/:
- whisper-client.ts (transcription)
- gpt-task-parser.ts (text → structured tasks)
- prompts/task-parsing.ts (the actual prompt)

The task-parsing prompt must:
- Extract distinct tasks from messy text
- Suggest priority (bronze/silver/gold/amber — never urgent)
- Suggest steps if task is complex
- Detect time references ("tomorrow at 3pm")
- Return JSON matching strict schema
```

#### 7.2 Audio Recording
```
- packages/ui/src/components/VoiceDumpButton.tsx
- Hold-to-record using MediaRecorder API
- Visual feedback: pulsing waveform during recording
- Falls back silently to text input if mic denied
```

#### 7.3 Audio Upload Flow
```
- POST /api/voice-dump (multipart upload)
- Audio sent to Whisper
- Audio deleted immediately after transcription
- Transcript sent to GPT-4o-mini for parsing
- Parsed tasks created in DB
- Audio NEVER persisted (per spec)
```

#### 7.4 Quota Enforcement (Build Now, Used Now and at M16)
```
- quota_usage table already in schema from M1 (per doc 04 §4.17)
- Implement checkQuota() and incrementQuota() per doc 05 §4.3-4.4
- Quota keys used in M7: 'voice_dump' (10/day free), 'ai_breakdown' (5/day free)
- Use canonical feature_key registry from doc 04 §4.7
- "Quota reached" UI per doc 05 §5
- All users get free-tier quotas (paid tier doesn't exist yet — this is fine)
- Reset works automatically via usage_date_utc — no cron needed
- UI displays reset time in user's local timezone
```

### Tests Required

```
Unit:
  - Task parser handles multiple tasks, single task, ambiguous text
  - Whisper client error handling
  - Quota check fail-open behavior (DB error → allow request)
  - Atomic increment prevents double-counting
  - Reset time conversion: UTC 04:00 → user's local time string

Integration:
  - POST /api/voice-dump → tasks created (mock OpenAI)
  - Quota increments correctly with ON DUPLICATE KEY UPDATE
  - Quota reached → returns 429 with reset time in user's timezone
  - usage_date_utc rolls over at 04:00 UTC boundary (test with mocked time)

E2E:
  - User records 5-second audio → tasks appear on dashboard
  - User records 11 times → 11th shows quota UI with "Type instead"
  - Quota UI displays user's local reset time correctly
```

### Acceptance Criteria

- [ ] Voice recording works in Chrome, Safari, Firefox
- [ ] Whisper transcription succeeds
- [ ] GPT-4o-mini returns valid JSON
- [ ] Audio file deleted within 60s of transcript receipt
- [ ] Quota enforced at 10/day for free users (voice_dump)
- [ ] Quota enforced at 5/day for free users (ai_breakdown)
- [ ] Quota resets at 04:00 UTC, displayed as user's local time
- [ ] Quota check fails open if DB unavailable
- [ ] Mic permission denied → silent fallback to text
- [ ] All tests pass

### Manual Smoke Test (Human)
1. Hold mic button, say "Email Sarah back, get groceries, and book the dentist"
2. See three tasks appear
3. Use voice dump 11 times → see quota UI showing local reset time
4. Wait until next 04:00 UTC → quota resets (verify via UI counter)

### ✅ PAUSE POINT — End of M7

---

## Milestone 8: Reverse Scheduler / Doorknob

**Goal:** User inputs an arrival time, transit duration, and pre-departure tasks. The app calculates backward and shows color-coded zones with a "+15 min" recalculator.

**Prerequisites:** M7 complete (uses AI for task parsing of "I need to leave at 3pm" inputs)

**Spec references:** `Detailed_ADHD_Forge_Document.pdf` §3.2; `Comprehensive_Multidisciplinary_Framework_*.pdf` §5

### Tasks

#### 8.1 Doorknob Domain Logic
```
packages/domain/src/doorknob/:
- calculate-schedule.ts (arrival - transit - tasks = start time)
- recalculate-late.ts (push entire schedule +15 min)
- zones.ts (yellow/green/mauve color logic)
```

#### 8.2 DoorknobTimeline Component
```
packages/ui/src/components/DoorknobTimeline.tsx:
- Horizontal timeline (special case from single-column rule)
- Color-coded zones per spec
- Current position indicator
- "+15 min" button
```

#### 8.3 Doorknob Setup Flow
```
- apps/web/app/(app)/doorknob/page.tsx
- Step 1: When do you need to be there?
- Step 2: How long is the trip?
- Step 3: Select pre-departure tasks (from Launchpad in M9, or freeform now)
- Result: full timeline shown
```

#### 8.4 Scheduled Alerts
```
Add to schema: scheduled_alerts (per §4.14)
- Cron job (Vercel Cron) fires alerts at zone transitions
- Browser notifications (with permission)
```

### Tests Required

```
Unit:
  - calculateSchedule correct for various inputs
  - recalculateLate adds 15 min to all downstream
  - Zone boundaries correct

E2E:
  - User creates Doorknob session → timeline displays
  - Click "+15 min" → all zones shift correctly
  - Browser notification at zone transition (mock)
```

### Acceptance Criteria

- [ ] Backward calculation correct
- [ ] Color zones match spec
- [ ] +15 button works in 1 click
- [ ] Scheduled alerts fire on time
- [ ] All tests pass

### ✅ PAUSE POINT — End of M8

---

## Milestone 9: Launchpad

**Goal:** User has a checklist of items by the door. Resets daily at user-defined time.

**Prerequisites:** M8 complete

**Spec references:** `Comprehensive_Multidisciplinary_Framework_*.pdf` §5; `04-mysql-schema.md` §4.11

### Tasks

#### 9.1 Schema + Domain
```
- launchpad_items table per §4.11
- Domain: add-item, check-item, reorder-items, reset-daily
- Vercel Cron: daily reset job (runs at 04:00 in each timezone — group by tz)
```

#### 9.2 Launchpad UI
```
- apps/web/app/(app)/launchpad/page.tsx
- Add to dashboard: launchpad summary widget
- Integrate with Doorknob: select Launchpad items as pre-departure tasks
```

#### 9.3 Nightly Reminder
```
- Scheduled alert: "Time to set up tomorrow's launchpad"
- User-configurable time (default 21:00 local)
```

### Tests Required

```
Unit:
  - Daily reset only resets items where reset_schedule = 'daily'
  - Timezone handling for reset time

E2E:
  - User adds Keys, Wallet, Lunch
  - Checks them off
  - At 04:00 local time, all unchecked again
```

### Acceptance Criteria

- [ ] Items persist across sessions
- [ ] Daily reset fires at correct local time
- [ ] Nightly reminder works
- [ ] Integrates with Doorknob mode

### ✅ PAUSE POINT — End of M9

---

## Milestone 10: Praise Repository

**Goal:** Users can invite trusted contacts (max 5 free), who can record voice memos. Free tier: 3 active memos, 15 plays/day. Pro tier: unlimited memos, 30 plays/day, AI transcripts included.

**Prerequisites:** M9 complete

**Spec references:** `Comprehensive_Multidisciplinary_Framework_*.pdf` §8; `04-mysql-schema.md` §4.9-4.10; `01-authentication-and-user-model.md` §10; `05-monetization-strategy.md` §2.1-2.2

### Tasks

#### 10.1 Trusted Contacts
```
- Schema: trusted_contacts table per doc 04 §4.10
- /account/praise-senders page
- User generates an invite link with a default sender display name
  (e.g., "Mom", "Sarah from work")
- Generate unique invite link with signed token (256-bit)
- 5-contact free limit (Pro: unlimited)
- User can revoke a sender at any time, deleting their memos
```

#### 10.2 Sender Flow (No Account Needed)
```
- /praise/[token] page (public route)
- Sender sees the display name the user set; can confirm or correct it
- The recipient's name takes precedence in case of ambiguity (per doc 01 §10.2)
- Sender records up to 3 memos within 7 days of first use
- Audio uploaded to Cloudflare R2 storage (not Vercel Blob)
- Token expires 7 days after first use OR after 3 memos
- Sender IP logged briefly for rate-limit abuse detection, discarded after 24h
- Sender's email is NOT collected
```

#### 10.3 Recipient Flow
```
- /praise inbox page
- Memo cards with playback, speed controls (1x, 1.25x, 1.5x)
- Categories: "Listen when overwhelmed", "Before a big task", "After a failure"
- AI transcription gated behind Pro tier (free users see audio only, with 
  a soft note: "Transcripts are a Pro feature")
- 3-active-memo free limit (oldest archived when adding 4th)
- Pro: unlimited memos, no archival
```

#### 10.4 Audio Storage on Cloudflare R2
```
Per doc 04 — using Cloudflare R2 (not Vercel Blob):

- @aws-sdk/client-s3 package (R2 is S3-compatible)
- Signed URLs valid 1 hour
- File size limit: 60 seconds max per memo
- Files stored in private bucket: focus-forge-praise-{env}
- Audio served via signed URL only — never public

CONFIG (Human action):
1. Sign up for free Cloudflare account (no credit card required)
2. Create R2 bucket: focus-forge-praise-prod
3. Generate API token with R2 read/write scope
4. Configure CORS to allow uploads from Vercel domain
5. Add R2_ACCOUNT_ID, R2_ACCESS_KEY_ID, R2_SECRET_ACCESS_KEY,
   R2_BUCKET_NAME to .env.local and Vercel env vars
```

#### 10.5 Play Quotas
```
Per doc 05 §2.1-2.2:

- Quota key: 'praise_play'
- Free tier: 15 plays per day total (any combination of memos)
- Pro tier: 30 plays per day total
- Increment happens on play_started event
- When quota reached, show approved soft message:
  "Take a breath. Come back tomorrow if you still need to listen.
   Your memos will be here."
- NEVER frame this as "you're using this too much" - clinical safeguard
```

#### 10.6 Reactive Moderation (Reports Only)
```
Per doc 01 §10 and doc 04 §4.29 — Option A reactive moderation:

- "Report this memo" button on each memo card (recipient side)
- Opens modal: reason category (inappropriate | harassment | spam | other),
  details textarea
- Creates content_reports row with:
  - reporter_user_id = current user
  - content_type = 'praise_memo'
  - content_id = memo id
  - reason_category, reason_details
  - status = 'pending_review'
- Memo is HIDDEN from the recipient's inbox immediately on report
  (they don't have to keep seeing it while admin reviews)
- Memo is NOT deleted — admins need to review the actual content
- If report is later resolved as 'no action needed', memo can be restored
  (admin action with justification)

Privacy boundary:
- Admins can ONLY access memo content for reports with status 'pending_review' or 'reviewing'
- Access via signed URL valid 30 minutes, regenerated per access
- Each access logs admin_actions row with action='content.review_memo'
- No persistent admin access to praise audio outside active reports
```

### Tests Required

```
Unit:
  - Token signing/verification
  - 5-contact, 3-memo (free), unlimited (paid) limit enforcement
  - 60-second audio length validation
  - Sender display name precedence logic (recipient wins)
  - Report submission creates content_reports row
  - Reported memo hidden from recipient inbox

Integration:
  - Sender flow end-to-end (mock R2 storage)
  - Recipient sees new memos within 7 seconds via polling sync
  - Audio upload to R2 with correct CORS
  - Signed URL generation
  - Play quota: 15 plays succeed for free user, 16th blocked with soft message
  - Play quota: 30 plays succeed for paid user, 31st blocked
  - Admin with admin_content_moderation can access reported memo audio
  - Admin without that permission cannot access memo audio (404)
  - Each admin access logged in admin_actions
  - Resolved 'no action' report restores memo visibility

E2E:
  - User creates invite with name "Mom" → opens in incognito 
    → sender sees "Mom" pre-filled → records → user receives memo
  - User has 3 memos → 4th memo arrives → oldest auto-archived
  - Free user plays memos 15 times → 16th attempt shows soft cap message
```

### Acceptance Criteria

- [ ] Invite links work without sender account
- [ ] 5-contact free limit enforced (paid: unlimited)
- [ ] 3-memo free limit enforced with auto-archival of oldest
- [ ] 60-second per-memo length limit enforced
- [ ] 15-plays/day free, 30-plays/day paid
- [ ] Audio stored privately on Cloudflare R2 (not Vercel Blob)
- [ ] Signed URLs expire correctly (1 hour)
- [ ] Speed controls work (1x, 1.25x, 1.5x)
- [ ] AI transcription gated to Pro (free users see audio with soft Pro note)
- [ ] Sender abuse detection (rate limit by IP on token page)
- [ ] Sender display name precedence: recipient's setting wins
- [ ] Play cap message uses approved soft language (no shame framing)

### ✅ PAUSE POINT — End of M10

---

## Milestone 11: Body Doubling (Jitsi)

**Status:** ✅ Decision locked — Jitsi Public Instance, Pro tier only.

**Goal:** Pro users can join 24/7 silent co-working rooms with synchronized Pomodoro timer.

**Prerequisites:** M10 complete (note: M11 doesn't depend on M10 functionally; sequenced this way for milestone discipline)

**Spec references:** `Comprehensive_Multidisciplinary_Framework_*.pdf` §7; `05-monetization-strategy.md` §8

### Tasks

#### 11.1 Pro Tier Gate
```
- /co-work page (Pro-gated)
- Free users see informational page explaining the feature with soft Pro CTA
  per doc 03 §5.1 — never shame-framed
- Use feature_gates.userHasFeature(userId, 'body_doubling') to check access
```

#### 11.2 Jitsi Iframe Integration
```
- Use lib-jitsi-meet or @jitsi/react-sdk for iframe embedding
- Domain: meet.jit.si (free public instance)
- Room naming: focusforge-{roomId}-{themeName} 
  (namespaced to prevent collision with random Jitsi rooms)
- Default config:
  - startWithAudioMuted: true
  - startWithVideoMuted: false
  - prejoinPageEnabled: false (skip Jitsi's prejoin)
  - disableModeratorIndicator: true
  - hideRecordingLabel: true
- User cannot record (disabled in config)
```

#### 11.3 Themed Drop-In Rooms
```
- 5 always-on rooms, themed per Comprehensive Framework §7:
  - "Silent Cafe" (warm, casual atmosphere)
  - "Library Quiet" (focused, formal)
  - "Cozy Living Room" (relaxed)
  - "Office Hours" (professional)
  - "Late Night Owl" (for night workers)
- Each is a virtual Jitsi room with our custom UI overlay
- /co-work shows room list with current participant counts
- Click → joins room with mic-off, blur-on by default
```

#### 11.4 Synchronized Pomodoro Overlay
```
- Custom React overlay on top of Jitsi iframe
- Shared timer visible to all participants in the room
- Stored in MySQL: room_pomodoro_state table
  - room_id, current_phase (work|break), phase_started_at, duration
- Polled by all participants every 5s (uses existing sync infrastructure)
- Anyone can start a new pomodoro; everyone sees it
- Timer is INDEPENDENT of Jitsi — it's our own UI
```

#### 11.5 Sensory Controls
```
- Quiet Mode toggle (default ON): mic stays muted, no auto-unmute
- Blur background toggle (default ON): uses Jitsi's built-in blur
- Hide self-view toggle (default OFF): hides own tile from grid
- Dim incoming video toggle (CSS opacity reduction): for sensory overload
```

#### 11.6 Reporting & Moderation (Unified content_reports)
```
Per doc 04 §4.29 — body doubling reports use the unified content_reports table:

- "Report user" button in participant menu
- Report modal: reason category, reason details
- Creates content_reports row with:
  - reporter_user_id = current user
  - reported_user_id = (NULL — we only have target_jitsi_id, not our user_id)
  - content_type = 'body_doubling_session'
  - content_id = room_key + jitsi_session_id (composite, stored in metadata)
  - reason_category, reason_details
  - status = 'pending_review'

Privacy boundary:
- We CANNOT review video/audio content — Jitsi controls that, not us
- Admin review consists of: examining reports against the same target,
  pattern-matching repeat offenders
- Action options: warn user, pause user, ban from body doubling specifically
  (revoke 'body_doubling' feature_grant)
- All admin decisions logged in admin_actions

Three-strike heuristic (admin discretion, not automated):
- 3+ reports against same user within 30 days → admin notified for review
- Admin reviews report context, can pause user pending investigation
```

#### 11.7 Schema Addition
```sql
-- Add to Prisma schema (only room_pomodoro_state — body_doubling_reports
-- is REPLACED by the unified content_reports table from doc 04 §4.29)

CREATE TABLE room_pomodoro_state (
  id              VARCHAR(30)   NOT NULL PRIMARY KEY,
  room_key        VARCHAR(80)   NOT NULL,        -- 'silent_cafe', etc.
  current_phase   ENUM('work', 'break', 'idle') NOT NULL DEFAULT 'idle',
  phase_started_at TIMESTAMP(3) NULL DEFAULT NULL,
  phase_duration_seconds INT UNSIGNED NULL DEFAULT NULL,
  started_by_user_id VARCHAR(30) NULL DEFAULT NULL,
  
  updated_at      TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  
  UNIQUE KEY uq_room (room_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

**Note:** the originally-planned `body_doubling_reports` table is replaced by `content_reports` (doc 04 §4.29) which unifies the moderation queue across praise memos and body doubling. Single workflow, single admin UI.

### Tests Required

```
Unit:
  - Feature gate check (Pro vs free)
  - Pomodoro state transitions
  - Room state polling logic

Integration:
  - Free user accessing /co-work sees Pro CTA, not iframe
  - Pro user can load Jitsi iframe with correct config
  - Pomodoro state syncs across simulated participants

E2E:
  - Pro user joins room → sees Jitsi iframe with mic muted
  - Two Pro users in same room → both see same Pomodoro state
  - Free user attempts /co-work → sees Pro feature info (soft framing)
  - User reports another participant → row appears in content_reports with content_type='body_doubling_session'
```

### Acceptance Criteria

- [ ] /co-work route exists, gated by 'body_doubling' feature_grant
- [ ] Jitsi iframe loads with mic muted, blur on by default
- [ ] 5 themed rooms always available
- [ ] Synchronized Pomodoro timer visible to all participants
- [ ] Quiet Mode, blur, hide self-view, dim incoming all work
- [ ] Report button creates row in content_reports (unified moderation queue)
- [ ] Free users see soft Pro upsell (no shame language)
- [ ] No Jitsi-specific recording functionality enabled
- [ ] All tests pass

### Manual Smoke Test (Human)
1. As Pro user, visit /co-work → see 5 themed rooms
2. Join "Silent Cafe" → Jitsi iframe loads, mic muted by default
3. Open in second browser → both users see each other
4. Start Pomodoro from one tab → other tab updates within 5 seconds
5. As free user, visit /co-work → see Pro feature info, no iframe

### ✅ PAUSE POINT — End of M11

---

## Milestone 12: Body Check-Ins

**Goal:** During focus sessions ≥60 minutes, gentle prompts ask about water, tension, posture.

**Prerequisites:** M6 complete (uses focus_sessions); can be done anytime after M6

**Spec references:** `Comprehensive_Multidisciplinary_Framework_*.pdf` §9 Tool 1; `04-mysql-schema.md` §4.13 (table) and §8.1 (prompt library)

### Tasks

```
- Schema: check_ins table already in M1 (per doc 04 §4.13)
- Use prompt library from doc 04 §8.1 (CHECK_IN_PROMPTS array)
- Random selection at each check-in firing
- Non-blocking toast notification during long sessions
- Default ON for sessions ≥60 min, configurable per user
- Settings: enable/disable, opt out of bathroom prompts
- Bathroom prompt limited to once per 4 hours per user
- No prompt repeats within same focus session
- Default firing interval: every 30 minutes during sessions ≥60 min
```

### Tests
- Prompt fires at correct interval (mock timers)
- Random selection avoids repeats within session
- Bathroom prompt rate limit (once per 4h)
- Response captured to check_ins table
- Session ends → no more prompts queued
- Badge: check_in_yes fires on first 'yes'/'no' response (any non-dismiss)
- Disabled in settings → prompts never fire

### ✅ PAUSE POINT — End of M12

---

## Milestone 13: Decision Paralysis Breaker

**Goal:** When user has 3+ tasks and hasn't started one in 24 hours, surface a "Help Me Decide" prompt that uses AI to pick 2 options.

**Prerequisites:** M7 complete (uses AI)

**Spec references:** `Comprehensive_Multidisciplinary_Framework_*.pdf` §9 Tool 2

### Tasks

```
- Detection logic: 3+ active tasks, no task completion in 24h
- "Help Me Decide" button on dashboard
- AI prompt: given task list, return 2 micro-step recommendations
- Quota: 3/day free
- Modal UI: two big buttons with the recommended steps
- Selecting one creates a task_step and enters Walk-Through mode
```

### Tests
- Trigger correctness
- AI returns exactly 2 options
- Quota enforcement
- Selection flows into Walk-Through

### ✅ PAUSE POINT — End of M13 — End of Phase 2

All features functional. Pre-launch hardening begins.

---

# PHASE 3: LAUNCH PREP

## Milestone 14: Onboarding Flow + First-Session Experience

**Goal:** New users complete the full onboarding per spec, including First Capture, badge surfacing, welcome email, and Phase 3 progressive discovery.

**Prerequisites:** M4–M13 complete

**Spec references:** `03-onboarding-flow.md` (entire doc)

### Tasks

```
- /welcome page (post-signup landing)
- First-capture flow per spec §3
- First Capture Badge fires within 500ms of task creation 
  (NOT dependent on AI parsing completion — fail open)
- Discovery card system
  - Pro features surfaced with soft "this is Pro" framing 
    (per doc 03 §5.1 update — never shame-framed)
- Returning-user logic per spec §8
  - NO Day 3 re-engagement email (removed per audit)
  - NO "we miss you" emails ever
- Telemetry events per spec §9
- Skip path on every step
- Email verification banner (non-blocking)

#### 14.1 Welcome Email (Transactional, NOT Re-Engagement)
- Triggered by 'user.signed_up' event, sent within 5 minutes
- Subject: "Your Focus Forge account is ready"
- Body (plain, no marketing):
  "Hi [name],

  Your Focus Forge account is set up and ready.

  Whatever brought you here — burnout, frustration with other tools,
  curiosity — we hope this helps.

  Sign in: https://focusforge.app/signin

  If you have questions, reply to this email.

  — Focus Forge"
- Sent via Resend
- This is the ONLY transactional onboarding email
- No drip sequence, no follow-up emails, no re-engagement

#### 14.2 Display Name Resolution (per doc 01 §2.5)
- Implement getUserAddressName(user) utility
- Used everywhere the UI greets the user
- Fallback chain: explicit display_name → OAuth name → email local part → "you"
```

### Tests
- Full first-touch flow under 90 seconds
- First Capture Badge fires immediately (not gated on AI completion)
- Skip path bypasses without errors
- Discovery cards trigger correctly per updated table (Pro features properly framed)
- No re-engagement emails sent at any point after welcome
- Returning user experience contains no shame language
- Display name fallback chain works end-to-end
- Welcome email sent on signup (mock Resend)

### Acceptance Criteria

- [ ] All §12 acceptance criteria from 03-onboarding-flow.md met
- [ ] First Capture Badge fires within 500ms of task creation
- [ ] AI parsing failure does NOT block badge or task display
- [ ] Welcome email sent exactly once per signup
- [ ] No emails sent at Day 3, Day 7, Day 30, or any other re-engagement window
- [ ] Pro features in discovery cards use soft framing (verified by content review)

### ✅ PAUSE POINT — End of M14

---

## Milestone 15: PWA + Offline + Static Pages + Production Hardening

**Goal:** App is installable as PWA on mobile, core features work offline, all static pages (About, References, legal) are live, CI link checker is running, and production is ready for real users.

**Prerequisites:** M14 complete

**Spec references:** `08-page-content-and-references.md` (entire doc)

### Tasks

#### 15.1 PWA Manifest
```
- public/manifest.json with icons, theme colors, name
- next.config.mjs with next-pwa or built-in PWA support
- Service worker for offline support
```

#### 15.2 Offline Support
```
- Cache: dashboard, active tasks, timer, design system
- Queue: task creation, completion (sync when online)
- Offline banner: "Working offline. Changes will sync."
```

#### 15.3 Account Settings (Full)
```
- Data export (JSON download)
- Delete account flow with 30-day grace
- Theme toggle
- Sound family preference
- Notification preferences
- Linked auth methods
- Settings → About link (jumps to /about)
```

#### 15.4 Static Pages — About, References, Legal
```
Per spec 08-page-content-and-references.md:

a) Reference Data Source
   - Create apps/web/data/references.json with all 75 references
     categorized per spec §3.2
   - Validate against TypeScript schema from spec §3.1
   - Each foundational/supporting reference has annotation

b) About Page
   - apps/web/app/about/page.tsx
   - Content from spec §4.1 (markdown source of truth)
   - Single column, max-w-65ch, design system tokens
   - Links to /about/references

c) References Page
   - apps/web/app/about/references/page.tsx
   - Renders categorized references with disclaimer (spec §2.2)
   - ReferenceCard component per spec §2.3
   - Search/filter input (client-side, instant)
   - All external links: target="_blank" rel="noopener noreferrer"
   - Small external-link icon next to each title
   - "Last updated: [date]" displays from references.json
   - Display weight indicator subtly (e.g., foundational refs slightly emphasized)

d) Footer Component
   - packages/ui/src/components/Footer.tsx
   - Layout per spec §5.1
   - Links per spec §5.2
   - Tagline per spec §5.3
   - Persistent on all non-auth pages
   - Auth pages keep minimal/no footer

e) Legal Pages
   - apps/web/app/privacy/page.tsx (Privacy Policy)
   - apps/web/app/terms/page.tsx (Terms of Service)
   - apps/web/app/refunds/page.tsx (Refund Policy)
   - Use Termly/Iubenda generated content for v1
   - Single column, design system tokens
```

#### 15.5 CI Link Checker
```
Per spec 08-page-content-and-references.md §6:

- Create .github/workflows/check-references.yml per spec §6.2
- Create scripts/post-link-check-results.js for result handling
- Configure result handling per spec §6.3:
  - Scheduled (weekly): opens GitHub issue if broken links found
  - PR (when references.json changes): comments with results, fails on NEW breaks
  - Manual: console output
- Test with deliberately broken URL (should be caught and flagged)
- Update references.json lastUpdated field on each successful run
```

#### 15.6 Production Hardening
```
- Sentry error tracking (free tier) with PII scrubbing rules:
  - sendDefaultPii: false (do NOT capture user emails, IPs by default)
  - Custom beforeSend hook to redact:
    - Voice Dump audio data (NEVER transmitted)
    - Praise memo content (NEVER transmitted)
    - Praise memo transcripts (redact 'transcript' fields)
    - User-typed task content (redact 'rawText', 'title', 'notes' fields)
    - Auth tokens, session IDs (redact any field matching /token|secret|password/i)
  - User context: only include user ID (no email, no name)
- Vercel Analytics (free, privacy-respecting)
- Rate limiting on all API routes:
  - Auth endpoints: 5/15min per email
  - Voice Dump: 10/day per user (matches quota)
  - Other write endpoints: 60/min per user
- Content Security Policy headers (strict, no inline scripts)
- HSTS, X-Frame-Options, X-Content-Type-Options
- robots.txt allowing all major search engines
- sitemap.xml including /about, /about/references, all public legal pages
```

#### 15.7 Mobile App Strategy (PWA Only For v1)
```
Per discussion notes — "build mobile apps on github" was clarified as PWA-only for v1:

- App is a Progressive Web App, installable on iOS and Android
- Native iOS/Android apps are FUTURE work, not in this roadmap
- The monorepo apps/mobile folder is reserved for future React Native or Expo build
- For v1, ship PWA with proper manifest:
  - Installable from browser "Add to Home Screen"
  - App icons for all required sizes
  - Splash screens
  - Standalone display mode
  - Proper theme color matching dark mode
```

#### 15.8 Performance Audits
```
- Lighthouse score ≥90 on all key pages
- Core Web Vitals: LCP <2.5s, FID <100ms, CLS <0.1
- Database query performance: dashboard <100ms
- Reference page initial render <1s (75 entries should not slow page)
```

### Tests Required

```
Unit tests:
  - References JSON validates against TypeScript schema
  - Reference card component renders all reference types
  - Search/filter logic correctly matches title, publisher, annotation
  - Footer renders correct links
  - Sentry beforeSend correctly redacts sensitive fields

Integration tests:
  - About page renders all section content
  - References page renders all categories with correct counts
  - Search input filters results without page reload
  - External links have correct rel attributes
  - 404 page renders with footer
  - Legal pages all return 200

E2E tests (Playwright):
  - User clicks footer "References" link from any page → lands on References
  - User searches "time blindness" → results filter live
  - User clicks external reference → opens in new tab (verify target attribute)
  - User navigates Settings → About → References (full path works)
  - Reduced-motion preference honored on References page

CI Link Checker tests:
  - Workflow runs on schedule
  - Workflow runs on PR touching references.json
  - Adding a known-broken URL to a PR fails the check
  - Existing-broken URL from scheduled run opens GitHub issue, doesn't fail builds

Accessibility tests:
  - axe-core: 0 violations on About page
  - axe-core: 0 violations on References page
  - All references keyboard-navigable
  - Reading-level check on About page content (Flesch-Kincaid 8th grade)
```

### Acceptance Criteria

- [ ] App installable on iOS and Android (as PWA)
- [ ] Offline support works for: dashboard, active tasks, timer
- [ ] Account deletion works end-to-end with 30-day grace
- [ ] Account deletion blocked by active Stripe subscription (must cancel first)
- [ ] Data export produces valid JSON
- [ ] Sentry captures errors in production
- [ ] **Sentry PII scrubbing verified: voice/audio/transcript/task content NEVER in error reports**
- [ ] **Sentry user context contains only user ID, no email or name**
- [ ] All Lighthouse scores ≥90
- [ ] All security headers verified
- [ ] **About page live with all content from spec §4.1**
- [ ] **References page live with all 75 references categorized**
- [ ] **Disclaimer block visible at top of References page**
- [ ] **All foundational/supporting references have annotations**
- [ ] **Footer present on all non-auth pages with all 6 links**
- [ ] **Search/filter on References page works without page reload**
- [ ] **All external links use rel="noopener noreferrer"**
- [ ] **No tracking on outbound link clicks**
- [ ] **CI link checker workflow exists and runs successfully**
- [ ] **CI link checker correctly catches a deliberately broken test URL**
- [ ] **lastUpdated date displays correctly on References page**
- [ ] Privacy Policy, Terms of Service, Refunds pages live
- [ ] axe-core: 0 violations on all static pages
- [ ] Native iOS/Android apps NOT in scope for v1 (documented as future work)

### Manual Smoke Test (Human)

1. Install PWA on iPhone
2. Use offline → tasks still accessible
3. Reconnect → changes sync
4. Trigger error → see in Sentry
5. Run Lighthouse → all green
6. **Open homepage → verify footer present with all links**
7. **Click "References" in footer → land on References page**
8. **Verify disclaimer is visible at top**
9. **Verify references are organized into 6 categories**
10. **Search "Barkley" → see relevant references filter**
11. **Click an external reference → opens in new tab, no Focus Forge tracking**
12. **Navigate Settings → About → click References link**
13. **Manually test CI link checker:**
    - Add a deliberately broken URL to references.json on a test branch
    - Open PR → verify CI fails the check
    - Remove the broken URL → verify CI passes
14. **Verify "Last updated" date is recent**

### ✅ PAUSE POINT — End of M15 — Phase 3 Complete

**You can launch here.** M16 (paid tier) comes after you have real users on the free tier.

---

# POST-LAUNCH

## Milestone 16: Bug & Feature Request Tool

**Goal:** Public route where users can submit bug reports and feature requests, vote on existing items, and see status updates from maintainers. Forum framework placeholders in place but not exposed.

**Prerequisites:** M15 complete

**Spec references:** `04-mysql-schema.md` §4.19-4.21, §4.27; `05-monetization-strategy.md` §2.1 (free tier)

### Task Force Round-Table On This Milestone

This milestone replaces what would have been a forum. The Cognitive Therapist's hard rules:

- **No general user-to-user comments** in v1 (RSD risk)
- **No downvotes** (only upvotes)
- **No public attribution by default** (submitter shown as "A user" unless they opt to be named)
- **No notifications** about other users' content (only about updates to YOUR submissions)
- **Status language is neutral** — `wontfix` is "Outside our current focus" in UI, never "rejected" or "denied"

### Tasks

#### 16.1 Schema (already in M1 from doc 04 §4.19-4.21, §4.27)
```
- feedback_items (with kind: bug | feature_request)
- feedback_votes (one per user per item; upvotes only)
- feedback_status_updates (admin-only)
- feature_announcements (forum framework placeholder, used now for admin pinned notices)
```

#### 16.2 Public Feedback Page
```
- Route: /feedback (publicly viewable, anyone can read; submission requires auth)
- apps/web/app/feedback/page.tsx
- Tabs: "Bugs" | "Feature Requests" (default: Feature Requests, sorted by votes)
- Filter: status (open | acknowledged | in_progress | resolved | wontfix)
- Sort: most-voted | newest | recently-updated
- Pinned items appear at top (admin-pinned)
- Active feature_announcements (visible, not expired) shown above the list
- Single-column layout (per design system)
```

#### 16.3 Feedback Item Detail Page
```
- Route: /feedback/[id]
- Shows: title, body, status badge, vote count, vote button
- Admin status updates rendered chronologically below the item
- "Report duplicate" button (creates internal flag, doesn't auto-merge)
- "Report inappropriate content" button (admin moderation queue)
- NO general comment thread (forum framework placeholder doesn't expose this)
```

#### 16.4 Submit Feedback Flow
```
- Route: /feedback/new
- Authenticated users only
- Form fields:
  - Kind: radio (Bug / Feature Request)
  - Title: required, max 200 chars
  - Body: required, min 30 chars, max 2000 chars
  - Bug metadata (auto-collected if Bug kind):
    - Browser + version (from User-Agent)
    - OS (from User-Agent)
    - Viewport size
    - Current URL when reported
- Show: "Your submission will be visible publicly. Your name is shown as
  'A user' unless you change this in settings."
- Rate limit: 3 submissions per user per hour
- Submitter auto-votes on their own item (vote_count starts at 1)
```

#### 16.5 Voting
```
- /api/feedback/[id]/vote endpoint
- POST = add vote, DELETE = remove vote
- Atomic increment/decrement of feedback_items.vote_count in same transaction
- Toggle vote button: shows count, highlighted state when voted
- Authenticated users only
- One vote per user per item (enforced by unique key)
```

#### 16.6 Admin Console (Plugs Into M2 Admin Foundation)
```
- Route: /admin/feedback (gated by 'admin_feedback_management' feature_grant)
- Plugs into the admin layout established in M2 (no new auth/permission scaffolding)
- All actions use the requireAdminPermission middleware from M2
- All status updates and pins logged to admin_actions with justification field
- List view of all items with admin actions:
  - Update status (open → acknowledged → in_progress → resolved/wontfix)
  - Add status update message (admin commentary)
  - Pin/unpin item
  - Mark as duplicate (set duplicate_of_id)
  - Delete (soft-delete, hides from public view)
- Future enhancement: better admin UI in M18 or beyond
```

#### 16.7 Email Notifications (Submitter Only)
```
- When YOUR submission gets a status update or admin response:
  - Email via Resend
  - Plain text, no marketing
  - Subject: "Update on your [bug report | feature request]"
  - Body: short summary + link
- User can disable in Settings → Notifications
- NEVER email about other users' submissions or activity
```

#### 16.8 Forum Framework Placeholder Documentation
```
- Add /docs/architecture/forum-readiness.md (internal docs)
- Documents:
  - Schema affordances built in (feature_announcements, room for discussions table)
  - UI affordances (feedback components built on a generic Feed pattern)
  - Decision history: why forum was deferred from v1
  - What would need to change to enable it (data model, moderation tools, RSD considerations)
- This is NOT user-facing — it's documentation for the next developer/AI agent
```

### Tests Required

```
Unit tests:
  - Vote count increment/decrement atomicity
  - Status transition logic (admin only)
  - Bug metadata auto-collection from User-Agent
  - Rate limiting on submissions (3/hour)

Integration tests:
  - Submit feedback → row created with vote_count=1
  - Vote on item → count increments, UI reflects
  - Toggle vote off → count decrements
  - Admin status update → email sent to submitter (mock Resend)
  - Non-admin attempts admin actions → 403
  - User submits, then deletes account → submission persists, user_id NULL

E2E tests:
  - Anonymous user views /feedback → sees items but cannot vote
  - Authenticated user submits bug → it appears in list
  - User votes on feature request → vote count updates
  - Admin marks item as resolved → submitter receives email notification
```

### Acceptance Criteria

- [ ] /feedback route accessible to all (read-only for anonymous)
- [ ] Submission requires authentication
- [ ] Voting requires authentication, one vote per user per item
- [ ] No downvote button anywhere in UI
- [ ] No general comments between users (admin-only status updates)
- [ ] Bug metadata auto-collected from browser
- [ ] Admin can transition item through all status states
- [ ] Status text in UI uses neutral language (no "rejected" — uses "Outside our current focus")
- [ ] Email notifications only to submitter, only about their own submissions
- [ ] Rate limit enforced (3 submissions/user/hour)
- [ ] Forum framework documentation exists in /docs/architecture/
- [ ] axe-core: 0 violations on all feedback pages
- [ ] Submitter shown as "A user" by default (privacy-by-default)

### Manual Smoke Test (Human)

1. Visit /feedback while logged out → see existing items, no submit button
2. Log in → "Submit feedback" button appears
3. Submit a bug report → see it in the Bugs tab
4. Vote on a feature request → count goes up, button highlighted
5. Click vote again → un-vote, count goes down
6. As admin (manually grant yourself the feature): visit /admin/feedback
7. Update a status, write a message → check submitter's email (manual or mock)
8. Try to use Apple Sign-In on submission → it doesn't exist (correctly per spec)

### ✅ PAUSE POINT — End of M16

---

## Milestone 17: Routines & Task Templates

**Goal:** Users can create reusable task templates, build them into routines, schedule routines on selected days (every day / weekdays / specific days), and choose hard or soft scheduling per routine. Free for all users.

**Prerequisites:** M4 (tasks), M6 (timer), M8 (Doorknob), M16 (Phase 3 complete)

**Spec references:** `04-mysql-schema.md` §4.22-4.26; `05-monetization-strategy.md` §2.1-2.2 (AI suggestions paid only)

### Task Force Round-Table On This Milestone

The Behaviorist leads here: routines are the highest-leverage clinical accommodation we have. The Cognitive Therapist's hard rules:

- **Missed routine instances are NEVER shown to the user by default.** Soft-track mode applies.
- **The "Patterns" view is opt-in only.** Users explicitly enable it in settings.
- **Patterns view shows COMPLETION counts, not failure counts.** "Completed 12 of 14" not "Missed 2."
- **No streak counters anywhere.** Streaks are RSD landmines.
- **AI suggestions phrased as offers, not corrections.** "Want to try X?" not "You should do X."

### Tasks

#### 17.1 Schema (already in M1 from doc 04 §4.22-4.26)
```
- task_templates
- routines
- routine_steps  
- routine_instances
- routine_completion_patterns
```

#### 17.2 Task Template Management
```
Routes:
- /templates (list)
- /templates/new (create)
- /templates/[id] (edit)
- /templates/[id]/delete (soft-delete, archives)

Server actions:
- create-template
- update-template
- archive-template
- duplicate-template

UI:
- Single-column list of user's templates
- Create form: title, notes, default_priority, default_estimated_minutes,
  optional default_steps array
- Edit existing templates inline
- "Use in routine" button creates a new routine seeded with this template
```

#### 17.3 Routine Builder
```
Routes:
- /routines (list of user's routines)
- /routines/new (create)
- /routines/[id] (edit)
- /routines/[id]/preview (see what it generates for a typical day)

UI flow (single-column, progressive disclosure):
  Step 1: Name your routine ("Morning Routine")
  Step 2: Select days
    - Visual day picker: S M T W T F S (toggle each)
    - Quick presets: "Every day" | "Weekdays" | "Weekends"
  Step 3: Hard or soft scheduling?
    - Hard: "Send me notifications when blocks start/end"
    - Soft: "Just show times as labels, no notifications"
  Step 4: Add tasks
    - "Add from template" picker OR
    - "Add new task" inline form
    - Drag to reorder
    - Set start time + duration per task (optional unless hard-scheduled)
  Step 5: Review & save

Server actions:
- create-routine (with steps in transaction)
- update-routine
- pause-routine (sets is_active=false, doesn't generate new instances)
- resume-routine
- archive-routine (soft-delete)
- reorder-routine-steps
```

#### 17.4 Daily Instance Generation
```
Run by hourly cron dispatcher at 04:00 UTC each day:

For each user with active routines:
  Compute "today" in user's timezone
  For each active routine where isActiveOnDay(routine, today):
    For each active routine_step:
      Insert routine_instance:
        scheduled_date_utc = today (UTC date)
        status = 'pending'
      (Skip if instance already exists — uq_routine_instance_per_day)

Idempotent: re-running doesn't create duplicates
Logs to events: 'routine.instances_generated' with counts
```

#### 17.5 Dashboard Integration
```
Today's routine instances show on the dashboard mixed with regular tasks:
- Sort: scheduled time (if any) ascending, then priority
- Visual differentiator: small icon indicating "from routine"
- Tapping creates a real task row (lazy bind via routine_instances.task_id)
- Completing → marks both task and routine_instance completed
- Skipping → marks routine_instance skipped (silent, no shame)
- End-of-day silent expiration: pending instances become 'expired' (never shown again)
```

#### 17.6 Hard Scheduling (Notifications)
```
For hard-scheduled routines:
- When generating instance, also create scheduled_alert:
  - Type: 'routine_block_start'
  - Scheduled for: routine_step.start_time_local converted to UTC for today
  - Payload: { routine_id, routine_step_id, kind: 'start' }
- Browser notification (with permission)
- Notification copy: "Time to start: [task title]"
- ALSO create end alert if duration_minutes set:
  - Notification copy: "Wrapping up: [task title] (block ends now)"
- User can mute notifications for a specific routine
```

#### 17.7 Patterns View (Opt-In)
```
Setting: Settings → Routines → "Show me my completion patterns" (toggle, default OFF)

When enabled:
- Route: /routines/patterns
- Shows routine_completion_patterns data
- For each routine_step:
  - "Job hunt: completed 12 of 14 days (last 30 days, 14 active)"
  - Day-of-week breakdown chart
- Free tier: raw completion data only
- Pro tier: AI-generated suggestions appear inline
  - Generated by daily cron job using routine_completion_patterns data
  - Stored in routine_completion_patterns.ai_suggestion column
  - Quota: AI suggestions are NOT counted against ai_decision quota
    (this is a Pro-only feature; no free version exists)
- BANNED in this view: streak counters, red highlighting, "missed" framing,
  "you should" phrasing, comparison to other users
```

#### 17.8 AI Suggestion Generation (Pro Only)
```
Run by hourly cron dispatcher (e.g., at 05:00 UTC daily):

For each Pro user with completion_patterns enabled:
  For each routine_step with completion_rate < 0.5:
    Generate AI suggestion using GPT-4o-mini:
      Prompt: "User's routine task '{title}' is completed only X% of the time.
      Day-of-week breakdown: {breakdown}. Suggest ONE gentle adjustment
      (e.g., time change, day removal, splitting into smaller tasks).
      Return as a single sentence offering, never a directive."
    Save to routine_completion_patterns.ai_suggestion

UI in Patterns view (Pro):
  Shows the suggestion below each step's data
  "Try this?" button creates a draft routine update for user to review
```

#### 17.9 Settings Integration
```
Settings → Routines section:
- Toggle: Show completion patterns (default OFF)
- Toggle: Notifications for hard-scheduled routines (default ON)
- List of routines with quick pause/resume
- Link to /routines page for full management
```

### Tests Required

```
Unit tests:
  - Day bitmask: isActiveOnDay correctly handles all 7 days
  - Day presets: every_day=127, weekdays=62, weekends=65
  - Routine step ordering preserved on reorder
  - Instance generation idempotency (run twice, same result)
  - End-of-day expiration logic
  - Pattern computation: completion_rate correct for various inputs
  - AI suggestion gating: only Pro users get suggestions

Integration tests:
  - Create template → use in routine → save → verify schema
  - Create routine for "every day" → verify instance generated next 04:00 UTC
  - Create routine for "weekdays" → verify NO instance on Saturday
  - Hard-scheduled routine → scheduled_alert created with correct UTC time
  - Pending instance at end-of-day → marked expired silently
  - Free user views patterns → sees data, no AI suggestion
  - Pro user views patterns → sees data + AI suggestion
  - Daily generation handles users across timezones correctly

E2E tests:
  - User creates first template, then first routine → tasks appear next morning
  - User pauses routine → next day's instances NOT generated
  - User resumes routine → following day's instances resume
  - User enables Patterns → /routines/patterns becomes accessible
  - User disables Patterns → /routines/patterns shows "feature off" page
```

### Acceptance Criteria

- [ ] Users can create unlimited task templates
- [ ] Users can create unlimited routines
- [ ] Day selection supports every-day, weekdays, weekends, custom (any combo)
- [ ] Hard vs soft scheduling toggle per routine
- [ ] Hard-scheduled routines fire browser notifications at correct local times
- [ ] Soft-scheduled routines show times as labels only, no notifications
- [ ] Daily generation runs at 04:00 UTC via hourly cron, idempotent
- [ ] Routine instances appear on dashboard mixed with regular tasks
- [ ] Completing instance from dashboard marks both task and routine_instance complete
- [ ] End-of-day pending instances silently expire (NEVER shown to user)
- [ ] Patterns view is OPT-IN, default off
- [ ] Patterns view shows completion counts, not failure counts
- [ ] No streak counters anywhere in routines feature
- [ ] AI suggestions appear ONLY for Pro users in Patterns view
- [ ] Free users see raw data without AI suggestions (clear, not nagging)
- [ ] All routine UI passes axe-core (0 violations)
- [ ] All tests pass

### Manual Smoke Test (Human)

1. Create 3 task templates: "Job hunt", "Breakfast", "Clean common area"
2. Create routine "Morning Routine":
   - Days: every day
   - Hard scheduling: yes
   - Tasks: 8am-10am Job Hunt, 10am Breakfast, 10:30am-2pm Clean
3. Wait until next 04:00 UTC → check dashboard, see 3 routine instances
4. Receive browser notification at 8am: "Time to start: Job hunt"
5. Complete one, skip another → end of day, check no shame messaging anywhere
6. Enable Settings → Show completion patterns
7. Visit /routines/patterns → see your completion data
8. As Pro user: see AI suggestions inline
9. As free user: see data only, no suggestions

### ✅ PAUSE POINT — End of M17 — End of Phase 3

---

# POST-LAUNCH

## Milestone 18: Monetization (Stripe + Pro Tier)

**Goal:** Free users can upgrade to Pro. Paid users get unlimited quotas and Body Doubling. Legacy migration plan documented and ready.

**Prerequisites:** M17 complete + at least 50 active free users

**Spec references:** `05-monetization-strategy.md` (entire doc)

### Tasks
```
- Stripe account, Products, Prices configured
- subscriptions table per spec §6.3 (already in schema from M1)
- Stripe webhook endpoint
- Customer Portal integration
- Quota check expansion: paid users skip checks
- Pro upgrade page with pricing
- Donation page with Supporter badge
- Legacy migration script (do not run yet — script is for future)
- Email templates: legacy notice, payment failed, etc.
```

### Tests
- Webhook handles all 5 event types
- Tier sync from Stripe → DB
- Past-due grace period (3-day soft, 7-day revert)
- Customer Portal flow
- Refund handling (manual)
- Account deletion + active subscription

### Manual Smoke Test (Human)
1. Subscribe via Stripe Test Mode → tier updates
2. Cancel subscription → tier reverts at period end
3. Trigger payment failure → grace period UI
4. Use Customer Portal → manages everything

### Acceptance Criteria

- [ ] All §14 acceptance criteria from 05-monetization-strategy.md met

---

# Cross-Cutting Concerns

## Documentation Updates
After every milestone:
- Update README.md with current capabilities
- Add ADR (Architecture Decision Record) for significant choices
- Update API reference if new endpoints added

## Database Migrations
- Every schema change = a new migration file
- Migrations are forward-only (no rollback in v1)
- Test migrations on staging copy before production
- phpMyAdmin for inspection, never for direct schema edits

## Branch Strategy
```
main           ← production
develop        ← integration
feature/M{n}-* ← per-milestone work
hotfix/*       ← critical production fixes
```

## Code Review (When Human + AI Collaborate)
- Claude Code submits PRs to `develop`
- Human reviews + tests on Vercel preview deploy
- Merge after acceptance criteria met
- `develop` → `main` only after milestone passes manual smoke test

## When To Ask The Human

Claude Code should pause and ask the human when:
- A spec doc is ambiguous on an implementation choice
- An external service (Stripe, OpenAI) needs credentials
- A migration would touch production data
- Tests fail in ways that suggest spec changes needed
- A milestone's acceptance criteria can't be fully met as written
- A pause point is reached
