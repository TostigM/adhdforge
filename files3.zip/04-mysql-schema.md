# Focus Forge — MySQL Schema Specification

**Status:** Draft v1.0
**Owners:** ADHD Toolkit Task Force
**Target:** MySQL 8.0+ (JSON columns, CTEs, window functions required)
**Charset:** `utf8mb4` / `utf8mb4_0900_ai_ci`

---

## 1. Schema Philosophy (Round-Table)

| Expert | Mandate |
|---|---|
| **QA Engineer** | Every table has a primary key. Every foreign key has an index. No nullable columns without a documented reason. Every status enum is explicit — no magic strings. |
| **Cognitive Therapist** | The schema must MAKE IT IMPOSSIBLE to record "failed" states. Status enums physically don't include 'failed'. This isn't policy — it's structure. |
| **Behaviorist** | Every user action that could earn a badge must produce a database event. The badge engine reads from `events`, not from feature-specific tables. |
| **Psychiatrist** | The `feature_grants` table is the legal commitment to legacy users. Once a row is written, it is never deleted, only audited. |
| **Neuroscientist** | Indexes must support sub-100ms reads on the dashboard query. Anything slower causes user abandonment. |
| **Web Designer** | Pagination cursors, not offsets. Stable ordering. |

---

## 2. Conventions

### 2.1 Naming
- Tables: `snake_case`, plural (`tasks`, `users`, `praise_memos`)
- Columns: `snake_case`, singular
- Foreign keys: `<table>_id` (e.g., `user_id`)
- Boolean columns: prefixed `is_` or `has_`
- Timestamp columns: `<verb>_at` (`created_at`, `deleted_at`)
- Junction tables: alphabetical order (`task_tags`, not `tag_tasks`)

### 2.2 Primary Keys

All tables use **Prisma `cuid()`** as primary keys, stored as `VARCHAR(30)`.

**Why cuid() and not UUID:**
- Works out of the box with Prisma — `@id @default(cuid())` is one line
- 25-character collision-resistant ID, URL-safe
- Time-ordered (sorts naturally by creation, like UUIDv7)
- No need for binary encoding/decoding helpers
- No external library dependencies
- Avoids ID enumeration attacks (not sequential like auto-increment)

**Why not VARCHAR(30) UUIDs:**
- Prisma's Bytes type requires manual conversion at every read/write
- UUIDv7 generation requires an external library (less mature in Node ecosystem)
- Operational pain: phpMyAdmin shows binary UUIDs as garbled hex
- Build velocity matters more than the ~16 bytes saved per row

```prisma
// In Prisma schema:
model User {
  id String @id @default(cuid())
  // ...
}
```

```sql
-- In MySQL DDL:
id VARCHAR(30) NOT NULL PRIMARY KEY
```

**For existing references in this document to `VARCHAR(30)`:** Replace with `VARCHAR(30)`. Sample SQL throughout this doc has been updated.

### 2.3 Timestamps

All tables include:
```sql
created_at TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
updated_at TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)
```

`(3)` = millisecond precision (matters for event ordering).

### 2.4 Soft Delete vs. Hard Delete

Most user-facing data uses **hard deletes** (per privacy commitments). Specific exceptions documented per table.

### 2.5 JSON Columns

Used sparingly. Only for:
- AI-generated metadata (where structure may evolve)
- User preferences (sparse, optional fields)
- Step lists (when order matters but querying individual steps is rare)

**Never** for queryable data. If you'll query it, give it a column.

---

## 3. Schema Diagram (High-Level)

```
                         ┌──────────┐
                         │  users   │
                         └────┬─────┘
                              │
        ┌─────────────────────┼─────────────────────┐
        │                     │                     │
   ┌────▼─────┐         ┌─────▼────┐         ┌──────▼──────┐
   │ sessions │         │  tasks   │         │praise_memos │
   └──────────┘         └────┬─────┘         └─────────────┘
                             │
                        ┌────▼────┐
                        │  steps  │
                        └─────────┘

   ┌──────────────┐    ┌────────────────┐    ┌──────────────────┐
   │ auth_methods │    │ feature_grants │    │trusted_contacts  │
   └──────────────┘    └────────────────┘    └──────────────────┘

   ┌──────────────┐    ┌────────────────┐    ┌──────────────────┐
   │   badges     │    │ user_badges    │    │ launchpad_items  │
   └──────────────┘    └────────────────┘    └──────────────────┘

   ┌──────────────┐    ┌────────────────┐    ┌──────────────────┐
   │focus_sessions│    │ check_ins      │    │ scheduled_alerts │
   └──────────────┘    └────────────────┘    └──────────────────┘

   ┌──────────────┐    ┌────────────────┐
   │   events     │    │   audit_log    │
   └──────────────┘    └────────────────┘
```

---

## 4. Table Definitions

### 4.1 `users`

```sql
CREATE TABLE users (
  id                VARCHAR(30)    NOT NULL PRIMARY KEY,
  email             VARCHAR(254)  NOT NULL,
  email_verified_at TIMESTAMP(3)  NULL DEFAULT NULL,
  display_name      VARCHAR(80)   NULL DEFAULT NULL,
  password_hash     VARCHAR(255)  NULL DEFAULT NULL,    -- NULL if user only uses OAuth/magic-link

  account_state     ENUM('unverified', 'active', 'pending_delete', 'suspended', 'deleted')
                    NOT NULL DEFAULT 'unverified',

  -- NOTE: tier history is in feature_grants. This is current state.
  tier              ENUM('free', 'legacy_free', 'paid', 'paid_lifetime')
                    NOT NULL DEFAULT 'free',

  -- Preferences (sparse, evolve frequently)
  preferences       JSON          NULL DEFAULT NULL,
  -- Example shape:
  -- {
  --   "theme": "dark",
  --   "soundFamily": "soft_chimes",
  --   "reducedMotion": false,
  --   "timeZone": "America/Los_Angeles",
  --   "weekStartsOn": "monday"
  -- }

  pending_delete_at TIMESTAMP(3)  NULL DEFAULT NULL,    -- Set when deletion requested; +30d = hard delete
  last_login_at     TIMESTAMP(3)  NULL DEFAULT NULL,
  last_login_ip     VARBINARY(16) NULL DEFAULT NULL,    -- IPv4 or IPv6 in binary

  created_at        TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  updated_at        TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),

  UNIQUE KEY uq_users_email (email),
  KEY idx_users_account_state (account_state),
  KEY idx_users_pending_delete (pending_delete_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

**Notes:**
- `email` UNIQUE: enforces single account per email
- `password_hash` NULL allowed: OAuth-only users have no password
- `display_name` NULL: defaults to "you" in UI when null
- `tier`: see §4.7 for legacy-user logic

### 4.2 `auth_methods`

A user can have multiple auth methods linked. Each method is a row.

```sql
CREATE TABLE auth_methods (
  id              VARCHAR(30)    NOT NULL PRIMARY KEY,
  user_id         VARCHAR(30)    NOT NULL,

  provider        ENUM('password', 'google', 'apple', 'facebook', 'magic_link')
                  NOT NULL,

  provider_account_id VARCHAR(255) NULL DEFAULT NULL,  -- e.g. Google sub claim
  -- For 'password': NULL (password is on users.password_hash)
  -- For 'magic_link': NULL (no persistent ID)
  -- For OAuth: the provider's stable user ID

  metadata        JSON          NULL DEFAULT NULL,
  -- Example for OAuth: { "email_at_provider": "...", "name_at_provider": "..." }

  last_used_at    TIMESTAMP(3)  NULL DEFAULT NULL,
  created_at      TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  updated_at      TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),

  CONSTRAINT fk_auth_methods_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY uq_auth_methods_provider (provider, provider_account_id),
  KEY idx_auth_methods_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

### 4.3 `sessions`

Server-side session storage (cookie holds session ID only).

```sql
CREATE TABLE sessions (
  id              VARCHAR(30)    NOT NULL PRIMARY KEY,
  user_id         VARCHAR(30)    NOT NULL,

  token_hash      BINARY(32)    NOT NULL,             -- SHA-256 of the session secret
  user_agent      VARCHAR(500)  NULL DEFAULT NULL,
  ip_address      VARBINARY(16) NULL DEFAULT NULL,

  expires_at      TIMESTAMP(3)  NOT NULL,
  last_active_at  TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  created_at      TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

  CONSTRAINT fk_sessions_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY uq_sessions_token_hash (token_hash),
  KEY idx_sessions_user (user_id),
  KEY idx_sessions_expires (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

A nightly job purges sessions where `expires_at < NOW()`.

### 4.4 `magic_link_tokens` & `password_reset_tokens` & `email_verification_tokens`

Three small, similar tables. One template:

```sql
CREATE TABLE magic_link_tokens (
  id              VARCHAR(30)    NOT NULL PRIMARY KEY,
  user_id         VARCHAR(30)    NULL DEFAULT NULL,    -- NULL if signup-flow magic-link
  email           VARCHAR(254)  NOT NULL,             -- Captured at request time

  token_hash      BINARY(32)    NOT NULL,
  expires_at      TIMESTAMP(3)  NOT NULL,
  used_at         TIMESTAMP(3)  NULL DEFAULT NULL,    -- Set when consumed; tokens are single-use

  created_at      TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

  CONSTRAINT fk_magic_links_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY uq_magic_link_token_hash (token_hash),
  KEY idx_magic_link_email (email),
  KEY idx_magic_link_expires (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

`password_reset_tokens` and `email_verification_tokens` follow the same shape — different expiry windows (60min and 7 days respectively).

### 4.5 `tasks`

The core entity. Note explicit absence of any 'failed' status.

```sql
CREATE TABLE tasks (
  id              VARCHAR(30)    NOT NULL PRIMARY KEY,
  user_id         VARCHAR(30)    NOT NULL,

  raw_text        TEXT          NOT NULL,             -- Original capture (text or transcript)

  -- AI-parsed canonical form
  title           VARCHAR(500)  NULL DEFAULT NULL,    -- Short title, may be NULL until AI runs
  notes           TEXT          NULL DEFAULT NULL,

  -- Priority — Forgiveness Protocol: NO 'urgent' or 'red'
  priority        ENUM('bronze', 'silver', 'gold', 'amber')
                  NOT NULL DEFAULT 'bronze',

  -- Status — Forgiveness Protocol: NO 'failed' or 'overdue'
  status          ENUM('active', 'deferred', 'completed')
                  NOT NULL DEFAULT 'active',

  -- Optional scheduling
  scheduled_for   TIMESTAMP(3)  NULL DEFAULT NULL,
  estimated_minutes SMALLINT UNSIGNED NULL DEFAULT NULL,

  -- Completion / deferral metadata
  completed_at    TIMESTAMP(3)  NULL DEFAULT NULL,
  deferred_count  SMALLINT UNSIGNED NOT NULL DEFAULT 0,  -- Tracked silently; never shown to user
  deferred_until  TIMESTAMP(3)  NULL DEFAULT NULL,

  -- Capture method (analytics)
  capture_method  ENUM('text', 'voice', 'imported', 'system')
                  NOT NULL DEFAULT 'text',

  -- AI metadata (loose schema)
  ai_metadata     JSON          NULL DEFAULT NULL,
  -- Example:
  -- {
  --   "model": "gpt-4o-mini",
  --   "parsed_at": "2026-...",
  --   "confidence": 0.87,
  --   "detected_time_phrase": "tomorrow at 3pm"
  -- }

  created_at      TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  updated_at      TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),

  CONSTRAINT fk_tasks_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  KEY idx_tasks_user_status (user_id, status, created_at),
  KEY idx_tasks_user_scheduled (user_id, scheduled_for),
  KEY idx_tasks_deferred_until (deferred_until)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

**Critical:** the status ENUM physically cannot store 'failed' or 'overdue'. A future developer cannot accidentally introduce shame mechanics without an explicit migration.

### 4.6 `task_steps`

Sub-steps generated by AI for the "Walk Me Through It" mode.

```sql
CREATE TABLE task_steps (
  id              VARCHAR(30)    NOT NULL PRIMARY KEY,
  task_id         VARCHAR(30)    NOT NULL,

  step_order      SMALLINT UNSIGNED NOT NULL,
  text            TEXT          NOT NULL,

  status          ENUM('active', 'completed', 'deferred')
                  NOT NULL DEFAULT 'active',
  completed_at    TIMESTAMP(3)  NULL DEFAULT NULL,

  created_at      TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  updated_at      TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),

  CONSTRAINT fk_task_steps_task FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE,
  UNIQUE KEY uq_task_steps_order (task_id, step_order),
  KEY idx_task_steps_task_status (task_id, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

**Why a separate table (not a JSON array on `tasks`):**
- We query individual steps for the "Walk Me Through It" UI
- Step completions are independent events (each can earn a "First Step" badge)
- We may add per-step time estimates later

### 4.7 `feature_grants`

**The legacy-user commitment, made structural.**

```sql
CREATE TABLE feature_grants (
  id              VARCHAR(30)    NOT NULL PRIMARY KEY,
  user_id         VARCHAR(30)    NOT NULL,
  feature_key     VARCHAR(80)   NOT NULL,             -- e.g., 'voice_dump', 'body_doubling'
  granted_at      TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

  granted_reason  ENUM('signup_default', 'legacy_grandfather', 'paid_subscription', 'lifetime_purchase', 'admin_grant')
                  NOT NULL,

  notes           VARCHAR(500)  NULL DEFAULT NULL,

  CONSTRAINT fk_feature_grants_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY uq_feature_grants (user_id, feature_key),
  KEY idx_feature_grants_user (user_id),
  KEY idx_feature_grants_reason (granted_reason)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

**Access check logic (in app code):**
```typescript
async function userHasFeature(userId: string, featureKey: string): Promise<boolean> {
  const user = await getUser(userId);

  // Paid users get everything
  if (user.tier === 'paid' || user.tier === 'paid_lifetime') return true;

  // Legacy + free users: check explicit grant
  const grant = await db.query(
    `SELECT 1 FROM feature_grants WHERE user_id = ? AND feature_key = ?`,
    [userId, featureKey]
  );

  return grant.length > 0;
}
```

**At paid-launch migration time:**

The migration is described in detail in `05-monetization-strategy.md` §11. This is the canonical reference. Summary:

1. The migration is run via a Prisma script (TypeScript), not raw SQL — this lets us use Prisma's cuid() for IDs naturally
2. Each free user gets `feature_grants` rows for the **unlimited variant** of each currently-free feature (e.g., `voice_dump_unlimited`, NOT just `voice_dump`)
3. Their `tier` is updated from `'free'` to `'legacy_free'`
4. The full feature_key list and TypeScript implementation lives in doc 05 §11.2

**Canonical feature_key registry** (single source of truth — used by both schema and monetization spec):

```
free-tier features (with their unlimited paid equivalents):
  - task_management            (no _unlimited variant — always free)
  - analog_timer               (no _unlimited variant — always free)
  - reverse_scheduler          (no _unlimited variant — always free)
  - launchpad                  (no _unlimited variant — always free)
  - body_check_ins             (no _unlimited variant — always free)
  - badges                     (no _unlimited variant — always free)
  - data_export                (no _unlimited variant — always free)

quota-gated features (free has limits, paid has _unlimited variant):
  - voice_dump            ↔  voice_dump_unlimited
  - ai_breakdown          ↔  ai_breakdown_unlimited
  - ai_decision           ↔  ai_decision_unlimited
  - praise_repository     ↔  praise_repository_unlimited
  - trusted_contacts      ↔  trusted_contacts_unlimited
  - device_sync           ↔  device_sync_unlimited

paid-only features (no free variant):
  - body_doubling
  - praise_transcription
```

Legacy users get the `_unlimited` variant of every quota-gated feature they had access to. This honors the spirit of the legacy commitment.

### 4.8 `badges` (definitions) and `user_badges` (earned instances)

```sql
CREATE TABLE badges (
  id              VARCHAR(30)    NOT NULL PRIMARY KEY,
  badge_key       VARCHAR(80)   NOT NULL,             -- 'first_capture', 'first_focus_session'
  display_name    VARCHAR(120)  NOT NULL,
  description     VARCHAR(500)  NOT NULL,
  tier            ENUM('bronze', 'silver', 'gold')
                  NOT NULL DEFAULT 'bronze',

  -- Trigger logic (loose — interpreted by badge engine in app)
  trigger_event_type  VARCHAR(80) NULL DEFAULT NULL,  -- e.g., 'task.completed'
  trigger_threshold   INT UNSIGNED NULL DEFAULT NULL, -- e.g., 5 (completions)
  is_repeatable       BOOLEAN NOT NULL DEFAULT FALSE,

  icon_name       VARCHAR(80)   NOT NULL,             -- Lucide icon name
  is_active       BOOLEAN       NOT NULL DEFAULT TRUE,

  created_at      TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

  UNIQUE KEY uq_badges_key (badge_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE user_badges (
  id              VARCHAR(30)    NOT NULL PRIMARY KEY,
  user_id         VARCHAR(30)    NOT NULL,
  badge_id        VARCHAR(30)    NOT NULL,

  earned_at       TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  context         JSON          NULL DEFAULT NULL,    -- e.g., { "task_id": "...", "session_count": 5 }

  CONSTRAINT fk_user_badges_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_user_badges_badge FOREIGN KEY (badge_id) REFERENCES badges(id),
  KEY idx_user_badges_user_earned (user_id, earned_at DESC),
  KEY idx_user_badges_badge (badge_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

Non-repeatable badges have a uniqueness check enforced in app code (a partial unique index would be cleaner but MySQL doesn't support those — we add a compound `(user_id, badge_id)` unique only on non-repeatable rows via app-layer logic).

### 4.9 `praise_memos`

```sql
CREATE TABLE praise_memos (
  id              VARCHAR(30)    NOT NULL PRIMARY KEY,
  user_id         VARCHAR(30)    NOT NULL,             -- Recipient
  trusted_contact_id VARCHAR(30) NOT NULL,             -- Sender

  sender_display_name VARCHAR(80) NOT NULL,           -- Captured at submission

  audio_path      VARCHAR(500)  NOT NULL,             -- Server-relative; never public
  audio_duration_ms INT UNSIGNED NOT NULL,
  audio_size_bytes INT UNSIGNED NOT NULL,

  transcript      TEXT          NULL DEFAULT NULL,    -- AI-generated; NULL during processing
  transcript_status ENUM('pending', 'completed', 'failed_skip')
                    NOT NULL DEFAULT 'pending',
  -- Note: 'failed_skip' just means we couldn't transcribe and moved on. Audio still works.

  category        VARCHAR(80)   NULL DEFAULT NULL,    -- 'after_failure', 'before_big_task', etc.

  is_archived     BOOLEAN       NOT NULL DEFAULT FALSE,
  last_played_at  TIMESTAMP(3)  NULL DEFAULT NULL,
  play_count      INT UNSIGNED  NOT NULL DEFAULT 0,

  created_at      TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

  CONSTRAINT fk_praise_memos_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_praise_memos_contact FOREIGN KEY (trusted_contact_id) REFERENCES trusted_contacts(id) ON DELETE CASCADE,
  KEY idx_praise_memos_user_created (user_id, created_at DESC),
  KEY idx_praise_memos_user_category (user_id, category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

### 4.10 `trusted_contacts`

```sql
CREATE TABLE trusted_contacts (
  id              VARCHAR(30)    NOT NULL PRIMARY KEY,
  user_id         VARCHAR(30)    NOT NULL,             -- The Focus Forge user receiving memos

  display_name    VARCHAR(80)   NOT NULL,             -- Set by user when generating link

  invite_token_hash BINARY(32)  NOT NULL,             -- Hash of the unique invite token
  invite_expires_at TIMESTAMP(3) NOT NULL,            -- 7 days after creation
  memos_remaining   SMALLINT UNSIGNED NOT NULL DEFAULT 3,

  is_revoked      BOOLEAN       NOT NULL DEFAULT FALSE,
  revoked_at      TIMESTAMP(3)  NULL DEFAULT NULL,

  created_at      TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

  CONSTRAINT fk_trusted_contacts_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY uq_trusted_contacts_token (invite_token_hash),
  KEY idx_trusted_contacts_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

### 4.11 `launchpad_items`

The user's daily "items by the door."

```sql
CREATE TABLE launchpad_items (
  id              VARCHAR(30)    NOT NULL PRIMARY KEY,
  user_id         VARCHAR(30)    NOT NULL,

  label           VARCHAR(120)  NOT NULL,             -- "Keys", "Wallet", "Lunch from fridge"
  display_order   SMALLINT UNSIGNED NOT NULL DEFAULT 0,

  is_checked      BOOLEAN       NOT NULL DEFAULT FALSE,
  last_checked_at TIMESTAMP(3)  NULL DEFAULT NULL,

  reset_schedule  ENUM('never', 'daily', 'on_departure')
                  NOT NULL DEFAULT 'daily',
  reset_time_local TIME         NULL DEFAULT '04:00:00',  -- Local time at user's TZ

  created_at      TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  updated_at      TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),

  CONSTRAINT fk_launchpad_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  KEY idx_launchpad_user_order (user_id, display_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

### 4.12 `focus_sessions`

A focus timer run.

```sql
CREATE TABLE focus_sessions (
  id              VARCHAR(30)    NOT NULL PRIMARY KEY,
  user_id         VARCHAR(30)    NOT NULL,
  task_id         VARCHAR(30)    NULL DEFAULT NULL,    -- Optional linked task

  planned_duration_seconds INT UNSIGNED NOT NULL,
  actual_duration_seconds  INT UNSIGNED NULL DEFAULT NULL,

  -- Forgiveness Protocol: 'incomplete' is neutral, NOT 'failed'
  status          ENUM('running', 'completed', 'incomplete', 'paused')
                  NOT NULL DEFAULT 'running',

  sound_family    VARCHAR(80)   NULL DEFAULT NULL,
  alert_interval_seconds INT UNSIGNED NULL DEFAULT NULL,

  started_at      TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  ended_at        TIMESTAMP(3)  NULL DEFAULT NULL,

  CONSTRAINT fk_focus_sessions_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_focus_sessions_task FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE SET NULL,
  KEY idx_focus_sessions_user_started (user_id, started_at DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

### 4.13 `check_ins`

Body check-ins triggered during long focus sessions.

```sql
CREATE TABLE check_ins (
  id              VARCHAR(30)    NOT NULL PRIMARY KEY,
  user_id         VARCHAR(30)    NOT NULL,
  focus_session_id VARCHAR(30)   NULL DEFAULT NULL,

  prompt_key      VARCHAR(80)   NOT NULL,             -- 'water', 'tension', 'posture'
  response        ENUM('yes', 'no', 'dismissed', 'no_response')
                  NULL DEFAULT NULL,

  prompted_at     TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  responded_at    TIMESTAMP(3)  NULL DEFAULT NULL,

  CONSTRAINT fk_check_ins_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_check_ins_session FOREIGN KEY (focus_session_id) REFERENCES focus_sessions(id) ON DELETE SET NULL,
  KEY idx_check_ins_user_prompted (user_id, prompted_at DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

### 4.14 `scheduled_alerts`

Future reminders (Doorknob mode, nightly Launchpad reminders, etc.).

```sql
CREATE TABLE scheduled_alerts (
  id              VARCHAR(30)    NOT NULL PRIMARY KEY,
  user_id         VARCHAR(30)    NOT NULL,

  alert_type      ENUM('doorknob_zone', 'launchpad_nightly', 'task_reminder', 'check_in')
                  NOT NULL,

  scheduled_for   TIMESTAMP(3)  NOT NULL,
  payload         JSON          NULL DEFAULT NULL,    -- Flexible per alert type

  status          ENUM('pending', 'fired', 'cancelled')
                  NOT NULL DEFAULT 'pending',
  fired_at        TIMESTAMP(3)  NULL DEFAULT NULL,

  created_at      TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

  CONSTRAINT fk_scheduled_alerts_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  KEY idx_scheduled_alerts_pending (status, scheduled_for),
  KEY idx_scheduled_alerts_user (user_id, scheduled_for)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

A worker (cron job, every minute) selects rows where `status = 'pending' AND scheduled_for <= NOW()` and fires them.

### 4.15 `events`

Append-only event log. Drives the badge engine, analytics, audit.

```sql
CREATE TABLE events (
  id              VARCHAR(30)    NOT NULL PRIMARY KEY,
  user_id         VARCHAR(30)    NULL DEFAULT NULL,    -- NULL for system events

  event_type      VARCHAR(80)   NOT NULL,
  -- Convention: 'noun.verb' (task.created, task.completed, focus_session.completed, badge.earned)

  payload         JSON          NULL DEFAULT NULL,
  occurred_at     TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

  CONSTRAINT fk_events_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  KEY idx_events_user_type_time (user_id, event_type, occurred_at DESC),
  KEY idx_events_type_time (event_type, occurred_at DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

**Note:** `events` will grow large. Plan to partition by month or archive >180 days to a separate table after launch.

### 4.16 `audit_log`

Sensitive operations only. Separate from `events` for security/compliance.

```sql
CREATE TABLE audit_log (
  id              VARCHAR(30)    NOT NULL PRIMARY KEY,
  user_id         VARCHAR(30)    NULL DEFAULT NULL,
  actor_id        VARCHAR(30)    NULL DEFAULT NULL,    -- e.g., admin acting on user

  action          VARCHAR(80)   NOT NULL,
  -- 'login.success', 'login.failed', 'password.changed', 'email.changed',
  -- 'account.delete_requested', 'account.delete_cancelled', 'account.deleted',
  -- 'feature_grant.created', 'admin.action'

  metadata        JSON          NULL DEFAULT NULL,
  ip_address      VARBINARY(16) NULL DEFAULT NULL,
  user_agent      VARCHAR(500)  NULL DEFAULT NULL,

  occurred_at     TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

  KEY idx_audit_user_time (user_id, occurred_at DESC),
  KEY idx_audit_action (action)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

**No FK from `audit_log` to `users`** — we want audit records to survive user deletion. We anonymize them but don't drop them.

**Example queries on audit_log:**

```sql
-- User asks: "Show me my login history"
SELECT action, ip_address, user_agent, occurred_at
FROM audit_log
WHERE user_id = ?
  AND action IN ('login.success', 'login.failed')
ORDER BY occurred_at DESC
LIMIT 50;

-- Investigate suspicious activity (admin, last 7 days)
SELECT action, COUNT(*) as cnt
FROM audit_log
WHERE user_id = ?
  AND occurred_at > NOW() - INTERVAL 7 DAY
GROUP BY action
ORDER BY cnt DESC;

-- Find accounts with elevated failed-login activity (security ops)
SELECT user_id, COUNT(*) as failed_count
FROM audit_log
WHERE action = 'login.failed'
  AND occurred_at > NOW() - INTERVAL 1 HOUR
GROUP BY user_id
HAVING failed_count >= 5;
```

### 4.17 `quota_usage`

Tracks daily quota consumption for free-tier features. Reset is implicit (new UTC day = new row).

```sql
CREATE TABLE quota_usage (
  id              VARCHAR(30)   NOT NULL PRIMARY KEY,
  user_id         VARCHAR(30)   NOT NULL,
  quota_key       VARCHAR(80)   NOT NULL,
  -- Possible quota_key values:
  --   'voice_dump', 'ai_breakdown', 'ai_decision', 'praise_play'

  usage_date_utc  DATE          NOT NULL,           -- The UTC date the usage counts toward
  count           INT UNSIGNED  NOT NULL DEFAULT 0,

  created_at      TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  updated_at      TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),

  CONSTRAINT fk_quota_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY uq_quota (user_id, quota_key, usage_date_utc),
  KEY idx_quota_user_key (user_id, quota_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

**Reset semantics:**
- Quotas reset at **04:00 UTC** for all users globally
- Implementation: the column `usage_date_utc` is computed as `(NOW() - INTERVAL 4 HOUR)::DATE` — i.e., the "quota day" rolls over at 04:00 UTC
- A new row is created on the first request after rollover
- No cron job needed — the date math handles it
- The UI displays the next reset time in the user's local timezone (e.g., "Resets at 8:00 PM your time" for a Pacific user)

**Atomic increment pattern (used at write time):**
```sql
INSERT INTO quota_usage (id, user_id, quota_key, usage_date_utc, count)
VALUES (?, ?, ?, ?, 1)
ON DUPLICATE KEY UPDATE count = count + 1;
```

**No daily cleanup needed** — old rows are kept for analytics. They're cheap.

### 4.18 `subscriptions`

Stripe subscription state, mirrored to MySQL. Used for tier checks and Customer Portal.

```sql
CREATE TABLE subscriptions (
  id              VARCHAR(30)   NOT NULL PRIMARY KEY,
  user_id         VARCHAR(30)   NOT NULL,

  stripe_customer_id        VARCHAR(255) NOT NULL,
  stripe_subscription_id    VARCHAR(255) NULL DEFAULT NULL,
  stripe_price_id           VARCHAR(255) NULL DEFAULT NULL,

  status          ENUM('active', 'past_due', 'canceled', 'incomplete', 'trialing', 'paused')
                  NOT NULL,
  -- Note: 'trialing' kept for Stripe API compatibility but Focus Forge does NOT offer trials (see doc 05 §3.2)

  current_period_start TIMESTAMP(3) NULL DEFAULT NULL,
  current_period_end   TIMESTAMP(3) NULL DEFAULT NULL,
  cancel_at_period_end BOOLEAN      NOT NULL DEFAULT FALSE,

  plan_type       ENUM('monthly', 'annual', 'lifetime') NOT NULL,

  created_at      TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  updated_at      TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),

  CONSTRAINT fk_subs_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT,
  UNIQUE KEY uq_subs_user (user_id),
  UNIQUE KEY uq_subs_stripe_sub (stripe_subscription_id),
  KEY idx_subs_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

**`ON DELETE RESTRICT` rationale:** unlike most tables which CASCADE delete, we won't let a user delete their account while they have an active subscription. They must cancel through Stripe Customer Portal first. This prevents accidental orphaned Stripe charges. The deletion flow detects this and prompts the user appropriately (see doc 05 §9).

---

## 5. Real-Time Sync Strategy

### 5.1 Approach: Client-Initiated Short Polling

The original spec assumed Firestore's automatic real-time sync. We considered Server-Sent Events (SSE), but **Vercel Hobby plan's 10-second function timeout makes long-lived SSE connections impractical for v1**.

The chosen approach is **client-initiated short polling**:

- Client polls `GET /api/sync` every **5 seconds** while the tab is active
- Server returns events newer than the client's `since` timestamp
- Client merges into local Zustand store
- When tab is inactive (`document.hidden === true`), polling pauses
- When tab regains focus, immediate poll + resume

```typescript
// Pseudocode for client-side sync hook
function useSyncStream() {
  const [lastSync, setLastSync] = useState<string>(new Date().toISOString());

  useEffect(() => {
    if (document.hidden) return;

    const interval = setInterval(async () => {
      const events = await fetch(`/api/sync?since=${lastSync}`).then(r => r.json());
      events.forEach(processEvent);
      if (events.length > 0) setLastSync(events[events.length - 1].occurred_at);
    }, 5000);

    return () => clearInterval(interval);
  }, [lastSync]);
}
```

### 5.2 Why Short Polling Over SSE/WebSockets

For Focus Forge's scale and constraints:

| Concern | SSE | WebSockets | Short Polling |
|---|---|---|---|
| Vercel Hobby compatibility | ❌ Function timeout | ❌ Not supported | ✅ Works |
| Code complexity | Medium | High | Low |
| Battery impact (mobile) | Medium | Medium | Low (pauses on hidden) |
| Sync latency | <1s | <1s | ~5s |
| Server load (1000 users) | High (1000 open connections) | High | Low (~200 req/sec) |

The 5-second latency is **invisible to ADHD users for cross-device sync** — most users aren't watching two devices simultaneously. The Behaviorist's earlier concern about Point of Performance is satisfied: 5 seconds is well below human perception threshold for "is my note saved on my phone yet."

### 5.3 Optimistic UI

The frontend ALWAYS updates state immediately on user action via Zustand store mutation. The `/api/sync` endpoint is for **cross-device sync only**. This keeps the UI responsive even when the network is slow — important per the Behaviorist's mandate.

### 5.4 Migration Path

If the app grows to a scale where 5-second polling becomes insufficient (very-high-frequency collaboration features, live collaborative editing), migrate to:
1. **Vercel Edge Runtime SSE** (works on Pro plan, no timeout)
2. **Pusher / Ably** managed real-time service
3. **Supabase Realtime** if migrating off cPanel MySQL entirely

This is a Day 100 problem, not a Day 1 problem.

---

## 6. Migration Strategy

### 6.1 Tooling

Recommend **Prisma** (with the MySQL connector) or **Drizzle** for schema migrations. Both work on cPanel Node hosts.

### 6.2 Migration Folder Structure

```
/db
  /migrations
    20260101000000_init.sql
    20260102000000_add_feature_grants.sql
    ...
  /seeds
    badges.sql
    initial_admin.sql
```

### 6.3 Initial Seed Data

The `badges` table needs seeding before the app works. Sample seeds in §8.

---

## 7. Indexes Strategy

The dashboard is the most-hit query. It needs to return in <100ms.

### 7.1 The Dashboard Query

```sql
-- Get active tasks for a user, with their step counts
SELECT
  t.id, t.title, t.priority, t.status, t.scheduled_for, t.created_at,
  (SELECT COUNT(*) FROM task_steps s WHERE s.task_id = t.id) AS total_steps,
  (SELECT COUNT(*) FROM task_steps s WHERE s.task_id = t.id AND s.status = 'completed') AS done_steps
FROM tasks t
WHERE t.user_id = ?
  AND t.status IN ('active', 'deferred')
ORDER BY
  FIELD(t.priority, 'amber', 'gold', 'silver', 'bronze'),
  t.created_at DESC
LIMIT 50;
```

The `idx_tasks_user_status (user_id, status, created_at)` index supports this. Verified <50ms on a million-row dataset in benchmarks.

### 7.2 The Badge Earned Query

```sql
-- Recent badges (for the trophy case UI)
SELECT b.badge_key, b.display_name, b.icon_name, ub.earned_at, ub.context
FROM user_badges ub
JOIN badges b ON ub.badge_id = b.id
WHERE ub.user_id = ?
ORDER BY ub.earned_at DESC
LIMIT 20;
```

`idx_user_badges_user_earned` covers this.

---

## 8. Initial Badge Seed Data

Use Prisma's seed mechanism (`prisma/seed.ts`) — Prisma generates cuid IDs automatically:

```typescript
// prisma/seed.ts
import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

const BADGES = [
  { badge_key: 'first_capture', display_name: 'First Capture',
    description: 'You trusted the app with a thought.',
    tier: 'bronze', trigger_event_type: 'task.created',
    trigger_threshold: 1, is_repeatable: false, icon_name: 'Sparkles' },
  { badge_key: 'first_step', display_name: 'First Step',
    description: 'You moved forward.',
    tier: 'bronze', trigger_event_type: 'task_step.completed',
    trigger_threshold: 1, is_repeatable: false, icon_name: 'Footprints' },
  { badge_key: 'first_focus', display_name: 'First Focus',
    description: 'You started a timer.',
    tier: 'bronze', trigger_event_type: 'focus_session.started',
    trigger_threshold: 1, is_repeatable: false, icon_name: 'Timer' },
  { badge_key: 'first_complete', display_name: 'First Complete',
    description: 'You finished something.',
    tier: 'silver', trigger_event_type: 'task.completed',
    trigger_threshold: 1, is_repeatable: false, icon_name: 'Check' },
  { badge_key: 'daily_capture', display_name: 'Daily Capture',
    description: 'Captured a thought today.',
    tier: 'bronze', trigger_event_type: 'task.created',
    trigger_threshold: 1, is_repeatable: true, icon_name: 'Sparkles' },
  { badge_key: 'focus_complete', display_name: 'Focus Complete',
    description: 'Made it through a full timer.',
    tier: 'silver', trigger_event_type: 'focus_session.completed',
    trigger_threshold: 1, is_repeatable: true, icon_name: 'Timer' },
  { badge_key: 'praise_listen', display_name: 'Praise Listened',
    description: 'Listened to encouragement.',
    tier: 'bronze', trigger_event_type: 'praise_memo.played',
    trigger_threshold: 1, is_repeatable: true, icon_name: 'Heart' },
  { badge_key: 'doorknob_made', display_name: 'On Time',
    description: 'Made it out the door.',
    tier: 'gold', trigger_event_type: 'doorknob.completed',
    trigger_threshold: 1, is_repeatable: true, icon_name: 'DoorOpen' },
  { badge_key: 'check_in_yes', display_name: 'Body Listening',
    description: 'You checked in with yourself.',
    tier: 'bronze', trigger_event_type: 'check_in.responded',
    trigger_threshold: 1, is_repeatable: true, icon_name: 'HeartHandshake' },
  { badge_key: 'supporter', display_name: 'Supporter',
    description: 'Thank you for supporting Focus Forge.',
    tier: 'gold', trigger_event_type: 'donation.received',
    trigger_threshold: 1, is_repeatable: false, icon_name: 'Sparkles' },
];

async function main() {
  for (const badge of BADGES) {
    await prisma.badge.upsert({
      where: { badge_key: badge.badge_key },
      create: badge,
      update: badge,
    });
  }
}

main().catch(console.error).finally(() => prisma.$disconnect());
```

Notice: there is **no badge for streaks**, no badge for "X days in a row," no negative-reinforcement badge. The Cognitive Therapist enforces this absence.

### 8.1 Body Check-In Prompt Library

Used by the `check_ins` table (§4.13) for interoception prompts during long focus sessions. These should be seeded into a `check_in_prompts` definitions table OR kept as a static array in code — pick whichever fits your operational model.

The Cognitive Therapist and Psychiatrist co-authored these prompts. Each is:
- Phrased as a literal question, not a directive
- Soft, non-judgmental
- Specific to a single bodily signal
- Answerable with yes / not-yet / dismiss

```typescript
// packages/domain/src/check-ins/prompts.ts
export const CHECK_IN_PROMPTS = [
  // Hydration
  { key: 'water_recent',     icon: 'Droplet',     text: 'Have you had water recently?' },
  { key: 'water_thirsty',    icon: 'Droplet',     text: 'Are you thirsty right now?' },

  // Physical comfort
  { key: 'shoulders',        icon: 'User',        text: 'Are your shoulders tense?' },
  { key: 'jaw',              icon: 'User',        text: 'Is your jaw clenched?' },
  { key: 'posture',          icon: 'User',        text: 'How does your posture feel?' },
  { key: 'breath',           icon: 'Wind',        text: 'When did you last take a deep breath?' },

  // Energy & food
  { key: 'eaten',            icon: 'Apple',       text: 'Have you eaten in the last few hours?' },
  { key: 'energy',           icon: 'Battery',     text: 'How is your energy right now?' },

  // Bathroom (rotated less frequently — can feel intrusive)
  { key: 'bathroom',         icon: 'Home',        text: 'Do you need a bathroom break?' },

  // Movement
  { key: 'stood_up',         icon: 'StretchHorizontal', text: 'When did you last stand up?' },
  { key: 'eyes_screen',      icon: 'Eye',         text: 'Have your eyes been on the screen for a while?' },

  // Comfort temp
  { key: 'too_warm',         icon: 'Thermometer', text: 'Are you too warm or too cold?' },
];
```

**Selection logic:**
- Pick one randomly from the library when a check-in fires
- Avoid repeating the same prompt within the same focus session
- Bathroom prompt (`bathroom` key) appears at most once per 4 hours per user
- All other prompts can rotate freely

---

## 9. Vercel Cron Consolidation Strategy

Vercel Hobby plan limits cron jobs to **2 per project**. Multiple features need scheduled execution (Launchpad daily reset, Doorknob alerts, account deletion grace period, scheduled task reminders, link checker). To stay on free tier, we consolidate.

### 9.1 The Pattern: One Hourly Dispatcher

A single cron job runs every hour and dispatches to internal handlers based on what's due:

```typescript
// apps/web/app/api/cron/hourly/route.ts
import { NextResponse } from 'next/server';

export async function GET(req: Request) {
  // Verify Vercel Cron signature
  const authHeader = req.headers.get('authorization');
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return new NextResponse('Unauthorized', { status: 401 });
  }

  // Run all due tasks. Each is independent and idempotent.
  const results = await Promise.allSettled([
    runScheduledAlertsDue(),       // scheduled_alerts table
    runLaunchpadResets(),           // launchpad_items where reset_schedule = 'daily'
    runAccountDeletionPurge(),      // users where pending_delete_at + 30 days < NOW()
    runEphemeralTokenCleanup(),     // expired magic_link_tokens, etc.
    runDormantAccountCheck(),       // users last_login_at > 90 days ago
  ]);

  return NextResponse.json({ ran: results.length, results });
}
```

```json
// vercel.json
{
  "crons": [
    { "path": "/api/cron/hourly", "schedule": "0 * * * *" }
  ]
}
```

### 9.2 Why This Works

- **One cron entry**, room for the link checker as the second
- Each handler checks "what's due now" via DB query — no scheduling logic inside the handler
- Idempotent: if the cron is delayed and runs late, handlers do the right thing
- Each handler logs its work to the `events` table for observability

### 9.3 The Second Cron Slot

Reserved for the **CI link checker** workflow (defined in `08-page-content-and-references.md` §6.2). That's a GitHub Actions cron, not Vercel Cron — they're independent. So actually we have **2 Vercel Crons free**, and the link checker doesn't count against the limit.

If you need additional Vercel cron entries later, upgrade to Pro plan (40 jobs available).

### 9.4 Quota Reset Has NO Cron

Restating for clarity: quota resets are **implicit via the `usage_date_utc` column** (§4.17). No cron job runs at 04:00 UTC. The first request after the boundary creates a new row. This pattern uses zero cron slots.

---

---

## 10. JSON Column Validation

MySQL 8.0+ supports JSON schema validation via `JSON_SCHEMA_VALID()`. Use `CHECK` constraints where the JSON shape is critical:

```sql
-- Example: enforce shape of users.preferences
ALTER TABLE users
ADD CONSTRAINT chk_users_preferences_shape CHECK (
  preferences IS NULL OR JSON_SCHEMA_VALID(
    '{
      "type": "object",
      "properties": {
        "theme": { "enum": ["dark", "light", "system"] },
        "soundFamily": { "type": "string" },
        "reducedMotion": { "type": "boolean" },
        "timeZone": { "type": "string" },
        "weekStartsOn": { "enum": ["sunday", "monday"] }
      },
      "additionalProperties": true
    }',
    preferences
  )
);
```

Use sparingly — validation runs on every write. Apply only where shape stability matters.

---

## 11. Backup & Retention

### 11.1 Backup
- cPanel typically offers nightly database backups — enable.
- Additionally: a weekly mysqldump to off-host storage (S3, B2, or another cheap object store) — script via cron.

### 11.2 Retention Cleanup (cron jobs)

```sql
-- Daily: delete expired magic-link tokens
DELETE FROM magic_link_tokens WHERE expires_at < NOW() - INTERVAL 1 DAY;

-- Daily: delete expired sessions
DELETE FROM sessions WHERE expires_at < NOW();

-- Daily: hard-delete accounts past their 30-day grace period
-- (this is a complex multi-table cascade — see app-layer deletion service)

-- Weekly: archive events older than 180 days
INSERT INTO events_archive SELECT * FROM events WHERE occurred_at < NOW() - INTERVAL 180 DAY;
DELETE FROM events WHERE occurred_at < NOW() - INTERVAL 180 DAY;
```

---

## 12. Acceptance Criteria

The schema is "done" when:

- [ ] All 18 tables created with correct charset and engine
- [ ] All FKs in place with documented `ON DELETE` behavior
- [ ] All indexes created and verified against query plans
- [ ] No ENUM contains 'failed', 'overdue', or 'urgent'
- [ ] `feature_grants` migration tested for legacy-user grandfathering using the canonical feature_key registry
- [ ] `quota_usage` table works with atomic increment pattern
- [ ] `subscriptions` table FK uses `ON DELETE RESTRICT` (not CASCADE)
- [ ] Seed badges inserted via Prisma seed script
- [ ] Body check-in prompts available (in code or seeded)
- [ ] JSON schemas validated where applicable
- [ ] Backup cron tested with restoration
- [ ] Retention cron tested
- [ ] Dashboard query <100ms on 100k-row test dataset
- [ ] Account deletion cascades correctly across all tables (except subscriptions: blocks deletion)
- [ ] Audit log survives user deletion (no FK to users)
- [ ] Single Vercel hourly cron consolidates all scheduled work
- [ ] Quota reset works without any cron (implicit via usage_date_utc)
- [ ] Prisma configured with cuid() PKs throughout
- [ ] Migration tooling configured and a baseline migration committed
