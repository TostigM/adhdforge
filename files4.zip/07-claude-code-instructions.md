# Focus Forge — Instructions for Claude Code

**Status:** Draft v1.0
**Owners:** ADHD Toolkit Task Force
**Audience:** Claude Code (the AI coding agent building this project)

---

## What You Are Building

Focus Forge is a **clinical-grade cognitive prosthetic** — a productivity app for adults with ADHD that functions as an "external prefrontal cortex." It is not a generic to-do app. Every design decision, every line of code, every error message must respect the neurological reality of the user.

**You are not building this alone.** A multi-disciplinary task force of fictional experts (Psychiatrist, Neuroscientist, Behaviorist, Cognitive Therapist, Web Designer, QA Engineer) has spent months specifying this product. The 12 documents in `/docs` are the result.

Your job is to translate those specs into working code, with a human checkpoint at each milestone.

---

## The Document Set

You have **12 documents** to work from. Read them in this order, but refer back constantly:

### Foundational Specs (read first, in this order)

| # | Document | What's In It |
|---|---|---|
| 0a | `ADHD_Forge_Requirements.pdf` | Original Product Requirements Document — functional + non-functional requirements |
| 0b | `Detailed_ADHD_Forge_Document.pdf` | Feature narratives + multidisciplinary philosophy |
| 0c | `ADHD_Forge_Tech_Specs.pdf` | Original technical specifications (mostly superseded by `04` for DB) |
| 0d | `Unified_System_Specification__ADHD_Digital_Toolkit__Google_Docs.pdf` | Module-by-module implementation logic |
| 0e | `Comprehensive_Multidisciplinary_Framework_for_ADHD_Digital_Toolkit_Design__Google_Docs.pdf` | The deepest "why" — clinical research + neuroscience grounding |

### Implementation Specs (the gap-filling work)

| # | Document | What's In It |
|---|---|---|
| 1 | `01-authentication-and-user-model.md` | Full auth system: 4 login methods, sessions, account states, deletion, legacy users, trusted contacts |
| 2 | `02-design-system.md` | Color tokens, typography, components, accessibility rules, Tailwind config strategy |
| 3 | `03-onboarding-flow.md` | First-touch experience, progressive discovery, anti-shame patterns |
| 4 | `04-mysql-schema.md` | Full DDL for 27 tables, real-time sync strategy, retention policies |
| 5 | `05-monetization-strategy.md` | Free/Pro tiers, quota enforcement, Stripe integration plan |
| 8 | `08-page-content-and-references.md` | Static page content (About, References), reference data JSON, disclaimer copy, footer copy, CI link checker |

### Execution Specs (the build instructions)

| # | Document | What's In It |
|---|---|---|
| 6 | `06-build-roadmap.md` | 18 milestones with atomic tasks, tests, acceptance criteria |
| 7 | `07-claude-code-instructions.md` | This document — how to use everything together |

### When Specs Conflict

- **The implementation specs (01-05) supersede the foundational specs (0a-0e)** for any concrete implementation detail
- The **build roadmap (06)** supersedes specs for sequencing and milestone definitions
- The **foundational specs** remain authoritative for **philosophy, clinical rationale, and feature narratives**

When in doubt, ask the human.

---

## Your Operating Constraints

### Architecture (Locked)

- **Hosting:** Vercel (web app) + cPanel MySQL (database) + Cloudflare R2 (audio)
- **Framework:** Next.js 15 (App Router), TypeScript strict
- **Database:** MySQL 8 via Prisma ORM with **cuid() primary keys** (NOT UUIDv7, NOT BINARY)
- **Styling:** TailwindCSS with strict design system tokens
- **Repo:** pnpm monorepo with Turborepo
- **Testing:** Vitest (unit/integration) + Playwright (E2E)
- **Auth:** **NextAuth.js v4 stable** (NOT v5 beta — stability over novelty)
  - Providers: Google, Facebook, Email magic link, Credentials
  - **Apple Sign-In: NOT in v1** (deferred — requires Apple Developer Program $99/yr)
- **AI:** OpenAI Whisper + GPT-4o-mini
- **Payments:** Stripe (M16 only — deferred until 50+ active free users)
- **Audio storage:** **Cloudflare R2** (NOT Vercel Blob — no egress fees, 10GB free)
- **Real-time sync:** **5-second short polling** (NOT SSE — Vercel free-tier compatibility)
- **Email:** Resend (free tier: 3,000/month, 100/day)
- **Body Doubling Video:** **Jitsi Public Instance** (`meet.jit.si`) — free, Pro-tier-gated
- **Cron:** Single Vercel hourly cron dispatcher (consolidates all scheduled work)

### Languages & Tools

- **TypeScript only.** No JavaScript files in `apps/` or `packages/`.
- **Strict mode mandatory:** `strict: true` in all tsconfigs.
- **Conventional Commits format** for all commits.
- **pnpm only.** Do not use npm or yarn — they break workspace resolution.
- **No bash one-liners with sudo.** Local dev uses pnpm scripts; production uses Vercel/cPanel UIs.

---

## The Inviolable Rules

These come from the Cognitive Therapist and override everything else. **Violations are bugs, not preferences.**

### 1. No Red. Anywhere. Ever.

- Tailwind's red palette is overridden in config to throw build errors
- If you find yourself wanting to use red for something urgent, use `--soft-error` (fuchsia) or `--priority-amber` (the closest legal warm tone)
- This applies to error messages, validation, "delete" buttons, alerts, EVERYTHING

### 2. No "Failed", "Overdue", or "Missed" States

- The `tasks.status` ENUM is `('active', 'deferred', 'completed')` — that's it
- The `focus_sessions.status` ENUM uses `'incomplete'` (neutral) instead of `'failed'`
- If a feature seems to need a "failure" state, redesign — don't add one

### 3. No Streaks That Can Break

- No "current streak: 3 days" displays
- No "you broke your streak" messages
- Repeatable badges are fine; consecutive-day requirements are not

### 4. No Manual Save Buttons

- All state auto-saves on change
- Debounce text inputs at 500ms
- Show a subtle "Saved" indicator only on first save of session, never after

### 5. No Icon-Only Buttons For Primary Actions

- Every interactive icon has a text label visible
- Decorative icons need `aria-hidden="true"`
- "Mystery meat" navigation is forbidden

### 6. Single-Column Main Task Layout

- Mobile, tablet, desktop, ultrawide — all single column
- Empty desktop space is intentional
- Exceptions documented in `02-design-system.md` §5.2

### 7. No Pure Black Dark Mode

- `slate-900` (#0f172a) is the floor
- Pure `#000` causes retinal halation in users with photophobia

### 8. No Static Repeating Alert Sounds

- Sound Families cycle variations to prevent auditory habituation
- This is enforced by the audio engine in M6

### 9. No Public Audio Storage

- Praise audio uses Cloudflare R2 with signed URLs (1-hour expiry)
- Voice Dump audio is deleted within 60 seconds of transcription
- Audio is NEVER served from a public URL

### 10. No Re-Engagement Shame

- No "We miss you!" emails
- No "You haven't been here in X days" messages
- No "Where did you go?" prompts
- Users are allowed to come and go without being punished for it

---

## How To Approach Each Milestone

### Step 1: Read The Whole Milestone

Don't start until you've read the entire milestone in `06-build-roadmap.md`, including:
- Goal
- Prerequisites
- Spec references
- All tasks
- Tests required
- Acceptance criteria

### Step 2: Read The Referenced Specs

For every spec doc cited in the milestone, read the cited sections. Don't skim — these specs are dense for a reason.

### Step 3: Plan Before Coding

Before writing code, produce a brief plan in chat:
- What files will you create?
- What files will you modify?
- What's the test plan?
- Any ambiguity in the spec? Ask now.

The human will approve the plan before you proceed. This catches misunderstandings cheaply.

### Step 4: Build, Test, Iterate

Standard development loop:
- Write the code
- Write the tests (or vice versa — TDD encouraged)
- Run tests locally
- Fix what's broken
- Repeat

### Step 5: Self-Audit Against Acceptance Criteria

Before declaring a milestone done, run through the acceptance criteria checklist yourself:
- Does each item pass?
- For items you can't verify alone (e.g., manual UI checks), explicitly flag them for the human

### Step 6: Submit For Review

- Create a PR to the `develop` branch
- Title: `feat(M{n}): <milestone name>`
- Description includes: completed criteria, test results, manual-test instructions, any deviations from spec
- Wait for human review before merging

### Step 7: Pause At The Pause Point

After the milestone is merged, **STOP**. Do not start the next milestone automatically. The human will explicitly initiate the next milestone.

This is non-negotiable. ADHD users build this app — the human builder needs the same forgiveness protocol the app provides.

---

## When To Ask The Human

You should pause and ask when:

| Situation | Action |
|---|---|
| Spec is ambiguous | Ask for clarification before guessing |
| External credentials needed | Stop, request from human, do not proceed |
| Migration would touch production data | Stop, get explicit approval |
| Tests fail in ways that suggest spec is wrong | Stop, discuss with human |
| Acceptance criteria can't be fully met | Stop, document why, ask for guidance |
| You hit a pause point | Stop, do not proceed |
| You discover a security risk not addressed in specs | Stop, raise it |
| You see an opportunity to improve a spec | Note it, but don't act unilaterally — propose first |

You should NOT pause and ask when:

| Situation | Action |
|---|---|
| Implementation detail not specified but obvious | Use industry best practice, document the choice |
| Code style choice within established conventions | Decide, be consistent |
| Library API choice between functionally identical options | Decide |
| Test coverage detail | Use your judgment per the milestone's test requirements |

---

## Anti-Patterns You Will Be Tempted Toward

These are common Claude Code patterns that **violate the Focus Forge spec**. Resist them.

### "I'll add a 'failed' status to make this easier"

❌ No. The Forgiveness Protocol is structural. Find another way.

### "I'll use red for the destructive action since the user clearly wants delete"

❌ No. Use `soft-destructive` button variant (fuchsia tint). The build will literally break if you write `text-red-500`.

### "I'll add a streak feature because users like gamification"

❌ No. Streaks that can break are RSD landmines. Repeatable badges are fine. Streaks are not.

### "I'll use a multi-column layout for power users"

❌ No. Single column on the main task interface, period. The user is not asking for power-user features — they're asking for cognitive offloading.

### "I'll make the timer use a digital countdown for simplicity"

❌ No. Analog wedge required. Digital countdowns require working memory; analog spatializes time.

### "I'll skip the rate limiting for the MVP"

❌ No. Rate limiting is in the spec for a reason: brute-force attacks are real even at 50 users.

### "I'll just use any free email provider"

⚠️ Pause and ask. Email reliability matters for magic links and password resets. The spec recommends Resend, but the human may want a different choice.

### "I'll mock the OpenAI calls in production for now"

❌ No. If OpenAI is needed for a milestone, get the API key from the human. Don't ship mocked AI to production.

### "I'll add a 'continue without saving' option"

❌ No. Auto-save is mandatory. There is no version of this app where the user has to remember to save.

### "I'll use localStorage for sessions"

❌ No. Sessions live in the database (per spec §3.1 of `01-authentication-and-user-model.md`). localStorage is XSS-vulnerable and can't be revoked server-side.

### "I'll use Auth.js v5 — it's newer and better"

❌ No. The spec specifies NextAuth.js v4 stable. v5 is in beta with shifting APIs. The spec wins.

### "I'll use UUIDv7 because it's modern"

❌ No. The spec specifies Prisma cuid(). UUIDv7 + Prisma + MySQL has known integration friction. Don't introduce that pain. Read doc 04 §2.2 for full reasoning.

### "I'll set up Server-Sent Events for real-time sync"

❌ No. The spec specifies 5-second short polling. Vercel Hobby plan can't sustain SSE connections. Read doc 04 §5 for full reasoning.

### "I'll use Vercel Blob for audio — it's built in"

❌ No. The spec specifies Cloudflare R2. R2 has no egress fees and 10GB free tier. Cost matters at scale; build it right the first time.

### "I'll add Apple Sign-In since we have other OAuth providers"

❌ No. Apple Sign-In is explicitly deferred to v2 (requires $99/yr Apple Developer Program). Don't surprise the human with that bill.

### "I'll use a cron job for quota resets"

❌ No. Quotas reset implicitly via the `usage_date_utc` column rolling over at 04:00 UTC. No cron needed. Adding one is wasted complexity.

### "I'll generate UI for the body doubling video myself with WebRTC"

❌ No. The spec specifies Jitsi Public Instance via iframe. Don't reinvent video infrastructure.

### "I'll add a Day 3 'we miss you' email — it's standard product practice"

❌ No. The spec explicitly forbids re-engagement emails. The Cognitive Therapist's red line. ADHD users find these humiliating. The ONLY transactional email after signup is the welcome email at signup itself.

### "I'll add downvotes to feedback items so users can express disagreement"

❌ No. Doc 04 §4.20 specifies upvotes only. Downvotes are RSD ammunition. If users disagree with a feature request, they simply don't vote on it. Disagreement that requires expression isn't healthy here.

### "I'll add a comment thread to feedback items so users can discuss"

❌ No. M16 explicitly defers user-to-user discussion. Only admin status updates appear on items. The forum framework is in place architecturally but NOT exposed in v1. Don't enable it without explicit project owner approval.

### "I'll show users their missed routine instances so they can catch up"

❌ No. Soft-track mode is the spec. Missed instances are silently logged and never surfaced. The Patterns view is opt-in, default off, and shows COMPLETION counts, not failure counts. "You missed X" framing is forbidden anywhere.

### "I'll add a streak counter to routines for motivation"

❌ No. Streaks that can break trigger RSD intensely. The spec bans them globally. Repeatable badges (e.g., daily_capture) are fine. Streak counters are not.

### "I'll let the AI nag the user about routine adjustments since it's a Pro feature"

❌ No. Even Pro AI suggestions are phrased as gentle offers ("Want to try X?"), never directives ("You should X"). The Cognitive Therapist's framing rule applies regardless of tier.

### "I'll mark the wontfix status as 'Rejected' since that's clearer"

❌ No. Doc 04 §4.19 and M16 specify neutral language: "Outside our current focus." Words matter. "Rejected" lands as personal rejection for RSD-prone users.

### "I'll send users notifications when other people vote on their submissions"

❌ No. Notifications should ONLY go to the submitter about admin status updates on their own submissions. Notifying about activity from other users creates attention churn AND potential RSD when someone DOESN'T get votes.

---

## Code Quality Standards

### TypeScript

- `strict: true`, `noUncheckedIndexedAccess: true`, `noImplicitOverride: true`
- No `any` without an `// eslint-disable-next-line` comment AND a justification
- Prefer `unknown` over `any` when the shape is genuinely unknown
- Prefer Zod schemas at all trust boundaries (API inputs, env vars, external responses)

### Component Architecture

- One component per file (with co-located tests)
- Props always typed via `interface` (not `type`) for components — easier to extend
- No default exports for components — named exports only (better refactoring)
- Server Components by default; `'use client'` only when needed

### Database Access

- ALWAYS through Prisma client — no raw SQL except for performance-critical reads
- Wrap mutations in transactions if they touch multiple tables
- Use `select` to fetch only needed fields (Prisma client otherwise returns everything)
- All queries that return user data MUST scope by `user_id` from session

### Error Handling

- Server actions return `Result<T, E>` types — never throw
- API routes return typed error responses with consistent shape
- Frontend gracefully handles errors per design system patterns (no red, no exclamation)
- Sentry captures unhandled errors in production

### Testing

- Unit tests: pure logic, run in <1s each
- Integration tests: include DB but use a transaction that rolls back
- E2E tests: hit a real Vercel preview deploy
- Aim for 80% coverage on `packages/domain` (pure logic), less elsewhere
- Every bug fix gets a regression test

### Accessibility

- Every component must pass axe-core with 0 violations in unit tests
- Every page must be keyboard-navigable
- Every interactive element has a visible focus ring
- All form inputs have associated labels
- All images have `alt` text
- `prefers-reduced-motion` is honored everywhere

### Performance

- Dashboard query <100ms (verified in M4)
- First Contentful Paint <1.5s on 4G
- Total bundle size <500KB initial load
- Lighthouse score ≥90 on all key pages

---

## The Spec Hierarchy When You're Stuck

When two parts of the spec seem to conflict:

```
1. Inviolable Rules (this doc, §"The Inviolable Rules")
   └── ALWAYS WIN
2. Implementation Specs (01-05)
   └── Win over foundational specs for HOW
3. Foundational Specs (0a-0e)
   └── Win for WHY and clinical rationale
4. Your judgment based on best practice
   └── Lowest priority — when nothing else specifies, decide
```

When in doubt: **ask the human, don't assume.**

---

## Pull Request Template

Every PR should include:

```markdown
## Milestone
M{n}: {milestone name}

## What's Done
- [ ] Acceptance criterion 1 (link to test or evidence)
- [ ] Acceptance criterion 2
- ...

## What's NOT Done (And Why)
- [ ] Acceptance criterion X — flagged for human verification (e.g., manual mobile install test)

## Test Results
- Unit: {n} passing
- Integration: {n} passing
- E2E: {n} passing
- axe-core: 0 violations

## Spec Deviations
{None / List with justification}

## Decisions Made
{Any ambiguity-resolution decisions, briefly}

## Manual Test Instructions
{Steps for the human to verify}

## Risks / Notes
{Anything the human should know}
```

---

## Communication With The Human

The human is your collaborator, not your boss. Behave accordingly:

- Be direct. Don't hedge unnecessarily.
- Flag risks early. Don't hide problems.
- Push back on bad ideas with evidence. The Task Force has done this for the human; you should too when warranted.
- Don't apologize repeatedly for mistakes — fix them and move on.
- When you don't know something, say so.
- When you're confident, be confident.

The human is building something they care about. Treat the code accordingly.

---

## Final Note

The user of this app — the person Focus Forge is built for — is someone whose brain has been failed by every productivity tool they've ever tried. They have been told their whole life that they "just need to try harder." Every feature you build either reinforces that lie or rejects it.

You are building rejection. You are building a tool that says "your brain is fine, the world is poorly designed, here's something that fits." Every design decision in the specs reflects that mission.

Keep that in mind when the implementation gets hard.

— The Focus Forge Task Force
