# Focus Forge — Build Roadmap

**Status:** Draft v1.0
**Owners:** ADHD Toolkit Task Force
**Architecture:** Vercel + cPanel MySQL + Monorepo + Prisma
**Builder:** Claude Code (primary) with human review at milestone gates

---

## How To Use This Document

This roadmap is structured for an AI coding agent to execute step by step. Each milestone is **atomic, verifiable, and rollback-able**.

### Reading Order
1. Read this entire file before starting Milestone 1.
2. Read the milestone you're working on in full before any code is written.
3. Refer to spec docs (`01–05`, `07`, `08`) when implementation details are unclear.
4. **Stop at every milestone gate** for human verification.

### What Each Milestone Contains
- **Goal** — One sentence: what's working at the end
- **Prerequisites** — What must be done first
- **Spec references** — Which other docs to consult
- **Files** — What to create/modify
- **Tasks** — Atomic, ordered steps
- **Tests** — Automated tests required (TDD encouraged but not mandatory)
- **Acceptance criteria** — Pass/fail gate
- **Manual smoke test** — What the human verifies
- **Pause point** — ✅ Safe to stop here

### Conventions
- All paths relative to monorepo root
- All commands assume `pnpm` package manager
- All code TypeScript with `strict: true`
- All tests use Vitest (unit/integration) + Playwright (E2E)
- All commits follow Conventional Commits format

---

## Phase Overview

```
PHASE 1: FOUNDATION (3 milestones)
  M1: Monorepo + Vercel + DB connection
  M2: Authentication system
  M3: Design system primitives

PHASE 2: VERTICAL SLICES (10 milestones)
  M4: Task capture + dashboard
  M5: Walk Me Through It
  M6: Analog Timer
  M7: Voice Dump + AI parsing
  M8: Reverse Scheduler / Doorknob
  M9: Launchpad
  M10: Praise Repository
  M11: Body Doubling
  M12: Body Check-Ins
  M13: Decision Paralysis Breaker

PHASE 3: LAUNCH PREP (2 milestones)
  M14: Onboarding flow + first-session experience
  M15: PWA + offline + production hardening

POST-LAUNCH (deferred):
  M16: Monetization (Stripe integration, Pro tier)
```

**Note on M16:** Build the entire app on the free tier first. Add paid-tier infrastructure once you have real users to validate pricing assumptions. The `feature_grants` table from M1 already supports this — you're just not using it yet.

---

# PHASE 1: FOUNDATION

## Milestone 1: Monorepo + Vercel + DB Connection

**Goal:** A deployed monorepo on Vercel that connects to your cPanel MySQL and shows a "Hello, Focus Forge" page.

**Prerequisites:**
- GitHub account
- Vercel account (free tier)
- cPanel access with Remote MySQL feature enabled
- OpenAI API key (will use later)
- Local Node 20+ and pnpm 9+ installed

**Spec references:** `04-mysql-schema.md` §3, §6

### Tasks

#### 1.1 Monorepo Scaffolding
```
- Initialize repo with pnpm workspaces:
  - Create root package.json with "workspaces": ["apps/*", "packages/*"]
  - Create pnpm-workspace.yaml
  - Create turbo.json (Turborepo for build orchestration)
  - Create tsconfig.base.json (extended by all packages)
  - Create .editorconfig, .gitignore, .nvmrc (Node 20)
  
- Create folder structure:
  apps/web/              (Next.js app)
  packages/database/     (Prisma + DB client)
  packages/ui/           (Design system — empty for now)
  packages/domain/       (Pure business logic — empty for now)
  packages/ai/           (OpenAI integration — empty for now)
  packages/config/       (Shared TS, ESLint configs)
```

#### 1.2 Next.js App
```
- cd apps/web
- pnpm create next-app@latest . --typescript --tailwind --app --no-src-dir
  - When prompted: use App Router, TypeScript yes, Tailwind yes, no src dir
- Install: prisma, @prisma/client, zod, lucide-react
- Configure tailwind.config.ts to extend from packages/ui (when ui exists)
- Add @ alias for app paths
```

#### 1.3 Prisma Setup
```
- cd packages/database
- pnpm init
- pnpm add prisma @prisma/client
- pnpm dlx prisma init --datasource-provider mysql
- Create the basic users table in schema.prisma (just enough for M2)
- Add prisma scripts: "generate", "migrate dev", "migrate deploy", "studio"
- Export Prisma client singleton from src/client.ts
```

#### 1.4 Remote MySQL Setup (cPanel side)
```
INSTRUCTIONS FOR HUMAN (Claude Code: pause and request human action):

1. Log into cPanel
2. Find "Remote MySQL" in the Databases section
3. Add Vercel's IP ranges to allowed hosts:
   - Vercel doesn't publish static IPs for free tier
   - Use "%" (any host) as a temporary measure for development
   - Document that this is a security tradeoff to revisit before paid launch
4. Create a new MySQL database: focus_forge
5. Create a new MySQL user with full access to focus_forge
6. Note the connection string format:
   mysql://USER:PASSWORD@your-cpanel-domain.com:3306/focus_forge
7. Provide this DATABASE_URL to Claude Code via .env.local
```

#### 1.5 Vercel Setup
```
- Push monorepo to GitHub (private repo)
- Import in Vercel:
  - Root Directory: apps/web
  - Framework Preset: Next.js
  - Build Command: pnpm build (Vercel auto-detects monorepo)
  - Install Command: pnpm install
  - Output Directory: .next
- Add environment variables in Vercel dashboard:
  - DATABASE_URL (from cPanel)
  - NEXTAUTH_SECRET (generate: openssl rand -base64 32)
  - NEXTAUTH_URL (https://your-vercel-url.vercel.app)
- Trigger first deploy
```

#### 1.6 Hello, Focus Forge
```
- Replace apps/web/app/page.tsx with a simple "Hello, Focus Forge" page
- Add a server component that queries the database (e.g., counts users — should return 0)
- Verify the DB connection works from Vercel
```

### Tests Required

```
packages/database/src/__tests__/client.test.ts:
  - Test that Prisma client connects (skip in CI without DB)

apps/web/__tests__/home.test.tsx:
  - Test that home page renders without error
  - Test that "Hello, Focus Forge" appears

CI setup:
  - GitHub Actions workflow runs lint + test on every push
  - .github/workflows/ci.yml: pnpm install, pnpm lint, pnpm test
```

### Acceptance Criteria

- [ ] `pnpm install` from repo root succeeds
- [ ] `pnpm dev` runs the web app locally on http://localhost:3000
- [ ] Home page shows "Hello, Focus Forge"
- [ ] `pnpm prisma migrate dev` creates the users table on cPanel MySQL
- [ ] phpMyAdmin shows the users table exists
- [ ] Vercel deploy succeeds and shows the same page at the public URL
- [ ] Vercel page successfully queries cPanel MySQL (e.g., count of users = 0)
- [ ] CI workflow runs and passes
- [ ] All TypeScript strict checks pass

### Manual Smoke Test (Human)

1. Open Vercel deploy URL → see "Hello, Focus Forge"
2. Open phpMyAdmin → see users table with 0 rows
3. Make a trivial change locally → push to GitHub → confirm Vercel auto-deploys

### ✅ PAUSE POINT — End of M1

Stop here. Verify everything works. The biggest deployment risks are now eliminated. Future milestones build on a known-working foundation.

---

## Milestone 2: Authentication System

**Goal:** Users can sign up and log in via email+password, Google, Apple, Facebook, and magic link. Sessions persist 30 days.

**Prerequisites:** M1 complete

**Spec references:** `01-authentication-and-user-model.md` (entire doc), `04-mysql-schema.md` §4.1–4.4

### Tasks

#### 2.1 Install Auth.js (NextAuth v5)
```
- pnpm add next-auth@beta @auth/prisma-adapter
- pnpm add @node-rs/argon2 (for password hashing)
- pnpm add resend (for transactional email — magic link, verification)
```

#### 2.2 Expand Prisma Schema
```
- Add all auth-related tables from 04-mysql-schema.md §4.1-4.4:
  - users (with all fields)
  - auth_methods
  - sessions
  - magic_link_tokens
  - password_reset_tokens
  - email_verification_tokens
  - feature_grants (set up structure now, populate later)
  - audit_log
- Run prisma migrate dev
- Verify in phpMyAdmin
```

#### 2.3 Configure Auth.js
```
- apps/web/lib/auth.ts: NextAuth config with all 4 providers
- Email provider configured for magic links via Resend
- Credentials provider for email+password
- Custom pages: /signin, /signup, /verify-email, /reset-password
- Custom callbacks for tier checks, feature_grants
- Session strategy: database (using sessions table)
```

#### 2.4 Auth UI Pages
```
- apps/web/app/(auth)/signin/page.tsx
- apps/web/app/(auth)/signup/page.tsx
- apps/web/app/(auth)/verify-email/page.tsx
- apps/web/app/(auth)/reset-password/page.tsx
- apps/web/app/(auth)/layout.tsx (centered, single-column)

These use raw HTML/Tailwind — design system components come in M3.
```

#### 2.5 Server Actions for Auth Flows
```
- apps/web/server-actions/auth/signup-with-password.ts
- apps/web/server-actions/auth/signin-with-password.ts
- apps/web/server-actions/auth/request-magic-link.ts
- apps/web/server-actions/auth/request-password-reset.ts
- apps/web/server-actions/auth/verify-email.ts
- apps/web/server-actions/auth/sign-out.ts

Each action:
  - Validates input with Zod
  - Logs to audit_log
  - Implements rate limiting (5 attempts per email per 15 min)
  - Returns typed result (not throwing)
```

#### 2.6 OAuth Provider Registration (Human action)
```
INSTRUCTIONS FOR HUMAN:

Google:
1. Go to console.cloud.google.com
2. Create project: "Focus Forge"
3. Configure OAuth consent screen
4. Create OAuth credentials → Web application
5. Authorized redirect URIs: 
   - http://localhost:3000/api/auth/callback/google
   - https://your-vercel-url.vercel.app/api/auth/callback/google
6. Copy Client ID and Secret to .env.local and Vercel env vars

Apple:
1. Requires Apple Developer Program ($99/yr) — needed only if shipping to iOS
2. Defer if not shipping iOS-installed PWA in v1
3. Document as TODO for paid launch

Facebook:
1. Go to developers.facebook.com
2. Create new app, type: Consumer
3. Add Facebook Login product
4. Settings → Basic: get App ID and App Secret
5. Add OAuth redirect URI same as Google
6. Copy to env vars
```

#### 2.7 Account Settings Page (Minimal)
```
- apps/web/app/(app)/account/page.tsx
- Shows current email, linked auth methods, "Sign out" button
- Full account management (delete, export) deferred to M14
```

### Tests Required

```
Unit tests (Vitest):
  - Password hashing/verification round-trip
  - Magic link token generation/validation
  - Email validation (edge cases: plus addressing, unicode)
  - Rate limiter logic

Integration tests:
  - Sign up with email+password creates user + auth_method rows
  - Sign in with correct password creates session
  - Sign in with wrong password does NOT create session, increments rate limit
  - Magic link flow end-to-end (mock email send)
  - Password reset flow end-to-end
  - OAuth callback creates user on first login, links on subsequent

E2E tests (Playwright):
  - User signs up with email+password → lands on dashboard
  - User signs out → can't access /account
  - User clicks "Forgot password" → receives email (mock) → resets → can log in
```

### Acceptance Criteria

- [ ] User can sign up with email+password
- [ ] User can sign in with email+password
- [ ] User can sign in with Google OAuth
- [ ] User can sign in with Facebook OAuth
- [ ] Apple OAuth is configured but skippable if no Apple Developer account
- [ ] User can request and use magic link
- [ ] Sessions survive page refresh and 30-day inactivity simulation
- [ ] Password reset flow works end-to-end
- [ ] Email verification works (banner shown until verified, doesn't block app)
- [ ] Rate limiting kicks in after 5 failed attempts
- [ ] No red colors anywhere in auth UI (audit with grep)
- [ ] All forms keyboard-accessible
- [ ] axe-core passes 0 violations on all auth pages
- [ ] All tests pass

### Manual Smoke Test (Human)

1. Sign up with a real email — receive welcome
2. Log out, log back in with password
3. Log out, log in with Google
4. Log out, request magic link, click email link, verify auto-login
5. Forget password, reset, log in with new password
6. Check phpMyAdmin: users, auth_methods, sessions all populated correctly
7. Try to log in with wrong password 6 times → rate limit message appears

### ✅ PAUSE POINT — End of M2

Auth is the most security-sensitive milestone. Verify thoroughly before continuing.

---

## Milestone 3: Design System Primitives

**Goal:** Core UI components built and themed. Dark mode default. No red anywhere. Components live in `packages/ui` and are consumed by `apps/web`.

**Prerequisites:** M2 complete

**Spec references:** `02-design-system.md` (entire doc)

### Tasks

#### 3.1 Tailwind Config + Tokens
```
- packages/ui/tailwind.preset.ts: 
  - All color tokens from 02-design-system.md §2
  - All typography tokens from §3
  - All spacing/radius/shadow tokens from §4-7
  - Red removal via Proxy (§13.2)
- packages/ui/styles/globals.css:
  - CSS variables for both dark and light themes
  - Reduced-motion media query
- apps/web tailwind.config.ts extends the preset
```

#### 3.2 Component Library — Primitives
```
packages/ui/src/components/:

- Button.tsx (variants: primary, secondary, ghost, soft-destructive)
- IconButton.tsx (always with aria-label)
- Input.tsx (text, email, password, with show/hide toggle)
- Textarea.tsx (auto-growing)
- Select.tsx (native on mobile, custom on desktop)
- Checkbox.tsx
- Radio.tsx
- Toggle.tsx
- Slider.tsx
- Label.tsx

All components:
  - Use CSS variables (no hardcoded colors)
  - 44×44px minimum touch targets
  - Visible focus rings (--accent, 2px, 2px offset)
  - TypeScript prop types exported
  - JSDoc comments with examples
```

#### 3.3 Component Library — Containers
```
- Card.tsx
- Modal.tsx (focus trap, Esc-to-close, backdrop click)
- Drawer.tsx (slides from right)
- Toast.tsx (4s auto-dismiss, soft, non-blocking)
- ToastProvider.tsx (root provider for app)
```

#### 3.4 Component Library — Feedback
```
- EmptyState.tsx (illustration + message + single CTA)
- LoadingSpinner.tsx
- SkeletonLoader.tsx
- ErrorBoundary.tsx (graceful fail, Forgiveness Protocol — no red)
```

#### 3.5 Theme Provider
```
- packages/ui/src/theme/ThemeProvider.tsx
- Reads user preference from cookie / DB
- Falls back to prefers-color-scheme
- Applies data-theme attribute to <html>
```

#### 3.6 Storybook (Highly Recommended)
```
- pnpm dlx storybook@latest init in packages/ui
- Story file for every component
- This is your visual QA tool
```

#### 3.7 Apply To Auth Pages (Refactor)
```
- Refactor M2 auth pages to use new components
- This ensures the design system actually works under load
- Verify dark mode looks correct on all auth screens
```

### Tests Required

```
Unit tests:
  - Each component renders without crashing
  - Each component respects disabled state
  - Each component respects required ARIA attributes
  - ThemeProvider correctly switches themes

Visual regression (optional but recommended):
  - Storybook + Chromatic, or 
  - Playwright screenshot tests for each component

Accessibility tests:
  - axe-core integration in component tests
  - 0 violations required
```

### Acceptance Criteria

- [ ] All components in packages/ui exist with TypeScript types
- [ ] Storybook runs and shows every component in dark + light mode
- [ ] Auth pages refactored to use design system
- [ ] Build error if any code uses Tailwind red-* class
- [ ] axe-core: 0 violations on Storybook pages
- [ ] All components keyboard-navigable
- [ ] prefers-reduced-motion honored (verify with DevTools)
- [ ] All components have JSDoc with usage examples

### Manual Smoke Test (Human)

1. Open Storybook → tab through every component
2. Toggle dark/light theme → all components look correct
3. Enable "Reduce motion" in OS settings → animations disabled
4. Open auth pages → look identical to Storybook in dark mode
5. Try to write `text-red-500` somewhere → build fails with helpful error

### ✅ PAUSE POINT — End of M3 — End of Phase 1

Phase 1 complete. Foundation is solid. Vertical slices begin.

---

# PHASE 2: VERTICAL SLICES

## Milestone 4: Task Capture + Dashboard

**Goal:** Logged-in user can type a task, see it appear on the dashboard, mark it Complete or Defer. Forgiveness Protocol enforced everywhere. First Capture Badge fires on first task.

**Prerequisites:** M3 complete

**Spec references:** `04-mysql-schema.md` §4.5–4.6, §4.8, §4.15; `02-design-system.md` §9.4 (TaskCard, PriorityBadge); `03-onboarding-flow.md` §3

### Tasks

#### 4.1 Schema Additions
```
- Add to Prisma schema:
  - tasks
  - task_steps
  - badges (table for definitions)
  - user_badges
  - events (append-only log)
- pnpm prisma migrate dev
- Seed badges table (first_capture, first_step, first_focus, first_complete, etc.)
- See 04-mysql-schema.md §8 for seed data
```

#### 4.2 Task Domain Logic
```
packages/domain/src/tasks/:

- create-task.ts (input → tasks row + event log)
- complete-task.ts (status active → completed, badge check)
- defer-task.ts (status → deferred, increment deferred_count silently)
- list-active-tasks.ts (dashboard query, see schema doc §7.1)

Each function:
  - Pure logic, no UI
  - Returns typed Result<T, E>
  - Records to events table
  - Triggers badge engine check
```

#### 4.3 Badge Engine
```
packages/domain/src/badges/:

- check-and-award.ts (subscribe to events, award badges)
- get-user-badges.ts
- The engine reads from events table, not feature tables
- First Capture badge: fires on first task.created event for user
- Idempotent — running twice doesn't double-award
```

#### 4.4 Server Actions
```
apps/web/server-actions/tasks/:

- create-task.ts
- complete-task.ts
- defer-task.ts (with optional "defer until" datetime)
- update-task-priority.ts

All call domain functions, handle authentication, return typed results.
```

#### 4.5 Dashboard Page
```
- apps/web/app/(app)/page.tsx (the post-login landing)
- Shows:
  - User's display name or "you"
  - List of active tasks (single column)
  - "Capture another thought" input at top
  - Empty state if no tasks (per spec §11.1)
- Real-time updates via SSE (M4 sets this up; reused later)
```

#### 4.6 TaskCard Component
```
- packages/ui/src/components/TaskCard.tsx
- Shows: title, priority pill, scheduled time if any, step progress
- Actions: "Done. Next step." / "Push to later"
- NO red, NO "delete," NO "overdue"
```

#### 4.7 SSE Setup
```
- apps/web/app/api/stream/route.ts (Server-Sent Events endpoint)
- 2-second polling of events table for the user
- Client uses EventSource to subscribe
- Updates Zustand store on new events
- Connection auto-recovers on disconnect
```

### Tests Required

```
Unit tests:
  - create-task: validates input, creates row, logs event
  - complete-task: respects ENUM values, awards First Complete badge first time
  - defer-task: increments counter silently, never visible to user
  - Badge engine: idempotent, fires correct badges

Integration tests:
  - POST to create-task action: full round-trip
  - Dashboard page loads tasks for current user only
  - SSE endpoint streams updates correctly

E2E tests (Playwright):
  - User logs in → captures first task → sees First Capture Badge toast
  - User completes task → sees First Complete badge
  - User defers task → it disappears from dashboard, reappears at deferred time
  - Two browser tabs: change in one, appears in other within 3 seconds
```

### Acceptance Criteria

- [ ] User can capture a task via text input
- [ ] Task appears immediately on dashboard
- [ ] First Capture Badge fires on first task creation, only once
- [ ] User can mark task complete → "Done. Next step." → animation plays
- [ ] User can defer task → removed from view, no shame language
- [ ] Status enum cannot be set to "failed" (TS error)
- [ ] Priority enum cannot be set to "urgent" or "red" (TS error)
- [ ] Dashboard query returns in <100ms with 1000 tasks (load test)
- [ ] SSE keeps two tabs in sync within 3s
- [ ] No red colors anywhere
- [ ] Empty state per design system spec
- [ ] All tests pass
- [ ] axe-core 0 violations

### Manual Smoke Test (Human)

1. Log in → land on empty dashboard with empty state
2. Type "Buy oranges" → press Enter → see TaskCard appear
3. See First Capture Badge toast
4. Mark complete → animation, task moves out
5. Add task, defer for 1 hour → it disappears, reappears after 1 hour
6. Open second tab → both stay in sync

### ✅ PAUSE POINT — End of M4

The core loop works. Every subsequent milestone extends from here.

---

## Milestone 5: Walk Me Through It

**Goal:** When user has multi-step task, they can enter a focused single-step mode that hides all other UI.

**Prerequisites:** M4 complete

**Spec references:** `Detailed_ADHD_Forge_Document.pdf` §3.1; `Comprehensive_Multidisciplinary_Framework_*.pdf` §9 Tool 2

### Tasks

#### 5.1 Manual Step Creation (AI integration in M7)
```
- Edit task UI: "Add steps" button
- User can manually add ordered steps to a task
- packages/domain/src/tasks/add-step.ts
- packages/domain/src/tasks/complete-step.ts
- packages/domain/src/tasks/reorder-steps.ts
```

#### 5.2 Walk-Through UI
```
- apps/web/app/(app)/walk/[taskId]/page.tsx
- Full-screen, single-column, hides nav
- Shows ONE step at a time
- Big "Done. Next step." button
- "Pause" button returns to dashboard, preserves position
- ESC key acts as Pause
```

#### 5.3 First Step Badge
```
- Add to events: task_step.completed
- Badge engine: first_step badge fires on first step completion
```

### Tests Required

```
Unit:
  - add-step: validates order, returns step
  - complete-step: marks complete, awards badge
  - Step ordering remains stable on completion

E2E:
  - User adds 3 steps to task → enters walk-through → completes each → returns to dashboard
  - User pauses mid-walk → resumes → starts at correct step
  - User completes all steps → task auto-completes → First Complete badge
```

### Acceptance Criteria

- [ ] User can add steps to a task
- [ ] Walk-through mode shows one step at a time
- [ ] No other UI visible in walk-through
- [ ] First Step badge fires correctly
- [ ] ESC pauses
- [ ] Mobile-friendly (works in PWA)
- [ ] All tests pass

### Manual Smoke Test (Human)
1. Add 3 steps to a task
2. Click "Walk Me Through It"
3. Complete each step in turn
4. Confirm dashboard shows task complete

### ✅ PAUSE POINT — End of M5

---

## Milestone 6: Analog Timer

**Goal:** User can start a timer with a diminishing wedge visual, optional Sound Family alerts, and Picture-in-Picture pop-out.

**Prerequisites:** M5 complete

**Spec references:** `Detailed_ADHD_Forge_Document.pdf` §3.2; `Comprehensive_Multidisciplinary_Framework_*.pdf` §4

### Tasks

#### 6.1 Timer Domain Logic
```
packages/domain/src/timer/:
- focus-session.ts (start/pause/resume/end)
- sound-families.ts (definitions)
```

#### 6.2 Schema
```
Add to Prisma:
- focus_sessions (per schema doc §4.12)
```

#### 6.3 AnalogTimer Component
```
packages/ui/src/components/AnalogTimer.tsx:
- SVG-based wedge that diminishes
- Color zones (yellow → green → mauve as time elapses)
- Smooth animation, respects prefers-reduced-motion
- Configurable duration (15/25/45 min presets + custom)
```

#### 6.4 Sound Family System
```
- Pre-recorded audio files in apps/web/public/sounds/families/
- soft_chimes/ (variations 1-5)
- singing_bowls/ (variations 1-5)
- pink_noise_pulse/ (variations 1-3)
- Random selection on each interval to prevent habituation
```

#### 6.5 Picture-in-Picture
```
- "Pop out" button uses documentPictureInPicture API
- Falls back to a normal floating window if API unavailable
- Pop-out shows minimal timer UI only
```

#### 6.6 First Focus Badge
```
- Event: focus_session.started → first_focus badge
- Event: focus_session.completed → focus_complete badge (repeatable)
```

### Tests Required

```
Unit:
  - Timer start/pause/resume/end state transitions
  - Sound family selection randomness
  - Wedge percentage calculation accuracy

Integration:
  - focus_sessions row created on start, updated on end
  - Badge fires correctly

E2E:
  - User starts 30-second timer → wedge animates → completes → badge
  - User pops out timer → floating window appears
  - User pauses, resumes, completes
```

### Acceptance Criteria

- [ ] Three preset durations + custom
- [ ] Visual wedge accurate to ±1 second
- [ ] Sound Family cycles variations correctly (no two consecutive same)
- [ ] Picture-in-Picture works in Chrome/Edge
- [ ] Fallback floating window in Safari/Firefox
- [ ] Mobile: timer works in foreground
- [ ] First Focus and Focus Complete badges fire
- [ ] All tests pass

### Manual Smoke Test (Human)
1. Start 25-min timer → see wedge animate
2. Pop out → floating window, return to other tabs
3. Wait for completion → hear sound, see badge

### ✅ PAUSE POINT — End of M6

---

## Milestone 7: Voice Dump + AI Parsing

**Goal:** User can hold a button to record audio, which is transcribed via Whisper and parsed into structured tasks via GPT-4o-mini.

**Prerequisites:** M6 complete

**Spec references:** `ADHD_Forge_Tech_Specs.pdf` §2; `Detailed_ADHD_Forge_Document.pdf` §3.1; `01-authentication-and-user-model.md` §11.2

### Tasks

#### 7.1 OpenAI Integration
```
packages/ai/src/:
- whisper-client.ts (transcription)
- gpt-task-parser.ts (text → structured tasks)
- prompts/task-parsing.ts (the actual prompt)

The task-parsing prompt must:
- Extract distinct tasks from messy text
- Suggest priority (bronze/silver/gold/amber — never urgent)
- Suggest steps if task is complex
- Detect time references ("tomorrow at 3pm")
- Return JSON matching strict schema
```

#### 7.2 Audio Recording
```
- packages/ui/src/components/VoiceDumpButton.tsx
- Hold-to-record using MediaRecorder API
- Visual feedback: pulsing waveform during recording
- Falls back silently to text input if mic denied
```

#### 7.3 Audio Upload Flow
```
- POST /api/voice-dump (multipart upload)
- Audio sent to Whisper
- Audio deleted immediately after transcription
- Transcript sent to GPT-4o-mini for parsing
- Parsed tasks created in DB
- Audio NEVER persisted (per spec)
```

#### 7.4 Quota Enforcement (Even Without Paid Tier Yet)
```
- Add quota_usage table to schema
- Implement checkQuota() and incrementQuota() per 05-monetization-strategy.md §4
- All users get free-tier quotas (10 voice dumps/day)
- "Quota reached" UI per spec
- This is infrastructure for M16; build now to avoid retrofit
```

### Tests Required

```
Unit:
  - Task parser handles multiple tasks, single task, ambiguous text
  - Whisper client error handling
  - Quota check fail-open behavior

Integration:
  - POST /api/voice-dump → tasks created (mock OpenAI)
  - Quota increments correctly
  - Quota reached → returns 429 with reset time

E2E:
  - User records 5-second audio → tasks appear on dashboard
  - User records 11 times → 11th shows quota UI with "Type instead"
```

### Acceptance Criteria

- [ ] Voice recording works in Chrome, Safari, Firefox
- [ ] Whisper transcription succeeds
- [ ] GPT-4o-mini returns valid JSON
- [ ] Audio file deleted within 60s of transcript receipt
- [ ] Quota enforced at 10/day for free users
- [ ] Reset at 04:00 user-local time
- [ ] Mic permission denied → silent fallback to text
- [ ] All tests pass

### Manual Smoke Test (Human)
1. Hold mic button, say "Email Sarah back, get groceries, and book the dentist"
2. See three tasks appear
3. Use voice dump 11 times → see quota UI
4. Wait until 4 AM next day → quota reset

### ✅ PAUSE POINT — End of M7

---

## Milestone 8: Reverse Scheduler / Doorknob

**Goal:** User inputs an arrival time, transit duration, and pre-departure tasks. The app calculates backward and shows color-coded zones with a "+15 min" recalculator.

**Prerequisites:** M7 complete (uses AI for task parsing of "I need to leave at 3pm" inputs)

**Spec references:** `Detailed_ADHD_Forge_Document.pdf` §3.2; `Comprehensive_Multidisciplinary_Framework_*.pdf` §5

### Tasks

#### 8.1 Doorknob Domain Logic
```
packages/domain/src/doorknob/:
- calculate-schedule.ts (arrival - transit - tasks = start time)
- recalculate-late.ts (push entire schedule +15 min)
- zones.ts (yellow/green/mauve color logic)
```

#### 8.2 DoorknobTimeline Component
```
packages/ui/src/components/DoorknobTimeline.tsx:
- Horizontal timeline (special case from single-column rule)
- Color-coded zones per spec
- Current position indicator
- "+15 min" button
```

#### 8.3 Doorknob Setup Flow
```
- apps/web/app/(app)/doorknob/page.tsx
- Step 1: When do you need to be there?
- Step 2: How long is the trip?
- Step 3: Select pre-departure tasks (from Launchpad in M9, or freeform now)
- Result: full timeline shown
```

#### 8.4 Scheduled Alerts
```
Add to schema: scheduled_alerts (per §4.14)
- Cron job (Vercel Cron) fires alerts at zone transitions
- Browser notifications (with permission)
```

### Tests Required

```
Unit:
  - calculateSchedule correct for various inputs
  - recalculateLate adds 15 min to all downstream
  - Zone boundaries correct

E2E:
  - User creates Doorknob session → timeline displays
  - Click "+15 min" → all zones shift correctly
  - Browser notification at zone transition (mock)
```

### Acceptance Criteria

- [ ] Backward calculation correct
- [ ] Color zones match spec
- [ ] +15 button works in 1 click
- [ ] Scheduled alerts fire on time
- [ ] All tests pass

### ✅ PAUSE POINT — End of M8

---

## Milestone 9: Launchpad

**Goal:** User has a checklist of items by the door. Resets daily at user-defined time.

**Prerequisites:** M8 complete

**Spec references:** `Comprehensive_Multidisciplinary_Framework_*.pdf` §5; `04-mysql-schema.md` §4.11

### Tasks

#### 9.1 Schema + Domain
```
- launchpad_items table per §4.11
- Domain: add-item, check-item, reorder-items, reset-daily
- Vercel Cron: daily reset job (runs at 04:00 in each timezone — group by tz)
```

#### 9.2 Launchpad UI
```
- apps/web/app/(app)/launchpad/page.tsx
- Add to dashboard: launchpad summary widget
- Integrate with Doorknob: select Launchpad items as pre-departure tasks
```

#### 9.3 Nightly Reminder
```
- Scheduled alert: "Time to set up tomorrow's launchpad"
- User-configurable time (default 21:00 local)
```

### Tests Required

```
Unit:
  - Daily reset only resets items where reset_schedule = 'daily'
  - Timezone handling for reset time

E2E:
  - User adds Keys, Wallet, Lunch
  - Checks them off
  - At 04:00 local time, all unchecked again
```

### Acceptance Criteria

- [ ] Items persist across sessions
- [ ] Daily reset fires at correct local time
- [ ] Nightly reminder works
- [ ] Integrates with Doorknob mode

### ✅ PAUSE POINT — End of M9

---

## Milestone 10: Praise Repository

**Goal:** Users can invite trusted contacts (max 5 free), who can record voice memos. Memos play with speed controls. AI transcripts are Pro-only.

**Prerequisites:** M9 complete

**Spec references:** `Comprehensive_Multidisciplinary_Framework_*.pdf` §8; `04-mysql-schema.md` §4.9-4.10; `01-authentication-and-user-model.md` §10

### Tasks

#### 10.1 Trusted Contacts
```
- Schema: trusted_contacts table per §4.10
- /account/praise-senders page
- Generate unique invite link with signed token
- 5-contact free limit (quota check)
```

#### 10.2 Sender Flow (No Account Needed)
```
- /praise/[token] page (public)
- Sender enters display name, records up to 3 memos
- Token expires 7 days after first use
- Audio uploaded to Vercel Blob storage
```

#### 10.3 Recipient Flow
```
- /praise inbox page
- Memo cards with playback, speed controls (1x, 1.25x, 1.5x)
- Categories: "Listen when overwhelmed", "Before a big task", "After a failure"
- AI transcription gated behind Pro tier (free users see audio only)
- 5-active-memo free limit (oldest archived when adding 6th)
```

#### 10.4 Audio Storage
```
- Vercel Blob for audio (not cPanel disk — Vercel is serverless)
- Signed URLs valid 1 hour
- File size limit: 60 seconds max per memo
```

### Tests Required

```
Unit:
  - Token signing/verification
  - Free-tier limit enforcement
  - Audio upload validation

Integration:
  - Sender flow end-to-end (mock storage)
  - Recipient sees new memos within 5 seconds via SSE

E2E:
  - User creates invite → opens in incognito → records → user receives memo
  - User has 5 memos → 6th memo arrives → oldest auto-archived
```

### Acceptance Criteria

- [ ] Invite links work without sender account
- [ ] 5-contact, 5-memo, 60-second limits enforced
- [ ] Audio stored privately on Vercel Blob
- [ ] Signed URLs expire correctly
- [ ] Speed controls work
- [ ] AI transcription gated to Pro (returns null for free users)
- [ ] Sender abuse detection (rate limit by IP on token page)

### ✅ PAUSE POINT — End of M10

---

## Milestone 11: Body Doubling (Decision Pending)

**Status:** Awaiting your decision on Jitsi vs Daily.co.

**Goal:** Pro users can join 24/7 silent co-working rooms with synchronized Pomodoro timer.

**Prerequisites:** M10 complete

**Spec references:** `Comprehensive_Multidisciplinary_Framework_*.pdf` §7

### High-Level Tasks (Implementation differs by provider)

```
- Room infrastructure (Jitsi iframe OR Daily.co SDK)
- Drop-in room list page (Pro-gated)
- Synchronized Pomodoro timer overlay
- Quiet Mode default (mic off, blur on)
- Reporting tooling
- 24/7 always-on rooms (5 themed: "Silent Cafe", "Library Quiet", etc.)
```

### Tests Required
- Connection establishment
- Room state sync
- Permission gating (free users see "Pro feature" page)
- Mute/blur defaults

### ✅ PAUSE POINT — End of M11

**Note:** Build this last among Phase 2 items if your decision is still pending. Other features don't depend on it.

---

## Milestone 12: Body Check-Ins

**Goal:** During focus sessions ≥60 minutes, gentle prompts ask about water, tension, posture.

**Prerequisites:** M6 complete (uses focus_sessions); can be done anytime after M6

**Spec references:** `Comprehensive_Multidisciplinary_Framework_*.pdf` §9 Tool 1

### Tasks

```
- Schema: check_ins table per §4.13
- Random selection from prompt library
- Non-blocking toast notification during long sessions
- Default ON for sessions ≥60 min, configurable
- Settings: enable/disable, prompt categories
```

### Tests
- Prompt fires at correct interval
- Response captured correctly
- Session ends → no more prompts
- Badge: check_in_yes fires on first response

### ✅ PAUSE POINT — End of M12

---

## Milestone 13: Decision Paralysis Breaker

**Goal:** When user has 3+ tasks and hasn't started one in 24 hours, surface a "Help Me Decide" prompt that uses AI to pick 2 options.

**Prerequisites:** M7 complete (uses AI)

**Spec references:** `Comprehensive_Multidisciplinary_Framework_*.pdf` §9 Tool 2

### Tasks

```
- Detection logic: 3+ active tasks, no task completion in 24h
- "Help Me Decide" button on dashboard
- AI prompt: given task list, return 2 micro-step recommendations
- Quota: 3/day free
- Modal UI: two big buttons with the recommended steps
- Selecting one creates a task_step and enters Walk-Through mode
```

### Tests
- Trigger correctness
- AI returns exactly 2 options
- Quota enforcement
- Selection flows into Walk-Through

### ✅ PAUSE POINT — End of M13 — End of Phase 2

All features functional. Pre-launch hardening begins.

---

# PHASE 3: LAUNCH PREP

## Milestone 14: Onboarding Flow + First-Session Experience

**Goal:** New users complete the full onboarding per spec, including First Capture, badge surfacing, and Phase 3 progressive discovery.

**Prerequisites:** M4–M13 complete

**Spec references:** `03-onboarding-flow.md` (entire doc)

### Tasks

```
- /welcome page (post-signup landing)
- First-capture flow per spec §3
- Discovery card system
- Triggers per spec §5.1
- Returning-user logic per spec §8
- Telemetry events per spec §9
- Skip path on every step
- Email verification banner (non-blocking)
```

### Tests
- Full first-touch flow under 90 seconds
- Skip path bypasses without errors
- Discovery cards trigger correctly
- No re-engagement loops
- Returning user experience contains no shame language

### Acceptance Criteria

- [ ] All §12 acceptance criteria from 03-onboarding-flow.md met

### ✅ PAUSE POINT — End of M14

---

## Milestone 15: PWA + Offline + Static Pages + Production Hardening

**Goal:** App is installable as PWA on mobile, core features work offline, all static pages (About, References, legal) are live, CI link checker is running, and production is ready for real users.

**Prerequisites:** M14 complete

**Spec references:** `08-page-content-and-references.md` (entire doc)

### Tasks

#### 15.1 PWA Manifest
```
- public/manifest.json with icons, theme colors, name
- next.config.mjs with next-pwa or built-in PWA support
- Service worker for offline support
```

#### 15.2 Offline Support
```
- Cache: dashboard, active tasks, timer, design system
- Queue: task creation, completion (sync when online)
- Offline banner: "Working offline. Changes will sync."
```

#### 15.3 Account Settings (Full)
```
- Data export (JSON download)
- Delete account flow with 30-day grace
- Theme toggle
- Sound family preference
- Notification preferences
- Linked auth methods
- Settings → About link (jumps to /about)
```

#### 15.4 Static Pages — About, References, Legal
```
Per spec 08-page-content-and-references.md:

a) Reference Data Source
   - Create apps/web/data/references.json with all 75 references
     categorized per spec §3.2
   - Validate against TypeScript schema from spec §3.1
   - Each foundational/supporting reference has annotation

b) About Page
   - apps/web/app/about/page.tsx
   - Content from spec §4.1 (markdown source of truth)
   - Single column, max-w-65ch, design system tokens
   - Links to /about/references

c) References Page
   - apps/web/app/about/references/page.tsx
   - Renders categorized references with disclaimer (spec §2.2)
   - ReferenceCard component per spec §2.3
   - Search/filter input (client-side, instant)
   - All external links: target="_blank" rel="noopener noreferrer"
   - Small external-link icon next to each title
   - "Last updated: [date]" displays from references.json
   - Display weight indicator subtly (e.g., foundational refs slightly emphasized)

d) Footer Component
   - packages/ui/src/components/Footer.tsx
   - Layout per spec §5.1
   - Links per spec §5.2
   - Tagline per spec §5.3
   - Persistent on all non-auth pages
   - Auth pages keep minimal/no footer

e) Legal Pages
   - apps/web/app/privacy/page.tsx (Privacy Policy)
   - apps/web/app/terms/page.tsx (Terms of Service)
   - apps/web/app/refunds/page.tsx (Refund Policy)
   - Use Termly/Iubenda generated content for v1
   - Single column, design system tokens
```

#### 15.5 CI Link Checker
```
Per spec 08-page-content-and-references.md §6:

- Create .github/workflows/check-references.yml per spec §6.2
- Create scripts/post-link-check-results.js for result handling
- Configure result handling per spec §6.3:
  - Scheduled (weekly): opens GitHub issue if broken links found
  - PR (when references.json changes): comments with results, fails on NEW breaks
  - Manual: console output
- Test with deliberately broken URL (should be caught and flagged)
- Update references.json lastUpdated field on each successful run
```

#### 15.6 Production Hardening
```
- Sentry error tracking (free tier)
- Vercel Analytics (free)
- Rate limiting on all API routes
- Content Security Policy headers
- HSTS, security headers
- robots.txt, sitemap.xml (include /about and /about/references)
```

#### 15.7 Performance Audits
```
- Lighthouse score ≥90 on all key pages
- Core Web Vitals: LCP <2.5s, FID <100ms, CLS <0.1
- Database query performance: dashboard <100ms
- Reference page initial render <1s (75 entries should not slow page)
```

### Tests Required

```
Unit tests:
  - References JSON validates against TypeScript schema
  - Reference card component renders all reference types
  - Search/filter logic correctly matches title, publisher, annotation
  - Footer renders correct links

Integration tests:
  - About page renders all section content
  - References page renders all categories with correct counts
  - Search input filters results without page reload
  - External links have correct rel attributes
  - 404 page renders with footer
  - Legal pages all return 200

E2E tests (Playwright):
  - User clicks footer "References" link from any page → lands on References
  - User searches "time blindness" → results filter live
  - User clicks external reference → opens in new tab (verify target attribute)
  - User navigates Settings → About → References (full path works)
  - Reduced-motion preference honored on References page

CI Link Checker tests:
  - Workflow runs on schedule
  - Workflow runs on PR touching references.json
  - Adding a known-broken URL to a PR fails the check
  - Existing-broken URL from scheduled run opens GitHub issue, doesn't fail builds

Accessibility tests:
  - axe-core: 0 violations on About page
  - axe-core: 0 violations on References page
  - All references keyboard-navigable
  - Reading-level check on About page content (Flesch-Kincaid 8th grade)
```

### Acceptance Criteria

- [ ] App installable on iOS and Android
- [ ] Offline support works for: dashboard, active tasks, timer
- [ ] Account deletion works end-to-end with 30-day grace
- [ ] Data export produces valid JSON
- [ ] Sentry captures errors in production
- [ ] All Lighthouse scores ≥90
- [ ] All security headers verified
- [ ] **About page live with all content from spec §4.1**
- [ ] **References page live with all 75 references categorized**
- [ ] **Disclaimer block visible at top of References page**
- [ ] **All foundational/supporting references have annotations**
- [ ] **Footer present on all non-auth pages with all 6 links**
- [ ] **Search/filter on References page works without page reload**
- [ ] **All external links use rel="noopener noreferrer"**
- [ ] **No tracking on outbound link clicks**
- [ ] **CI link checker workflow exists and runs successfully**
- [ ] **CI link checker correctly catches a deliberately broken test URL**
- [ ] **lastUpdated date displays correctly on References page**
- [ ] Privacy Policy, Terms of Service, Refunds pages live
- [ ] axe-core: 0 violations on all static pages

### Manual Smoke Test (Human)

1. Install PWA on iPhone
2. Use offline → tasks still accessible
3. Reconnect → changes sync
4. Trigger error → see in Sentry
5. Run Lighthouse → all green
6. **Open homepage → verify footer present with all links**
7. **Click "References" in footer → land on References page**
8. **Verify disclaimer is visible at top**
9. **Verify references are organized into 6 categories**
10. **Search "Barkley" → see relevant references filter**
11. **Click an external reference → opens in new tab, no Focus Forge tracking**
12. **Navigate Settings → About → click References link**
13. **Manually test CI link checker:**
    - Add a deliberately broken URL to references.json on a test branch
    - Open PR → verify CI fails the check
    - Remove the broken URL → verify CI passes
14. **Verify "Last updated" date is recent**

### ✅ PAUSE POINT — End of M15 — Phase 3 Complete

**You can launch here.** M16 (paid tier) comes after you have real users on the free tier.

---

# POST-LAUNCH

## Milestone 16: Monetization (Stripe + Pro Tier)

**Goal:** Free users can upgrade to Pro. Paid users get unlimited quotas and Body Doubling. Legacy migration plan documented and ready.

**Prerequisites:** M15 complete + at least 50 active free users

**Spec references:** `05-monetization-strategy.md` (entire doc)

### Tasks
```
- Stripe account, Products, Prices configured
- subscriptions table per spec §6.3
- Stripe webhook endpoint
- Customer Portal integration
- Quota check expansion: paid users skip checks
- Pro upgrade page with pricing
- Donation page with Supporter badge
- Legacy migration script (do not run yet — script is for future)
- Email templates: legacy notice, payment failed, etc.
```

### Tests
- Webhook handles all 5 event types
- Tier sync from Stripe → DB
- Past-due grace period (3-day soft, 7-day revert)
- Customer Portal flow
- Refund handling (manual)
- Account deletion + active subscription

### Manual Smoke Test (Human)
1. Subscribe via Stripe Test Mode → tier updates
2. Cancel subscription → tier reverts at period end
3. Trigger payment failure → grace period UI
4. Use Customer Portal → manages everything

### Acceptance Criteria

- [ ] All §14 acceptance criteria from 05-monetization-strategy.md met

---

# Cross-Cutting Concerns

## Documentation Updates
After every milestone:
- Update README.md with current capabilities
- Add ADR (Architecture Decision Record) for significant choices
- Update API reference if new endpoints added

## Database Migrations
- Every schema change = a new migration file
- Migrations are forward-only (no rollback in v1)
- Test migrations on staging copy before production
- phpMyAdmin for inspection, never for direct schema edits

## Branch Strategy
```
main           ← production
develop        ← integration
feature/M{n}-* ← per-milestone work
hotfix/*       ← critical production fixes
```

## Code Review (When Human + AI Collaborate)
- Claude Code submits PRs to `develop`
- Human reviews + tests on Vercel preview deploy
- Merge after acceptance criteria met
- `develop` → `main` only after milestone passes manual smoke test

## When To Ask The Human

Claude Code should pause and ask the human when:
- A spec doc is ambiguous on an implementation choice
- An external service (Stripe, OpenAI) needs credentials
- A migration would touch production data
- Tests fail in ways that suggest spec changes needed
- A milestone's acceptance criteria can't be fully met as written
- A pause point is reached
