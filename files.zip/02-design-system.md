# Focus Forge — Design System Specification

**Status:** Draft v1.0
**Owners:** ADHD Toolkit Task Force
**Stack:** TailwindCSS + React + Next.js

---

## 1. Design Philosophy (Round-Table)

| Expert | Mandate |
|---|---|
| **Web Designer** | Strict COGA compliance. Single column, literal labels, progressive disclosure. The interface should feel quieter than the user's brain. |
| **Cognitive Therapist** | No red. No alert colors. Every state has a soft visual treatment. Empty states are encouraging, not blank. |
| **Neuroscientist** | Color contrast tuned for retinal comfort, not maximum WCAG numbers. Pure black causes "halation" in dark mode. Pastel priority colors prevent dopamine hijack by alarm hues. |
| **Behaviorist** | Every interactive element provides immediate visual feedback (≤100ms). Hover, focus, active, completion — all distinct. |
| **QA Engineer** | One canonical version of every component. No drift. If a developer needs a button, they MUST use `<Button>`, not roll a new one. |
| **Psychiatrist** | The interface is a clinical instrument. Visual consistency reduces cognitive load. Cognitive load is the symptom we're treating. |

---

## 2. Color System

### 2.1 The Forbidden Color: RED

**Red is physically removed from the codebase.** The Tailwind config overrides `red-*` to throw an error during build. Replacements below.

### 2.2 Background Layers (Dark Mode — Default)

```
slate-950   ┌─────────────────────────────────┐
            │  Page background (--bg-page)    │  Deepest layer
slate-900   │  ┌───────────────────────────┐  │
            │  │  Surface (--bg-surface)   │  │  Cards, modals
slate-800   │  │  ┌─────────────────────┐  │  │
            │  │  │  Elevated           │  │  │  Inputs, hover states
slate-700   │  │  │  (--bg-elevated)    │  │  │
            │  │  └─────────────────────┘  │  │
            │  └───────────────────────────┘  │
            └─────────────────────────────────┘
```

| Token | Hex | Use |
|---|---|---|
| `--bg-page` | `#0f172a` (slate-900) | Body background. **Never pure black** (#000) — causes retinal halation. |
| `--bg-surface` | `#1e293b` (slate-800) | Cards, primary content surfaces |
| `--bg-elevated` | `#334155` (slate-700) | Inputs, hover states, modals |
| `--bg-overlay` | `rgba(15,23,42,0.8)` | Modal backdrop |

### 2.3 Background Layers (Light Mode — Optional)

Available, but **dark mode is default**. Some users with photophobia get worse with dark mode (rare but real). Light mode tokens:

| Token | Hex |
|---|---|
| `--bg-page` | `#fafaf9` (warm off-white, not pure white) |
| `--bg-surface` | `#ffffff` |
| `--bg-elevated` | `#f5f5f4` |

### 2.4 Text Colors

| Token | Hex (dark) | Hex (light) | Use |
|---|---|---|---|
| `--text-primary` | `#f1f5f9` (slate-100) | `#0f172a` | Body text |
| `--text-secondary` | `#94a3b8` (slate-400) | `#475569` | Labels, hints |
| `--text-tertiary` | `#64748b` (slate-500) | `#94a3b8` | Disabled, timestamps |
| `--text-on-priority` | varies | varies | Always test contrast against badge bg |

**Critical:** Body text must hit **WCAG AAA (7:1)** contrast against `--bg-page`. We're not aiming for "passing" — we're aiming for "comfortable for hours."

### 2.5 Priority Color Scale (RSD-Safe)

The Web Designer and Cognitive Therapist explicitly designed this together.

| Priority | Token | Hex | Visual |
|---|---|---|---|
| Bronze (low) | `--priority-bronze` | `#a07452` | Soft, earthy, easy to ignore |
| Silver (medium) | `--priority-silver` | `#94a3b8` | Neutral, doesn't shout |
| Gold (high) | `--priority-gold` | `#d4a017` | Warm, draws eye without alarm |
| Amber (highest) | `--priority-amber` | `#f59e0b` | The closest we get to "urgent" — still warm, never red |

**No "urgent" or "critical" priority exists.** If everything is critical, nothing is. Amber is the ceiling.

### 2.6 Functional Colors

| Token | Hex | Use | NOT for |
|---|---|---|---|
| `--success` | `#10b981` (emerald-500) | Task completed, badge earned | Don't overuse — saturation fatigues |
| `--info` | `#7dd3fc` (sky-300) | Tooltips, neutral notices | |
| `--warning` | `#f59e0b` (amber-500) | "Heads up" — never "danger" | Form validation errors |
| `--soft-error` | `#d946ef` (fuchsia-500) | Errors, validation | Replaces all red usage |

**The fuchsia choice is deliberate.** It registers as "needs attention" without triggering the threat-response wiring that red activates.

### 2.7 Accent

| Token | Hex | Use |
|---|---|---|
| `--accent` | `#a78bfa` (violet-400) | Primary buttons, focus rings, active nav |
| `--accent-soft` | `#c4b5fd` (violet-300) | Hover states |

Violet is the brand color: distinctive, calming, none of the cultural baggage of green/blue.

---

## 3. Typography

### 3.1 Font Stack

```css
--font-sans: "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
--font-mono: "JetBrains Mono", ui-monospace, SFMono-Regular, monospace;
--font-display: "Inter", sans-serif; /* Same as sans for v1 — keep simple */
```

**No serif fonts in v1.** Sans-serif is more readable for ADHD users and scales better at small sizes.

**Inter specifically:** designed for screens, has tabular numbers (critical for the timer), excellent at all sizes, free, self-hostable.

### 3.2 Type Scale

ADHD-friendly = larger than typical. Body text is 16px minimum.

| Token | Size | Line-height | Use |
|---|---|---|---|
| `--text-xs` | 12px | 1.5 | Timestamps, micro-labels (rare) |
| `--text-sm` | 14px | 1.5 | Secondary text, hints |
| `--text-base` | 16px | 1.6 | Body text (DEFAULT) |
| `--text-lg` | 18px | 1.5 | Emphasized body |
| `--text-xl` | 20px | 1.4 | Card titles |
| `--text-2xl` | 24px | 1.3 | Section headings |
| `--text-3xl` | 32px | 1.2 | Page titles |
| `--text-display` | 48px | 1.1 | Timer numerals, hero text |

### 3.3 Font Weights

Three weights only. More creates visual noise.

| Token | Weight |
|---|---|
| `--font-normal` | 400 |
| `--font-medium` | 500 |
| `--font-bold` | 700 |

### 3.4 Reading Width

Body text: **max 65 characters per line** (`max-w-[65ch]`). Beyond this, ADHD eyes lose their place between lines.

---

## 4. Spacing System

8-point grid. Every spacing value is a multiple of 4px (Tailwind's default).

| Token | px | Use |
|---|---|---|
| `space-1` | 4px | Icon-to-text gap |
| `space-2` | 8px | Tight inline spacing |
| `space-3` | 12px | Default inline gap |
| `space-4` | 16px | Default block gap |
| `space-6` | 24px | Section spacing |
| `space-8` | 32px | Major section spacing |
| `space-12` | 48px | Hero/empty state spacing |
| `space-16` | 64px | Page-level breathing room |

**Touch targets minimum 44×44px.** No exceptions. ADHD users have variable motor control during dysregulation.

---

## 5. Layout Rules

### 5.1 Single-Column Mandate

The main task interface MUST be single column on every viewport. No exceptions.

```
Mobile (320px+):     [ single column ]
Tablet (768px+):     [   single column   ]    (max-w-2xl, centered)
Desktop (1024px+):   [   single column   ]    (max-w-2xl, centered)
Large (1440px+):     [   single column   ]    (still max-w-2xl)
```

The desktop empty space on either side is **intentional**. Filling it with sidebars violates COGA.

### 5.2 Allowed Multi-Column Surfaces

These are exceptions, justified case-by-case:

- **Settings pages** — two-column layout acceptable (nav + content)
- **Body Doubling room** — video tile grid
- **Praise Repository inbox** — single column, but each memo card is internally multi-region
- **Reverse Scheduler timeline** — visual horizontal layout for the time wedge

### 5.3 Z-Index Layers

```
0     Base content
10    Sticky header
20    Dropdown menus
30    Tooltips
40    Modal backdrop
50    Modal content
60    Toast notifications
70    Floating timer (Picture-in-Picture fallback)
9999  Critical recovery UI (offline banner, etc.)
```

---

## 6. Border Radius

| Token | px | Use |
|---|---|---|
| `--radius-sm` | 4px | Micro elements (badge dots) |
| `--radius` | 8px | Default — buttons, inputs, cards |
| `--radius-lg` | 12px | Modal corners |
| `--radius-xl` | 16px | Hero cards |
| `--radius-full` | 9999px | Avatars, pill badges |

**No sharp 90° corners on interactive elements.** Sharp corners read as "alert" / "warning."

---

## 7. Shadows

Used sparingly. Dark mode shadows are subtle.

| Token | Value | Use |
|---|---|---|
| `--shadow-sm` | `0 1px 2px rgba(0,0,0,0.3)` | Cards |
| `--shadow` | `0 4px 12px rgba(0,0,0,0.4)` | Elevated cards, dropdowns |
| `--shadow-lg` | `0 12px 32px rgba(0,0,0,0.5)` | Modals |
| `--shadow-glow-success` | `0 0 16px rgba(16,185,129,0.4)` | Badge earned animation |
| `--shadow-glow-accent` | `0 0 16px rgba(167,139,250,0.4)` | Active focus session |

---

## 8. Animation & Motion

### 8.1 Durations

| Token | ms | Use |
|---|---|---|
| `--duration-instant` | 100 | Hover state changes |
| `--duration-fast` | 150 | Button press feedback |
| `--duration-normal` | 250 | Modal open/close, page transitions |
| `--duration-slow` | 400 | Timer wedge animations |
| `--duration-celebration` | 800 | Badge earned animation |

### 8.2 Easing

```css
--ease-default: cubic-bezier(0.4, 0, 0.2, 1);  /* Smooth, standard */
--ease-spring: cubic-bezier(0.5, 1.4, 0.5, 1); /* Slight bounce — ONLY for celebrations */
```

### 8.3 Reduced Motion

**MUST honor `prefers-reduced-motion: reduce`.** Some ADHD users have vestibular sensitivity. Replace all animations with instant transitions; keep opacity fades only.

```css
@media (prefers-reduced-motion: reduce) {
  * {
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
  }
}
```

### 8.4 The Badge Earned Animation

This is the dopamine event. It must feel good.

```
1. Badge slides in from below (300ms, ease-spring)
2. Brief glow pulse (--shadow-glow-success, 600ms)
3. Soft chime plays (audio respects user's "Sound Family" preference)
4. Auto-dismisses after 2.5s, OR earlier if user clicks away
```

No confetti. Confetti is sensory overload for many ADHD users.

---

## 9. Component Inventory (v1)

The QA Engineer's mandate: **every UI element on the site uses one of these components.** No exceptions, no copies.

### 9.1 Primitives
- `<Button>` — variants: primary, secondary, ghost, soft-destructive (no "destructive" in red)
- `<IconButton>` — always with `aria-label`, never icon-only without text on critical actions
- `<Input>` — text, email, password, with show/hide toggle
- `<Textarea>` — auto-growing
- `<Select>` — native on mobile, custom on desktop (matched styling)
- `<Checkbox>` — large, satisfying tick animation
- `<Radio>` — same
- `<Toggle>` — for binary settings
- `<Slider>` — for things like timer duration
- `<Label>` — always with associated input via `htmlFor`

### 9.2 Containers
- `<Card>` — primary surface
- `<Modal>` — opens centered, dismissible by Esc and backdrop
- `<Drawer>` — slides from right (settings, secondary content)
- `<Toast>` — for soft notifications, auto-dismiss at 4s

### 9.3 Feedback
- `<Toast>` — soft, non-blocking
- `<EmptyState>` — encouraging illustration + message + CTA
- `<LoadingSpinner>` — only for >500ms operations; below that, nothing
- `<SkeletonLoader>` — for predictable layouts during fetch

### 9.4 ADHD-Specific Components
- `<TaskCard>` — single-column task display with priority badge
- `<MicroStep>` — single sub-task display for "Walk Me Through It" mode
- `<AnalogTimer>` — the wedge timer
- `<DoorknobTimeline>` — reverse scheduler visual
- `<PriorityBadge>` — bronze/silver/gold/amber pill
- `<EarnedBadge>` — celebration display
- `<VoiceDumpButton>` — large hold-to-record mic button
- `<DeferTaskButton>` — replaces the standard "delete" pattern
- `<PraiseMemoCard>` — voice memo with transcript + speed controls
- `<BodyCheckInPrompt>` — gentle interoception prompt
- `<SoundFamilyPicker>` — settings UI for alert variations

---

## 10. Iconography

### 10.1 Icon Library

**Lucide React** — open source, consistent stroke weight, 1500+ icons. Single dependency.

### 10.2 Icon Rules (COGA-mandated)

1. **Every icon on a clickable element MUST have an accompanying text label.** "Voice Dump" next to mic icon, not just mic.
2. **Icons in body text are decorative, not interactive.**
3. **`aria-hidden="true"` on decorative icons; `aria-label` on functional ones.**
4. **Icon size: 16px (inline), 20px (default), 24px (emphasized).**
5. **No custom-drawn icons in v1.** Stick to Lucide.

### 10.3 Standard Icon Mapping

| Concept | Icon | Label |
|---|---|---|
| Voice recording | `Mic` | "Voice Dump" |
| Task complete | `Check` | "Done. Next step." |
| Defer task | `Clock` | "Push to later" (NOT "Snooze" — too sleepy) |
| Timer | `Timer` | "Start Timer" |
| Settings | `Settings` | "Settings" |
| Praise inbox | `Heart` | "Praise from your people" |
| Body doubling | `Users` | "Co-work" |
| Help/decision | `Sparkles` | "Help Me Decide" |
| Walk-through mode | `Footprints` | "Walk Me Through It" |
| Sign out | `LogOut` | "Sign out" |

---

## 11. State Patterns

### 11.1 Empty States

Every empty state has three parts:
1. Soft illustration (or large icon)
2. Encouraging message — never "You have nothing"
3. Single primary action

**Example — Empty task list:**
```
   ✨
"Nothing on your plate right now.
That's allowed."
[Capture a thought]
```

### 11.2 Loading States

| Duration | Treatment |
|---|---|
| 0–200ms | Nothing — too fast to indicate |
| 200–500ms | Subtle skeleton |
| 500ms–3s | Skeleton + soft spinner |
| 3s+ | Skeleton + reassurance text: "Still working — promise" |

### 11.3 Error States

**No red. No exclamation marks. No "ERROR" headers.**

Format: `<soft icon> + plain-language description + recovery action`

**Example:**
```
🌙  We couldn't reach the server.
    [Try again]   [Work offline]
```

### 11.4 Success States

Brief, warm, dismissible. Earned-badge animation is the celebration peak — don't over-celebrate every save.

---

## 12. Accessibility Compliance

### 12.1 Targets

- **WCAG 2.2 AA minimum, AAA where feasible**
- **COGA Working Group recommendations** (Cognitive Accessibility)
- **ARIA 1.2 patterns** for all custom components

### 12.2 Required Behaviors

- All interactive elements keyboard-reachable
- Focus visible on every element (`--accent` ring, 2px, with 2px offset)
- Skip-to-content link on every page
- All images have `alt` text (decorative = `alt=""`)
- All form inputs have associated labels
- Color is never the only indicator (priority levels also have an icon/label)
- Page must be usable at 200% zoom without horizontal scroll
- Page must be usable in browser default font size

### 12.3 Screen Reader Patterns

- Live regions for timer countdown updates (`aria-live="polite"`)
- Modal dialogs trap focus and restore on close
- Toast notifications use `role="status"`
- Form errors use `aria-describedby` linking input to error message

### 12.4 Testing

- Automated: `axe-core` in CI, must show 0 violations
- Manual: keyboard-only nav test before every release
- Manual: VoiceOver (macOS/iOS) and NVDA (Windows) smoke test before launch

---

## 13. Tailwind Config Strategy

### 13.1 Custom Theme Tokens

```js
// tailwind.config.js (excerpt)
theme: {
  extend: {
    colors: {
      bg: {
        page: 'var(--bg-page)',
        surface: 'var(--bg-surface)',
        elevated: 'var(--bg-elevated)',
      },
      text: {
        primary: 'var(--text-primary)',
        secondary: 'var(--text-secondary)',
        tertiary: 'var(--text-tertiary)',
      },
      priority: {
        bronze: 'var(--priority-bronze)',
        silver: 'var(--priority-silver)',
        gold: 'var(--priority-gold)',
        amber: 'var(--priority-amber)',
      },
      accent: {
        DEFAULT: 'var(--accent)',
        soft: 'var(--accent-soft)',
      },
      success: 'var(--success)',
      info: 'var(--info)',
      warning: 'var(--warning)',
      'soft-error': 'var(--soft-error)',
    },
  },
}
```

### 13.2 Red Removal

```js
// In tailwind.config.js, override Tailwind's red palette to throw at build:
const buildError = () => {
  throw new Error('Red is forbidden in Focus Forge. Use --soft-error (fuchsia) instead.');
};

theme: {
  extend: {
    colors: {
      red: new Proxy({}, { get: buildError }),
    },
  },
}
```

This is enforced at the build level — a developer cannot ship `text-red-500` even by accident.

### 13.3 CSS Variables in Globals

```css
/* app/globals.css */
:root {
  --bg-page: #0f172a;
  --bg-surface: #1e293b;
  /* ... etc */
}

@media (prefers-color-scheme: light) {
  :root {
    --bg-page: #fafaf9;
    /* ... etc */
  }
}

/* User-selected theme overrides system preference */
[data-theme="dark"] { /* ... */ }
[data-theme="light"] { /* ... */ }
```

---

## 14. Acceptance Criteria

The design system is "done" when:

- [ ] All component variants render in a Storybook (or equivalent)
- [ ] All color tokens defined in CSS and Tailwind config
- [ ] Red is impossible to use without a build error
- [ ] axe-core passes 0 violations on every component
- [ ] Every component has a documented use case
- [ ] Reduced-motion preference is honored everywhere
- [ ] Both dark and light modes pass WCAG AAA on body text
- [ ] Touch targets are 44×44px minimum throughout
- [ ] No custom-drawn icons; all icons from Lucide
- [ ] Single-column layout enforced on all main task surfaces
- [ ] Component library has TypeScript types and prop documentation
