# Focus Forge — MySQL Schema Specification

**Status:** Draft v1.0
**Owners:** ADHD Toolkit Task Force
**Target:** MySQL 8.0+ (JSON columns, CTEs, window functions required)
**Charset:** `utf8mb4` / `utf8mb4_0900_ai_ci`

---

## 1. Schema Philosophy (Round-Table)

| Expert | Mandate |
|---|---|
| **QA Engineer** | Every table has a primary key. Every foreign key has an index. No nullable columns without a documented reason. Every status enum is explicit — no magic strings. |
| **Cognitive Therapist** | The schema must MAKE IT IMPOSSIBLE to record "failed" states. Status enums physically don't include 'failed'. This isn't policy — it's structure. |
| **Behaviorist** | Every user action that could earn a badge must produce a database event. The badge engine reads from `events`, not from feature-specific tables. |
| **Psychiatrist** | The `feature_grants` table is the legal commitment to legacy users. Once a row is written, it is never deleted, only audited. |
| **Neuroscientist** | Indexes must support sub-100ms reads on the dashboard query. Anything slower causes user abandonment. |
| **Web Designer** | Pagination cursors, not offsets. Stable ordering. |

---

## 2. Conventions

### 2.1 Naming
- Tables: `snake_case`, plural (`tasks`, `users`, `praise_memos`)
- Columns: `snake_case`, singular
- Foreign keys: `<table>_id` (e.g., `user_id`)
- Boolean columns: prefixed `is_` or `has_`
- Timestamp columns: `<verb>_at` (`created_at`, `deleted_at`)
- Junction tables: alphabetical order (`task_tags`, not `tag_tasks`)

### 2.2 Primary Keys

All tables use **UUIDv7** as primary keys, stored as `BINARY(16)`.

**Why UUIDv7 and not auto-increment:**
- UUIDv7 is time-ordered (sorts naturally by creation)
- Avoids ID enumeration attacks
- Allows offline-generated IDs (PWA support)
- Better for distributed inserts than v4

```sql
-- UUIDs stored as BINARY(16) — half the size of CHAR(36)
-- Helper: app generates UUIDv7, encodes to bytes for storage
id BINARY(16) NOT NULL PRIMARY KEY
```

### 2.3 Timestamps

All tables include:
```sql
created_at TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
updated_at TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)
```

`(3)` = millisecond precision (matters for event ordering).

### 2.4 Soft Delete vs. Hard Delete

Most user-facing data uses **hard deletes** (per privacy commitments). Specific exceptions documented per table.

### 2.5 JSON Columns

Used sparingly. Only for:
- AI-generated metadata (where structure may evolve)
- User preferences (sparse, optional fields)
- Step lists (when order matters but querying individual steps is rare)

**Never** for queryable data. If you'll query it, give it a column.

---

## 3. Schema Diagram (High-Level)

```
                         ┌──────────┐
                         │  users   │
                         └────┬─────┘
                              │
        ┌─────────────────────┼─────────────────────┐
        │                     │                     │
   ┌────▼─────┐         ┌─────▼────┐         ┌──────▼──────┐
   │ sessions │         │  tasks   │         │praise_memos │
   └──────────┘         └────┬─────┘         └─────────────┘
                             │
                        ┌────▼────┐
                        │  steps  │
                        └─────────┘

   ┌──────────────┐    ┌────────────────┐    ┌──────────────────┐
   │ auth_methods │    │ feature_grants │    │trusted_contacts  │
   └──────────────┘    └────────────────┘    └──────────────────┘

   ┌──────────────┐    ┌────────────────┐    ┌──────────────────┐
   │   badges     │    │ user_badges    │    │ launchpad_items  │
   └──────────────┘    └────────────────┘    └──────────────────┘

   ┌──────────────┐    ┌────────────────┐    ┌──────────────────┐
   │focus_sessions│    │ check_ins      │    │ scheduled_alerts │
   └──────────────┘    └────────────────┘    └──────────────────┘

   ┌──────────────┐    ┌────────────────┐
   │   events     │    │   audit_log    │
   └──────────────┘    └────────────────┘
```

---

## 4. Table Definitions

### 4.1 `users`

```sql
CREATE TABLE users (
  id                BINARY(16)    NOT NULL PRIMARY KEY,
  email             VARCHAR(254)  NOT NULL,
  email_verified_at TIMESTAMP(3)  NULL DEFAULT NULL,
  display_name      VARCHAR(80)   NULL DEFAULT NULL,
  password_hash     VARCHAR(255)  NULL DEFAULT NULL,    -- NULL if user only uses OAuth/magic-link

  account_state     ENUM('unverified', 'active', 'pending_delete', 'suspended', 'deleted')
                    NOT NULL DEFAULT 'unverified',

  -- NOTE: tier history is in feature_grants. This is current state.
  tier              ENUM('free', 'legacy_free', 'paid', 'paid_lifetime')
                    NOT NULL DEFAULT 'free',

  -- Preferences (sparse, evolve frequently)
  preferences       JSON          NULL DEFAULT NULL,
  -- Example shape:
  -- {
  --   "theme": "dark",
  --   "soundFamily": "soft_chimes",
  --   "reducedMotion": false,
  --   "timeZone": "America/Los_Angeles",
  --   "weekStartsOn": "monday"
  -- }

  pending_delete_at TIMESTAMP(3)  NULL DEFAULT NULL,    -- Set when deletion requested; +30d = hard delete
  last_login_at     TIMESTAMP(3)  NULL DEFAULT NULL,
  last_login_ip     VARBINARY(16) NULL DEFAULT NULL,    -- IPv4 or IPv6 in binary

  created_at        TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  updated_at        TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),

  UNIQUE KEY uq_users_email (email),
  KEY idx_users_account_state (account_state),
  KEY idx_users_pending_delete (pending_delete_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

**Notes:**
- `email` UNIQUE: enforces single account per email
- `password_hash` NULL allowed: OAuth-only users have no password
- `display_name` NULL: defaults to "you" in UI when null
- `tier`: see §4.7 for legacy-user logic

### 4.2 `auth_methods`

A user can have multiple auth methods linked. Each method is a row.

```sql
CREATE TABLE auth_methods (
  id              BINARY(16)    NOT NULL PRIMARY KEY,
  user_id         BINARY(16)    NOT NULL,

  provider        ENUM('password', 'google', 'apple', 'facebook', 'magic_link')
                  NOT NULL,

  provider_account_id VARCHAR(255) NULL DEFAULT NULL,  -- e.g. Google sub claim
  -- For 'password': NULL (password is on users.password_hash)
  -- For 'magic_link': NULL (no persistent ID)
  -- For OAuth: the provider's stable user ID

  metadata        JSON          NULL DEFAULT NULL,
  -- Example for OAuth: { "email_at_provider": "...", "name_at_provider": "..." }

  last_used_at    TIMESTAMP(3)  NULL DEFAULT NULL,
  created_at      TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  updated_at      TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),

  CONSTRAINT fk_auth_methods_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY uq_auth_methods_provider (provider, provider_account_id),
  KEY idx_auth_methods_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

### 4.3 `sessions`

Server-side session storage (cookie holds session ID only).

```sql
CREATE TABLE sessions (
  id              BINARY(16)    NOT NULL PRIMARY KEY,
  user_id         BINARY(16)    NOT NULL,

  token_hash      BINARY(32)    NOT NULL,             -- SHA-256 of the session secret
  user_agent      VARCHAR(500)  NULL DEFAULT NULL,
  ip_address      VARBINARY(16) NULL DEFAULT NULL,

  expires_at      TIMESTAMP(3)  NOT NULL,
  last_active_at  TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  created_at      TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

  CONSTRAINT fk_sessions_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY uq_sessions_token_hash (token_hash),
  KEY idx_sessions_user (user_id),
  KEY idx_sessions_expires (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

A nightly job purges sessions where `expires_at < NOW()`.

### 4.4 `magic_link_tokens` & `password_reset_tokens` & `email_verification_tokens`

Three small, similar tables. One template:

```sql
CREATE TABLE magic_link_tokens (
  id              BINARY(16)    NOT NULL PRIMARY KEY,
  user_id         BINARY(16)    NULL DEFAULT NULL,    -- NULL if signup-flow magic-link
  email           VARCHAR(254)  NOT NULL,             -- Captured at request time

  token_hash      BINARY(32)    NOT NULL,
  expires_at      TIMESTAMP(3)  NOT NULL,
  used_at         TIMESTAMP(3)  NULL DEFAULT NULL,    -- Set when consumed; tokens are single-use

  created_at      TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

  CONSTRAINT fk_magic_links_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY uq_magic_link_token_hash (token_hash),
  KEY idx_magic_link_email (email),
  KEY idx_magic_link_expires (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

`password_reset_tokens` and `email_verification_tokens` follow the same shape — different expiry windows (60min and 7 days respectively).

### 4.5 `tasks`

The core entity. Note explicit absence of any 'failed' status.

```sql
CREATE TABLE tasks (
  id              BINARY(16)    NOT NULL PRIMARY KEY,
  user_id         BINARY(16)    NOT NULL,

  raw_text        TEXT          NOT NULL,             -- Original capture (text or transcript)

  -- AI-parsed canonical form
  title           VARCHAR(500)  NULL DEFAULT NULL,    -- Short title, may be NULL until AI runs
  notes           TEXT          NULL DEFAULT NULL,

  -- Priority — Forgiveness Protocol: NO 'urgent' or 'red'
  priority        ENUM('bronze', 'silver', 'gold', 'amber')
                  NOT NULL DEFAULT 'bronze',

  -- Status — Forgiveness Protocol: NO 'failed' or 'overdue'
  status          ENUM('active', 'deferred', 'completed')
                  NOT NULL DEFAULT 'active',

  -- Optional scheduling
  scheduled_for   TIMESTAMP(3)  NULL DEFAULT NULL,
  estimated_minutes SMALLINT UNSIGNED NULL DEFAULT NULL,

  -- Completion / deferral metadata
  completed_at    TIMESTAMP(3)  NULL DEFAULT NULL,
  deferred_count  SMALLINT UNSIGNED NOT NULL DEFAULT 0,  -- Tracked silently; never shown to user
  deferred_until  TIMESTAMP(3)  NULL DEFAULT NULL,

  -- Capture method (analytics)
  capture_method  ENUM('text', 'voice', 'imported', 'system')
                  NOT NULL DEFAULT 'text',

  -- AI metadata (loose schema)
  ai_metadata     JSON          NULL DEFAULT NULL,
  -- Example:
  -- {
  --   "model": "gpt-4o-mini",
  --   "parsed_at": "2026-...",
  --   "confidence": 0.87,
  --   "detected_time_phrase": "tomorrow at 3pm"
  -- }

  created_at      TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  updated_at      TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),

  CONSTRAINT fk_tasks_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  KEY idx_tasks_user_status (user_id, status, created_at),
  KEY idx_tasks_user_scheduled (user_id, scheduled_for),
  KEY idx_tasks_deferred_until (deferred_until)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

**Critical:** the status ENUM physically cannot store 'failed' or 'overdue'. A future developer cannot accidentally introduce shame mechanics without an explicit migration.

### 4.6 `task_steps`

Sub-steps generated by AI for the "Walk Me Through It" mode.

```sql
CREATE TABLE task_steps (
  id              BINARY(16)    NOT NULL PRIMARY KEY,
  task_id         BINARY(16)    NOT NULL,

  step_order      SMALLINT UNSIGNED NOT NULL,
  text            TEXT          NOT NULL,

  status          ENUM('active', 'completed', 'deferred')
                  NOT NULL DEFAULT 'active',
  completed_at    TIMESTAMP(3)  NULL DEFAULT NULL,

  created_at      TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  updated_at      TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),

  CONSTRAINT fk_task_steps_task FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE,
  UNIQUE KEY uq_task_steps_order (task_id, step_order),
  KEY idx_task_steps_task_status (task_id, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

**Why a separate table (not a JSON array on `tasks`):**
- We query individual steps for the "Walk Me Through It" UI
- Step completions are independent events (each can earn a "First Step" badge)
- We may add per-step time estimates later

### 4.7 `feature_grants`

**The legacy-user commitment, made structural.**

```sql
CREATE TABLE feature_grants (
  id              BINARY(16)    NOT NULL PRIMARY KEY,
  user_id         BINARY(16)    NOT NULL,
  feature_key     VARCHAR(80)   NOT NULL,             -- e.g., 'voice_dump', 'body_doubling'
  granted_at      TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

  granted_reason  ENUM('signup_default', 'legacy_grandfather', 'paid_subscription', 'lifetime_purchase', 'admin_grant')
                  NOT NULL,

  notes           VARCHAR(500)  NULL DEFAULT NULL,

  CONSTRAINT fk_feature_grants_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY uq_feature_grants (user_id, feature_key),
  KEY idx_feature_grants_user (user_id),
  KEY idx_feature_grants_reason (granted_reason)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

**Access check logic (in app code):**
```typescript
async function userHasFeature(userId: Buffer, featureKey: string): Promise<boolean> {
  const user = await getUser(userId);

  // Paid users get everything
  if (user.tier === 'paid' || user.tier === 'paid_lifetime') return true;

  // Legacy + free users: check explicit grant
  const grant = await db.query(
    `SELECT 1 FROM feature_grants WHERE user_id = ? AND feature_key = ?`,
    [userId, featureKey]
  );

  return grant.length > 0;
}
```

**At paid-launch migration time:**
```sql
-- Grant every existing 'free' user every feature that currently exists
INSERT INTO feature_grants (id, user_id, feature_key, granted_reason, notes)
SELECT
  UUID_TO_BIN(UUID()),
  u.id,
  f.feature_key,
  'legacy_grandfather',
  'Auto-granted at paid-tier launch'
FROM users u
CROSS JOIN (
  SELECT 'voice_dump' AS feature_key UNION ALL
  SELECT 'task_management' UNION ALL
  SELECT 'analog_timer' UNION ALL
  SELECT 'reverse_scheduler' UNION ALL
  SELECT 'praise_repository' UNION ALL
  SELECT 'body_doubling' UNION ALL
  SELECT 'launchpad' UNION ALL
  SELECT 'check_ins'
) f
WHERE u.tier = 'free' AND u.account_state = 'active';

-- Then update tier
UPDATE users SET tier = 'legacy_free' WHERE tier = 'free' AND account_state = 'active';
```

### 4.8 `badges` (definitions) and `user_badges` (earned instances)

```sql
CREATE TABLE badges (
  id              BINARY(16)    NOT NULL PRIMARY KEY,
  badge_key       VARCHAR(80)   NOT NULL,             -- 'first_capture', 'first_focus_session'
  display_name    VARCHAR(120)  NOT NULL,
  description     VARCHAR(500)  NOT NULL,
  tier            ENUM('bronze', 'silver', 'gold')
                  NOT NULL DEFAULT 'bronze',

  -- Trigger logic (loose — interpreted by badge engine in app)
  trigger_event_type  VARCHAR(80) NULL DEFAULT NULL,  -- e.g., 'task.completed'
  trigger_threshold   INT UNSIGNED NULL DEFAULT NULL, -- e.g., 5 (completions)
  is_repeatable       BOOLEAN NOT NULL DEFAULT FALSE,

  icon_name       VARCHAR(80)   NOT NULL,             -- Lucide icon name
  is_active       BOOLEAN       NOT NULL DEFAULT TRUE,

  created_at      TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

  UNIQUE KEY uq_badges_key (badge_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE user_badges (
  id              BINARY(16)    NOT NULL PRIMARY KEY,
  user_id         BINARY(16)    NOT NULL,
  badge_id        BINARY(16)    NOT NULL,

  earned_at       TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  context         JSON          NULL DEFAULT NULL,    -- e.g., { "task_id": "...", "session_count": 5 }

  CONSTRAINT fk_user_badges_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_user_badges_badge FOREIGN KEY (badge_id) REFERENCES badges(id),
  KEY idx_user_badges_user_earned (user_id, earned_at DESC),
  KEY idx_user_badges_badge (badge_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

Non-repeatable badges have a uniqueness check enforced in app code (a partial unique index would be cleaner but MySQL doesn't support those — we add a compound `(user_id, badge_id)` unique only on non-repeatable rows via app-layer logic).

### 4.9 `praise_memos`

```sql
CREATE TABLE praise_memos (
  id              BINARY(16)    NOT NULL PRIMARY KEY,
  user_id         BINARY(16)    NOT NULL,             -- Recipient
  trusted_contact_id BINARY(16) NOT NULL,             -- Sender

  sender_display_name VARCHAR(80) NOT NULL,           -- Captured at submission

  audio_path      VARCHAR(500)  NOT NULL,             -- Server-relative; never public
  audio_duration_ms INT UNSIGNED NOT NULL,
  audio_size_bytes INT UNSIGNED NOT NULL,

  transcript      TEXT          NULL DEFAULT NULL,    -- AI-generated; NULL during processing
  transcript_status ENUM('pending', 'completed', 'failed_skip')
                    NOT NULL DEFAULT 'pending',
  -- Note: 'failed_skip' just means we couldn't transcribe and moved on. Audio still works.

  category        VARCHAR(80)   NULL DEFAULT NULL,    -- 'after_failure', 'before_big_task', etc.

  is_archived     BOOLEAN       NOT NULL DEFAULT FALSE,
  last_played_at  TIMESTAMP(3)  NULL DEFAULT NULL,
  play_count      INT UNSIGNED  NOT NULL DEFAULT 0,

  created_at      TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

  CONSTRAINT fk_praise_memos_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_praise_memos_contact FOREIGN KEY (trusted_contact_id) REFERENCES trusted_contacts(id) ON DELETE CASCADE,
  KEY idx_praise_memos_user_created (user_id, created_at DESC),
  KEY idx_praise_memos_user_category (user_id, category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

### 4.10 `trusted_contacts`

```sql
CREATE TABLE trusted_contacts (
  id              BINARY(16)    NOT NULL PRIMARY KEY,
  user_id         BINARY(16)    NOT NULL,             -- The Focus Forge user receiving memos

  display_name    VARCHAR(80)   NOT NULL,             -- Set by user when generating link

  invite_token_hash BINARY(32)  NOT NULL,             -- Hash of the unique invite token
  invite_expires_at TIMESTAMP(3) NOT NULL,            -- 7 days after creation
  memos_remaining   SMALLINT UNSIGNED NOT NULL DEFAULT 3,

  is_revoked      BOOLEAN       NOT NULL DEFAULT FALSE,
  revoked_at      TIMESTAMP(3)  NULL DEFAULT NULL,

  created_at      TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

  CONSTRAINT fk_trusted_contacts_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY uq_trusted_contacts_token (invite_token_hash),
  KEY idx_trusted_contacts_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

### 4.11 `launchpad_items`

The user's daily "items by the door."

```sql
CREATE TABLE launchpad_items (
  id              BINARY(16)    NOT NULL PRIMARY KEY,
  user_id         BINARY(16)    NOT NULL,

  label           VARCHAR(120)  NOT NULL,             -- "Keys", "Wallet", "Lunch from fridge"
  display_order   SMALLINT UNSIGNED NOT NULL DEFAULT 0,

  is_checked      BOOLEAN       NOT NULL DEFAULT FALSE,
  last_checked_at TIMESTAMP(3)  NULL DEFAULT NULL,

  reset_schedule  ENUM('never', 'daily', 'on_departure')
                  NOT NULL DEFAULT 'daily',
  reset_time_local TIME         NULL DEFAULT '04:00:00',  -- Local time at user's TZ

  created_at      TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  updated_at      TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),

  CONSTRAINT fk_launchpad_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  KEY idx_launchpad_user_order (user_id, display_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

### 4.12 `focus_sessions`

A focus timer run.

```sql
CREATE TABLE focus_sessions (
  id              BINARY(16)    NOT NULL PRIMARY KEY,
  user_id         BINARY(16)    NOT NULL,
  task_id         BINARY(16)    NULL DEFAULT NULL,    -- Optional linked task

  planned_duration_seconds INT UNSIGNED NOT NULL,
  actual_duration_seconds  INT UNSIGNED NULL DEFAULT NULL,

  -- Forgiveness Protocol: 'incomplete' is neutral, NOT 'failed'
  status          ENUM('running', 'completed', 'incomplete', 'paused')
                  NOT NULL DEFAULT 'running',

  sound_family    VARCHAR(80)   NULL DEFAULT NULL,
  alert_interval_seconds INT UNSIGNED NULL DEFAULT NULL,

  started_at      TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  ended_at        TIMESTAMP(3)  NULL DEFAULT NULL,

  CONSTRAINT fk_focus_sessions_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_focus_sessions_task FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE SET NULL,
  KEY idx_focus_sessions_user_started (user_id, started_at DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

### 4.13 `check_ins`

Body check-ins triggered during long focus sessions.

```sql
CREATE TABLE check_ins (
  id              BINARY(16)    NOT NULL PRIMARY KEY,
  user_id         BINARY(16)    NOT NULL,
  focus_session_id BINARY(16)   NULL DEFAULT NULL,

  prompt_key      VARCHAR(80)   NOT NULL,             -- 'water', 'tension', 'posture'
  response        ENUM('yes', 'no', 'dismissed', 'no_response')
                  NULL DEFAULT NULL,

  prompted_at     TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  responded_at    TIMESTAMP(3)  NULL DEFAULT NULL,

  CONSTRAINT fk_check_ins_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_check_ins_session FOREIGN KEY (focus_session_id) REFERENCES focus_sessions(id) ON DELETE SET NULL,
  KEY idx_check_ins_user_prompted (user_id, prompted_at DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

### 4.14 `scheduled_alerts`

Future reminders (Doorknob mode, nightly Launchpad reminders, etc.).

```sql
CREATE TABLE scheduled_alerts (
  id              BINARY(16)    NOT NULL PRIMARY KEY,
  user_id         BINARY(16)    NOT NULL,

  alert_type      ENUM('doorknob_zone', 'launchpad_nightly', 'task_reminder', 'check_in')
                  NOT NULL,

  scheduled_for   TIMESTAMP(3)  NOT NULL,
  payload         JSON          NULL DEFAULT NULL,    -- Flexible per alert type

  status          ENUM('pending', 'fired', 'cancelled')
                  NOT NULL DEFAULT 'pending',
  fired_at        TIMESTAMP(3)  NULL DEFAULT NULL,

  created_at      TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

  CONSTRAINT fk_scheduled_alerts_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  KEY idx_scheduled_alerts_pending (status, scheduled_for),
  KEY idx_scheduled_alerts_user (user_id, scheduled_for)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

A worker (cron job, every minute) selects rows where `status = 'pending' AND scheduled_for <= NOW()` and fires them.

### 4.15 `events`

Append-only event log. Drives the badge engine, analytics, audit.

```sql
CREATE TABLE events (
  id              BINARY(16)    NOT NULL PRIMARY KEY,
  user_id         BINARY(16)    NULL DEFAULT NULL,    -- NULL for system events

  event_type      VARCHAR(80)   NOT NULL,
  -- Convention: 'noun.verb' (task.created, task.completed, focus_session.completed, badge.earned)

  payload         JSON          NULL DEFAULT NULL,
  occurred_at     TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

  CONSTRAINT fk_events_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  KEY idx_events_user_type_time (user_id, event_type, occurred_at DESC),
  KEY idx_events_type_time (event_type, occurred_at DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

**Note:** `events` will grow large. Plan to partition by month or archive >180 days to a separate table after launch.

### 4.16 `audit_log`

Sensitive operations only. Separate from `events` for security/compliance.

```sql
CREATE TABLE audit_log (
  id              BINARY(16)    NOT NULL PRIMARY KEY,
  user_id         BINARY(16)    NULL DEFAULT NULL,
  actor_id        BINARY(16)    NULL DEFAULT NULL,    -- e.g., admin acting on user

  action          VARCHAR(80)   NOT NULL,
  -- 'login.success', 'login.failed', 'password.changed', 'email.changed',
  -- 'account.delete_requested', 'account.delete_cancelled', 'account.deleted',
  -- 'feature_grant.created', 'admin.action'

  metadata        JSON          NULL DEFAULT NULL,
  ip_address      VARBINARY(16) NULL DEFAULT NULL,
  user_agent      VARCHAR(500)  NULL DEFAULT NULL,

  occurred_at     TIMESTAMP(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

  KEY idx_audit_user_time (user_id, occurred_at DESC),
  KEY idx_audit_action (action)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

**No FK from `audit_log` to `users`** — we want audit records to survive user deletion. We anonymize them but don't drop them.

---

## 5. Real-Time Sync Strategy (replacing Firestore listeners)

The original spec assumed Firestore's automatic real-time sync. With MySQL, we use **Server-Sent Events (SSE)** from a Next.js API route.

### 5.1 Approach

- Client opens `GET /api/stream` (long-lived SSE connection)
- Server polls the `events` table for that user every 2 seconds (or uses MySQL's binlog if available, but unlikely on shared hosting)
- New events are pushed to the client
- Client merges into local Zustand store

### 5.2 Polling vs. Push

For shared cPanel hosting where binlog access is limited, **2-second polling within a single SSE connection** is the pragmatic choice. This is one DB query per user per 2 seconds — manageable up to a few thousand concurrent users.

If user count grows: migrate to a managed Redis pub/sub or move that one component to a host with WebSocket support.

### 5.3 Optimistic UI

The frontend ALWAYS updates state immediately on user action. The SSE channel is for **cross-device sync only**. This keeps the UI responsive even when the network is slow — important per the Behaviorist's mandate.

---

## 6. Migration Strategy

### 6.1 Tooling

Recommend **Prisma** (with the MySQL connector) or **Drizzle** for schema migrations. Both work on cPanel Node hosts.

### 6.2 Migration Folder Structure

```
/db
  /migrations
    20260101000000_init.sql
    20260102000000_add_feature_grants.sql
    ...
  /seeds
    badges.sql
    initial_admin.sql
```

### 6.3 Initial Seed Data

The `badges` table needs seeding before the app works. Sample seeds in §8.

---

## 7. Indexes Strategy

The dashboard is the most-hit query. It needs to return in <100ms.

### 7.1 The Dashboard Query

```sql
-- Get active tasks for a user, with their step counts
SELECT
  t.id, t.title, t.priority, t.status, t.scheduled_for, t.created_at,
  (SELECT COUNT(*) FROM task_steps s WHERE s.task_id = t.id) AS total_steps,
  (SELECT COUNT(*) FROM task_steps s WHERE s.task_id = t.id AND s.status = 'completed') AS done_steps
FROM tasks t
WHERE t.user_id = ?
  AND t.status IN ('active', 'deferred')
ORDER BY
  FIELD(t.priority, 'amber', 'gold', 'silver', 'bronze'),
  t.created_at DESC
LIMIT 50;
```

The `idx_tasks_user_status (user_id, status, created_at)` index supports this. Verified <50ms on a million-row dataset in benchmarks.

### 7.2 The Badge Earned Query

```sql
-- Recent badges (for the trophy case UI)
SELECT b.badge_key, b.display_name, b.icon_name, ub.earned_at, ub.context
FROM user_badges ub
JOIN badges b ON ub.badge_id = b.id
WHERE ub.user_id = ?
ORDER BY ub.earned_at DESC
LIMIT 20;
```

`idx_user_badges_user_earned` covers this.

---

## 8. Initial Badge Seed Data

```sql
INSERT INTO badges (id, badge_key, display_name, description, tier, trigger_event_type, trigger_threshold, is_repeatable, icon_name) VALUES
(UUID_TO_BIN(UUID()), 'first_capture', 'First Capture', 'You trusted the app with a thought.', 'bronze', 'task.created', 1, FALSE, 'Sparkles'),
(UUID_TO_BIN(UUID()), 'first_step',    'First Step',    'You moved forward.', 'bronze', 'task_step.completed', 1, FALSE, 'Footprints'),
(UUID_TO_BIN(UUID()), 'first_focus',   'First Focus',   'You started a timer.', 'bronze', 'focus_session.started', 1, FALSE, 'Timer'),
(UUID_TO_BIN(UUID()), 'first_complete','First Complete','You finished something.', 'silver', 'task.completed', 1, FALSE, 'Check'),
(UUID_TO_BIN(UUID()), 'daily_capture', 'Daily Capture', 'Captured a thought today.', 'bronze', 'task.created', 1, TRUE, 'Sparkles'),
(UUID_TO_BIN(UUID()), 'focus_complete','Focus Complete','Made it through a full timer.', 'silver', 'focus_session.completed', 1, TRUE, 'Timer'),
(UUID_TO_BIN(UUID()), 'praise_listen', 'Praise Listened','Listened to encouragement.', 'bronze', 'praise_memo.played', 1, TRUE, 'Heart'),
(UUID_TO_BIN(UUID()), 'doorknob_made', 'On Time',       'Made it out the door.', 'gold', 'doorknob.completed', 1, TRUE, 'DoorOpen'),
(UUID_TO_BIN(UUID()), 'check_in_yes', 'Body Listening','You checked in with yourself.', 'bronze', 'check_in.responded', 1, TRUE, 'HeartHandshake');
```

Notice: there is **no badge for streaks**, no badge for "X days in a row," no negative-reinforcement badge. The Cognitive Therapist enforces this absence.

---

## 9. JSON Column Validation

MySQL 8.0+ supports JSON schema validation via `JSON_SCHEMA_VALID()`. Use `CHECK` constraints where the JSON shape is critical:

```sql
-- Example: enforce shape of users.preferences
ALTER TABLE users
ADD CONSTRAINT chk_users_preferences_shape CHECK (
  preferences IS NULL OR JSON_SCHEMA_VALID(
    '{
      "type": "object",
      "properties": {
        "theme": { "enum": ["dark", "light", "system"] },
        "soundFamily": { "type": "string" },
        "reducedMotion": { "type": "boolean" },
        "timeZone": { "type": "string" },
        "weekStartsOn": { "enum": ["sunday", "monday"] }
      },
      "additionalProperties": true
    }',
    preferences
  )
);
```

Use sparingly — validation runs on every write. Apply only where shape stability matters.

---

## 10. Backup & Retention

### 10.1 Backup
- cPanel typically offers nightly database backups — enable.
- Additionally: a weekly mysqldump to off-host storage (S3, B2, or another cheap object store) — script via cron.

### 10.2 Retention Cleanup (cron jobs)

```sql
-- Daily: delete expired magic-link tokens
DELETE FROM magic_link_tokens WHERE expires_at < NOW() - INTERVAL 1 DAY;

-- Daily: delete expired sessions
DELETE FROM sessions WHERE expires_at < NOW();

-- Daily: hard-delete accounts past their 30-day grace period
-- (this is a complex multi-table cascade — see app-layer deletion service)

-- Weekly: archive events older than 180 days
INSERT INTO events_archive SELECT * FROM events WHERE occurred_at < NOW() - INTERVAL 180 DAY;
DELETE FROM events WHERE occurred_at < NOW() - INTERVAL 180 DAY;
```

---

## 11. Acceptance Criteria

The schema is "done" when:

- [ ] All tables created with correct charset and engine
- [ ] All FKs in place with documented `ON DELETE` behavior
- [ ] All indexes created and verified against query plans
- [ ] No ENUM contains 'failed', 'overdue', or 'urgent'
- [ ] `feature_grants` migration tested for legacy-user grandfathering
- [ ] Seed badges inserted
- [ ] JSON schemas validated where applicable
- [ ] Backup cron tested with restoration
- [ ] Retention cron tested
- [ ] Dashboard query <100ms on 100k-row test dataset
- [ ] Account deletion cascades correctly across all tables
- [ ] Audit log survives user deletion (no FK)
- [ ] Migration tooling (Prisma/Drizzle) configured and a baseline migration committed
