# Focus Forge — Authentication & User Model Specification

**Status:** Draft v1.0
**Owners:** ADHD Toolkit Task Force
**Stack:** Next.js (App Router) on cPanel Node + MySQL

---

## 1. Guiding Principles (Round-Table)

| Expert | Principle |
|---|---|
| **Cognitive Therapist** | Auth must never shame the user. No "wrong password" red text. No "account locked" panic states. Recovery flows must feel like help, not punishment. |
| **Web Designer** | Single-column auth flows. One decision per screen. Literal labels ("Sign in with email" — not just an icon). Dark-mode default applies even on the login screen. |
| **Behaviorist** | Lowest possible friction at signup. ADHD users abandon multi-step forms. The first 60 seconds of the app are make-or-break. |
| **QA Engineer** | Every error path must have a recovery action. No dead ends. Account state must be recoverable without contacting support. |
| **Psychiatrist** | The "Legacy Free" status is a clinical commitment — once granted, never revoked. This must be enforced at the data layer, not just policy. |
| **Neuroscientist** | Magic-link emails are dopamine traps if delayed. Either send them within 5 seconds or the flow fails. |

---

## 2. Authentication Methods

Four methods supported. User picks one at signup; can link additional methods later from account settings.

### 2.1 Email + Password
- Primary, always available
- Password requirements: min 10 chars, no other rules (NIST 800-63B guidance — complexity rules backfire on ADHD users)
- Hashed with **argon2id** (preferred) or **bcrypt** (cost factor 12 minimum)
- Never logged, never displayed, never emailed

### 2.2 OAuth — Google, Apple, Facebook
- Implemented via **NextAuth.js** (Auth.js v5) — handles all three providers natively
- OAuth flows redirect to provider, return with verified email
- If email matches an existing account, prompt user to link (never silently merge)
- Apple Sign-In: **required** for iOS PWA install per App Store guidelines if Google/FB are present (forward-compat)

### 2.3 Magic Link
- User enters email → server emails a single-use link valid for 15 minutes
- Link contains a signed token (JWT or random 256-bit token stored in DB)
- After click, user is logged in and asked: "Set a password for next time?" (skippable)

### 2.4 Method Linking
- Logged-in users can add/remove methods from `/account/security`
- Cannot remove the **last** authentication method (would lock account)
- Email change requires re-verification

---

## 3. Session Management

### 3.1 Session Strategy
- **HTTP-only, Secure, SameSite=Lax cookies** containing a session ID
- Session record stored in MySQL `sessions` table (NOT JWT — server must be able to revoke)
- Session lifetime: **30 days** sliding window (refreshed on activity)
- "Remember me" is **always on** — ADHD users hate re-logging in

### 3.2 Session Revocation
- Logout: deletes the session row
- "Sign out all devices" button in security settings: deletes all sessions for that user
- Password change: revokes all sessions except current

### 3.3 CSRF Protection
- Next.js Server Actions provide built-in CSRF protection
- For custom API routes: double-submit cookie pattern

---

## 4. User Account States

```
┌─────────────────┐
│  unverified     │  Just signed up, email not confirmed
└────────┬────────┘
         │ clicks email confirmation link
         ▼
┌─────────────────┐
│  active         │  Normal state
└────────┬────────┘
         │
         ├─── user requests deletion ──→ ┌──────────────────┐
         │                                │  pending_delete  │  30-day grace period
         │                                └────────┬─────────┘
         │                                         │ 30 days pass OR user cancels
         │                                         ▼
         │                                ┌──────────────────┐
         │                                │  deleted         │  Hard-deleted, email released
         │                                └──────────────────┘
         │
         └─── admin action ────────────→ ┌──────────────────┐
                                          │  suspended       │  Login blocked, data preserved
                                          └──────────────────┘
```

**Forgiveness Protocol applied to account states:**
- `pending_delete` users see a soft "Welcome back — want to keep your account?" screen, never "YOUR ACCOUNT IS BEING DELETED"
- Suspended accounts see an empathetic explanation, not a generic error
- No account is ever called "failed," "expired," or "invalid"

---

## 5. Plan Tier & Legacy User Model

This is the most important piece for your future paid model. **The Psychiatrist insists this be enforced at the data layer.**

### 5.1 Tier Definitions

| Tier | Description |
|---|---|
| `free` | Current free user — gets all features available at signup time |
| `legacy_free` | Granted automatically when paid model launches; preserves all features they had access to |
| `paid` | Future paid tier |
| `paid_lifetime` | Reserved for future use (e.g., one-time purchase) |

### 5.2 Feature Access Logic

Instead of checking `user.tier == 'paid'` everywhere (brittle), we check:

```sql
-- Each user has a "feature_grant_set" — a snapshot of which features they have access to
-- New features added AFTER paid launch are gated by tier check
-- Features that existed BEFORE paid launch remain accessible to legacy_free users
```

**Implementation:** `feature_grants` table records WHICH features a user has access to and WHEN they were granted. When the paid model launches:

1. Run a migration that grants every `free` user access to every feature that currently exists
2. Convert their tier to `legacy_free`
3. New features added after launch check `tier IN ('paid', 'paid_lifetime')` OR `feature_grants` contains the feature

This makes the legacy commitment **mechanically irrevocable** — even a future developer who doesn't know the policy can't accidentally lock out legacy users.

### 5.3 Grandfathering at Account Reactivation
- A `legacy_free` user who deletes their account and signs up again with the same email **does NOT get legacy status back**
- This is documented in the deletion confirmation: "If you sign up again later, you'll start as a regular user."

---

## 6. Sign-Up Flow (Onboarding Entry)

Detailed onboarding lives in `03-onboarding-flow.md`. Auth-specific steps:

```
Landing page
    │
    ▼
"Get Started" (one button, large, literal label)
    │
    ▼
Single screen with FOUR auth options stacked:
  ┌─────────────────────────────────┐
  │  [G] Continue with Google       │
  ├─────────────────────────────────┤
  │  [] Continue with Apple        │
  ├─────────────────────────────────┤
  │  [f] Continue with Facebook     │
  ├─────────────────────────────────┤
  │  ✉  Continue with Email         │
  └─────────────────────────────────┘
    │
    ▼
(If email selected)
  Single field: "Your email"
  Single button: "Send me a magic link"
  Below: small text link: "I'd rather use a password"
    │
    ▼
(Magic link sent OR password screen)
    │
    ▼
First-run experience (separate doc)
```

**Critical UX rules:**
- No "Sign Up" vs "Sign In" distinction. The flow handles both seamlessly.
- New email → creates account. Existing email → signs in. User doesn't have to know which mode they're in.
- No CAPTCHA on first attempt. Add adaptive challenge only after suspicious activity.

---

## 7. Password Reset Flow

```
"Forgot password?" link on email/password screen
    │
    ▼
"Enter your email" — single field
    │
    ▼
"If an account exists, we sent a link" (always show this — don't leak account existence)
    │
    ▼
User clicks link in email (valid 60 minutes, single-use)
    │
    ▼
"Choose a new password" — single field, with show/hide toggle
    │
    ▼
Auto-logged-in, sessions on other devices revoked
    │
    ▼
Land on dashboard, with subtle confirmation: "Password updated."
```

**Cognitive Therapist note:** The phrase is "Reset password" — never "Recover account." Recovery implies something was lost. Reset implies a normal action.

---

## 8. Email Verification

- Required before access to features that send communications (Praise Repository invitations, body doubling)
- NOT required for basic task management — let new users get to value immediately
- Verification email includes a 6-digit code AND a click-link (some users prefer to type)
- Banner at top of dashboard: "Verify your email to unlock the Praise Repository →" (not a blocking modal)

---

## 9. Account Deletion

```
Settings → Account → Delete account
    │
    ▼
Soft confirmation: "We'll keep your data for 30 days in case you change your mind."
[Cancel] [Continue]
    │
    ▼
Final confirmation: "Type DELETE to confirm"
[Cancel] [Delete account]
    │
    ▼
Account → pending_delete state
Email sent: "Your account will be deleted on [date]. Click here to cancel."
    │
    ▼
30 days pass with no cancel
    │
    ▼
Hard delete:
  - User row anonymized (email → null, name → "Deleted user")
  - All tasks, voice dumps, praise memos hard-deleted
  - Audio files removed from disk
  - Sessions revoked
  - Email address released for re-registration
```

**Why 30-day grace period:** ADHD users impulsively delete things and regret it. The grace period is a Forgiveness Protocol applied to account state.

---

## 10. Trusted Contacts (Praise Repository Whitelist)

Praise Repository works only with senders the user has explicitly invited. This is a separate concept from "user accounts" but related.

### 10.1 Trusted Contact Model
- User generates a unique invite link from `/account/praise-senders`
- Link contains a signed token tied to the user's praise inbox
- Sender clicks link → can record up to 3 voice memos within the next 7 days
- After 7 days OR 3 memos, link expires
- User can revoke a sender at any time, deleting their memos

### 10.2 Sender Identity
- Senders provide a display name (free text)
- Senders DO NOT need to create accounts on Focus Forge
- Senders' email/identity is NOT collected (privacy-by-default)
- The user controls what names appear in their Praise inbox

---

## 11. Data Privacy & Compliance

### 11.1 Personal Data Stored
| Field | Purpose | Retention |
|---|---|---|
| Email | Auth, communications | Until account deletion + 30 days |
| Display name | UI personalization | Same |
| Hashed password | Auth | Same |
| OAuth provider IDs | Auth | Same |
| IP address (last login) | Security audit | 90 days rolling |
| Session tokens | Session management | Until logout or 30-day expiry |

### 11.2 Voice & Audio Data
- **Voice Dumps**: audio uploaded → transcribed → audio deleted within 60 seconds. Only transcript retained.
- **Praise audio**: retained as long as the user wants it. Stored on cPanel disk in a non-public directory; served via signed URLs valid for 1 hour.

### 11.3 GDPR / CCPA Compliance
- **Right to access**: `/account/data-export` generates a JSON download of all user data within 24 hours
- **Right to deletion**: handled by the deletion flow above
- **Right to rectification**: editable from `/account`
- **Privacy policy** required at `/privacy`
- **Cookie banner**: only required if we add analytics. For v1, use no third-party analytics → no banner needed.

### 11.4 What We Explicitly DO NOT Store
- Health information (the Voice Dump may *contain* it incidentally; the user is informed)
- Medication data (no field for it)
- Diagnostic data
- Geolocation
- Biometric data

---

## 12. Security Hardening Checklist

| Item | Implementation |
|---|---|
| Password hashing | argon2id with sane defaults |
| Brute-force protection | Rate limit: 5 failed logins per email per 15min, IP-based fallback |
| Session fixation | Regenerate session ID on login |
| HTTPS | Required (cPanel host must have valid cert; Let's Encrypt via cPanel UI) |
| Cookie flags | HttpOnly, Secure, SameSite=Lax |
| HSTS header | `max-age=31536000; includeSubDomains` |
| CSP header | Strict policy, no inline scripts (Next.js can do this) |
| Email enumeration | Generic responses on signup/reset to avoid leaking account existence |
| OAuth state param | Validated on every OAuth callback |
| Magic-link tokens | 256-bit random, single-use, 15-minute expiry, hashed in DB |
| Audit log | Every login, password change, email change, deletion → `audit_log` table |

---

## 13. Open Questions for Phase 2

These are deliberately deferred — flagging them for visibility:

- **2FA / TOTP**: Recommended for paid tier. Not blocking v1.
- **Passkey support (WebAuthn)**: Modern, ADHD-friendly, no passwords. Add when stable.
- **Email provider**: Resend, Postmark, or AWS SES? Decision needed before launch (SES is cheapest if comfortable with AWS).
- **OAuth app registration**: Need developer accounts at Google Cloud Console, Apple Developer, Facebook for Developers. Free, but Apple costs $99/yr for the developer program if you want Apple Sign-In on iOS-installed PWA.

---

## 14. Acceptance Criteria

The auth system is "done" when:

- [ ] User can sign up with email+password, log in, log out
- [ ] User can sign up via Google, Apple, Facebook
- [ ] User can request a magic link and authenticate via email
- [ ] User can link additional auth methods to an existing account
- [ ] Password reset works end-to-end with no dead ends
- [ ] Email verification flow works without blocking core features
- [ ] Account deletion works with 30-day grace period and reversal
- [ ] Sessions survive 30 days of activity, expire after 30 days of inactivity
- [ ] Logout-everywhere works
- [ ] No red text appears anywhere in the auth flow
- [ ] All error states have a recovery action
- [ ] Trusted-contact invite links work for non-account-holders
- [ ] Data export produces a valid JSON file
- [ ] All forms work with keyboard-only navigation
- [ ] All forms work with screen readers (axe-core: 0 violations)
